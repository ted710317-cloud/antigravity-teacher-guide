"""Overlay reviewed red-pen annotations onto a scanned PDF."""

import argparse
from io import BytesIO
import json
from math import atan2, cos, sin
from pathlib import Path

from pypdf import PdfReader, PdfWriter, Transformation
from reportlab.lib.colors import HexColor, white
from reportlab.lib.pagesizes import A4, landscape
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen.canvas import Canvas

RED = HexColor("#A91E2C")
FONT = "ReviewKai"


def checked_point(x, y, width, height):
    if not (0 <= x <= 1 and 0 <= y <= 1):
        raise ValueError(f"Expected normalized coordinates, got {x}, {y}")
    return x * width, (1 - y) * height


def draw_mark(canvas, mark, width, height, font):
    kind = mark["type"]
    if kind in {"text", "vertical"}:
        x, y = checked_point(mark["x"], mark["y"], width, height)
        size = float(mark.get("size", 10))
        step = float(mark.get("step", size * 1.18))
        if not 5 <= size <= 40 or step < size:
            raise ValueError("Use a font size of 5–40 pt and a step at least as large.")
        lines = mark["text"].splitlines()
        missing = sorted({char for line in lines for char in line if ord(char) not in font.face.charToGlyph})
        if missing:
            raise ValueError("Font lacks glyphs for " + "".join(missing))
        canvas.setFont(FONT, size)
        for column, line in enumerate(lines):
            if kind == "text":
                baseline = y - step * column
                if baseline < size or x + pdfmetrics.stringWidth(line, FONT, size) > width:
                    raise ValueError("Horizontal note extends beyond its page.")
                if mark.get("bold"):
                    text = canvas.beginText(x, baseline)
                    text.setFont(FONT, size)
                    text.setTextRenderMode(2)
                    canvas.setLineWidth(.42)
                    text.textOut(line)
                    canvas.drawText(text)
                else:
                    canvas.drawString(x, baseline, line)
                continue
            center = x - column * step
            if center < size or center + size / 2 > width or y - step * (len(line) - 1) < size:
                raise ValueError("Vertical note extends beyond its page.")
            for i, char in enumerate(line):
                if char in "，。":
                    canvas.drawCentredString(center + size * .15, y - i * step + size * .15, char)
                else:
                    canvas.drawCentredString(center, y - i * step, char)
    elif kind in {"box", "circle"}:
        left, top = checked_point(*mark["top_left"], width, height)
        right, bottom = checked_point(*mark["bottom_right"], width, height)
        if not (left < right and bottom < top):
            raise ValueError("Invalid rectangle")
        if kind == "box":
            canvas.setFillColor(white)
            canvas.roundRect(left, bottom, right - left, top - bottom, 3, stroke=1, fill=1)
        else:
            canvas.ellipse(left, bottom, right, top, stroke=1, fill=0)
    elif kind in {"line", "arrow"}:
        points = [checked_point(*point, width, height) for point in mark["points"]]
        if len(points) < 2:
            raise ValueError("A line needs at least two points.")
        for (x, y), (nx, ny) in zip(points, points[1:]):
            canvas.line(x, y, nx, ny)
        if kind == "arrow":
            (x, y), (nx, ny) = points[-2:]
            angle = atan2(ny - y, nx - x)
            for offset in (-.48, .48):
                canvas.line(nx, ny, nx - 4 * cos(angle + offset), ny - 4 * sin(angle + offset))
    else:
        raise ValueError(f"Unknown annotation type: {kind}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("plan", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--font", type=Path, required=True, help="Authorized Traditional Chinese TrueType font")
    parser.add_argument("--font-index", type=int, default=0, help="Font face index for a TTC")
    args = parser.parse_args()
    if args.output.exists() or args.output.resolve() == args.source.resolve():
        parser.error("Use a new output filename.")
    reader = PdfReader(args.source)
    plan = json.loads(args.plan.read_text(encoding="utf-8"))
    if not plan or not set(plan) <= {str(i) for i in range(1, len(reader.pages) + 1)}:
        parser.error("Plan keys must be existing one-based page numbers.")
    font = TTFont(FONT, str(args.font), subfontIndex=args.font_index)
    pdfmetrics.registerFont(font)
    layer = BytesIO()
    canvas = Canvas(layer)
    writer = PdfWriter()
    for i, page in enumerate(reader.pages, 1):
        if page.get("/Annots"):
            parser.error(f"Page {i} has live annotations. Export a flattened working copy first.")
        page.transfer_rotation_to_content()
        source_w, source_h = map(float, (page.cropbox.width, page.cropbox.height))
        width, height = landscape(A4) if source_w >= source_h else A4
        factor = min(width / source_w, height / source_h)
        left = (width - source_w * factor) / 2 - float(page.cropbox.left) * factor
        bottom = (height - source_h * factor) / 2 - float(page.cropbox.bottom) * factor
        destination = writer.add_blank_page(width=width, height=height)
        destination.merge_transformed_page(page, Transformation().scale(factor).translate(left, bottom))
        canvas.setPageSize((width, height))
        for mark in plan.get(str(i), []):
            canvas.saveState()
            canvas.setFillColor(RED)
            canvas.setStrokeColor(RED)
            canvas.setLineWidth(.75)
            canvas.setLineCap(1)
            draw_mark(canvas, mark, width, height, font)
            canvas.restoreState()
        canvas.showPage()
    canvas.save()
    for page, marks in zip(writer.pages, PdfReader(layer).pages):
        page.merge_page(marks)
    with args.output.open("xb") as file:
        writer.write(file)


if __name__ == "__main__":
    main()
