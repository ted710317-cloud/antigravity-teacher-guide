"""Create an image-only public PDF after painting approved regions white."""

from contextlib import closing
import argparse
import json
from pathlib import Path

import pypdfium2 as pdfium
from PIL import ImageDraw
from reportlab.lib.utils import ImageReader
from reportlab.pdfgen.canvas import Canvas


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("regions", type=Path, help="JSON mapping 1-based pages to normalized rectangles")
    parser.add_argument("directory", type=Path, help="Empty destination directory")
    parser.add_argument("--dpi", type=int, default=200)
    args = parser.parse_args()
    if not 100 <= args.dpi <= 400:
        parser.error("Choose a resolution from 100 to 400 DPI.")
    regions = json.loads(args.regions.read_text(encoding="utf-8"))
    with pdfium.PdfDocument(args.source) as document:
        expected = {str(i) for i in range(1, len(document) + 1)}
        if set(regions) != expected or not any(regions.values()):
            parser.error("Supply an entry for every page and at least one redaction.")
        for rectangles in regions.values():
            for x0, y0, x1, y1 in rectangles:
                if not (0 <= x0 < x1 <= 1 and 0 <= y0 < y1 <= 1):
                    parser.error("Redaction rectangles must be normalized [left, top, right, bottom].")
        args.directory.mkdir(parents=True, exist_ok=True)
        if any(args.directory.iterdir()):
            parser.error("Destination directory must be empty.")
        pdf = Canvas(str(args.directory / "sample.pdf"), pageCompression=1)
        pdf.setTitle("原卷紅筆作文批改示例")
        pdf.setAuthor("")
        for i in range(len(document)):
            with closing(document[i]) as page:
                w, h = page.get_size()
                with closing(page.render(scale=args.dpi / 72)) as bitmap:
                    rendered = bitmap.to_pil().convert("RGB")
            draw = ImageDraw.Draw(rendered)
            for x0, y0, x1, y1 in regions[str(i + 1)]:
                box = tuple(round(value * size) for value, size in zip((x0, y0, x1, y1), (rendered.width, rendered.height) * 2))
                draw.rectangle(box, fill="white")
            rendered.save(args.directory / f"sample-{i + 1:02d}.webp", lossless=True, method=6)
            pdf.setPageSize((w, h))
            pdf.drawImage(ImageReader(rendered), 0, 0, w, h)
            pdf.showPage()
        pdf.save()


if __name__ == "__main__":
    main()
