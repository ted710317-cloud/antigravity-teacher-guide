"""Render PDF pages to PNG previews, optionally with a normalized 0..1 coordinate grid."""

import argparse
from contextlib import closing
from pathlib import Path

import pypdfium2 as pdfium
from PIL import ImageDraw


def draw_grid(image):
    draw = ImageDraw.Draw(image)
    w, h = image.size
    major_color = (30, 110, 220)
    minor_color = (160, 200, 245)

    for step in range(1, 20):
        ratio = step * 0.05
        is_major = step % 2 == 0
        color = major_color if is_major else minor_color
        width = 2 if is_major else 1
        x = round(ratio * w)
        y = round(ratio * h)
        draw.line([(x, 0), (x, h)], fill=color, width=width)
        draw.line([(0, y), (w, y)], fill=color, width=width)
        if is_major:
            label = f"{ratio:.1f}"
            draw.text((x + 3, 4), label, fill=major_color)
            draw.text((4, y + 3), label, fill=major_color)
    return image


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path, help="Input PDF path")
    parser.add_argument("output_dir", type=Path, help="Directory for rendered PNG files")
    parser.add_argument("--grid", action="store_true", help="Overlay 0.0..1.0 normalized coordinate grid")
    parser.add_argument("--scale", type=float, default=1.5, help="Render scale (default: 1.5, ~108 DPI)")
    args = parser.parse_args()

    if not 0.5 <= args.scale <= 4.0:
        parser.error("Scale must be between 0.5 and 4.0.")

    args.output_dir.mkdir(parents=True, exist_ok=True)
    stem = args.source.stem
    with pdfium.PdfDocument(str(args.source)) as document:
        for idx in range(len(document)):
            with closing(document[idx]) as page:
                with closing(page.render(scale=args.scale)) as bitmap:
                    image = bitmap.to_pil().convert("RGB")
            if args.grid:
                image = draw_grid(image)
            suffix = "grid" if args.grid else "preview"
            out_path = args.output_dir / f"{stem}_p{idx + 1}_{suffix}.png"
            image.save(out_path)
            print(out_path)


if __name__ == "__main__":
    main()
