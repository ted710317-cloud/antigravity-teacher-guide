# -*- coding: utf-8 -*-
"""
國小國語科 各課隨堂小考／單元評量卷 自動生成引擎
Chinese Quiz Generator Engine
支援「國字田字格＋右側注音欄」高規格排版（吻合橡皮章樣式）
"""

import os
import sys
import json
import argparse
import subprocess
from datetime import datetime

CHROME_PATHS = [
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    os.path.expanduser(r"~\AppData\Local\Google\Chrome\Application\chrome.exe"),
]

def find_chrome():
    for p in CHROME_PATHS:
        if os.path.exists(p):
            return p
    return "chrome"

CSS_STYLES = """
  @page {
    size: A4 landscape;
    margin: 0;
  }
  * {
    box-sizing: border-box;
    -webkit-print-color-adjust: exact;
    print-color-adjust: exact;
  }
  body {
    margin: 0;
    padding: 0;
    background-color: #57606f;
    font-family: "DFKai-SB", "BiauKai", "標楷體", "Kaiti TC", "KaiTi", serif;
  }

  /* 螢幕頂部列印工具列 */
  .toolbar {
    width: 297mm;
    margin: 10px auto 4px auto;
    background: #2f3542;
    color: #f1f2f6;
    padding: 10px 20px;
    border-radius: 6px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-family: system-ui, -apple-system, "Microsoft JhengHei", sans-serif;
  }
  .btn-print {
    background: #2ed573;
    color: white;
    border: none;
    padding: 8px 24px;
    font-size: 15px;
    font-weight: bold;
    border-radius: 4px;
    cursor: pointer;
    box-shadow: 0 2px 6px rgba(0,0,0,0.3);
  }
  .btn-print:hover { background: #26af5f; }

  /* A4 橫式紙張容器 (297mm x 210mm) - 單張 A4 版面 */
  .page-sheet {
    width: 297mm;
    height: 210mm;
    margin: 12px auto;
    background: #ffffff;
    box-shadow: 0 4px 20px rgba(0,0,0,0.25);
    box-sizing: border-box;
    padding: 4mm 4mm;
    display: grid;
    grid-template-columns: 135mm 2mm 152mm; /* 左半頁、中折線、右半頁 */
    page-break-after: always;
    overflow: hidden;
  }

  @media print {
    body { background: transparent; }
    .toolbar { display: none !important; }
    .page-sheet {
      margin: 0 !important;
      box-shadow: none !important;
      width: 297mm !important;
      height: 210mm !important;
      page-break-after: always;
    }
  }

  /* 直書半頁容器（垂直由右至左直書） */
  .half-page {
    height: 202mm;
    writing-mode: vertical-rl;
    text-orientation: mixed;
    overflow: hidden;
  }

  /* 卷頭資訊欄 */
  .header-col {
    display: block;
    height: 200mm;
    margin-left: 1.2mm;
    white-space: nowrap;
  }
  .exam-title {
    display: block;
    font-size: 13.5pt;
    font-weight: 900;
    letter-spacing: 0.1em;
    color: #1e272e;
    border-bottom: 2px solid #1e272e;
    padding-bottom: 2mm;
  }
  .info-bar {
    display: block;
    font-size: 11.5pt;
    font-weight: bold;
    color: #2f3542;
    letter-spacing: 0.08em;
    line-height: 1.4;
    margin-left: 1.5mm;
  }

  /* 大題標題行 */
  .sec-header {
    display: block;
    height: 200mm;
    font-size: 10.5pt;
    font-weight: bold;
    color: #1e272e;
    margin-left: 1.2mm;
    letter-spacing: 0.04em;
    line-height: 1.4;
    white-space: nowrap;
  }

  /* 題目直行直欄 - 12 號字 */
  .q-col {
    display: block;
    height: 200mm;
    margin-left: 0.8mm;
    font-size: 12pt;
    line-height: 1.36;
    letter-spacing: 0.01em;
    white-space: nowrap;
    box-sizing: border-box;
    color: #2f3542;
  }
  .q-num {
    font-size: 12pt;
    font-weight: bold;
    color: #1e272e;
    margin-bottom: 1.2mm;
  }

  /* ================= 國字田字格 ＋ 右側注音欄 ================= */
  .tianzi-word {
    display: inline-flex;
    writing-mode: horizontal-tb; /* 內部水平軸向，使各字由上而下自然堆疊 */
    flex-direction: column;
    width: 8.8mm;
    border: 1.4px solid #2f3542;
    vertical-align: middle;
    margin: 0 0.5mm;
    background: #ffffff;
    box-sizing: border-box;
  }
  .tianzi-char {
    display: flex;
    flex-direction: row;
    width: 100%;
    height: 10.0mm;
    border-bottom: 1.3px solid #2f3542;
    box-sizing: border-box;
    position: relative;
  }
  .tianzi-char:last-child {
    border-bottom: none;
  }

  /* 左側大格：國字田字格 */
  .tianzi-hz {
    width: 6.1mm;
    height: 100%;
    border-right: 1.3px solid #2f3542; /* 實心分隔線 */
    position: relative;
    box-sizing: border-box;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  /* 十字虛線：水平線 */
  .tianzi-hz::before {
    content: "";
    position: absolute;
    top: 50%;
    left: 0;
    width: 100%;
    height: 0;
    border-top: 1px dashed #747d8c;
    pointer-events: none;
  }
  /* 十字虛線：垂直線 */
  .tianzi-hz::after {
    content: "";
    position: absolute;
    top: 0;
    left: 50%;
    width: 0;
    height: 100%;
    border-left: 1px dashed #747d8c;
    pointer-events: none;
  }

  /* 右側小格：注音欄（純淨直線直條） */
  .tianzi-zy {
    width: 2.7mm;
    height: 100%;
    box-sizing: border-box;
    display: flex;
    align-items: center;
    justify-content: center;
    writing-mode: vertical-rl;
    text-orientation: mixed;
    position: relative;
    line-height: 1;
  }

  /* 中間折線 */
  .center-divider {
    height: 200mm;
    border-left: 1px dashed #a4b0be;
    margin: 0 auto;
    position: relative;
  }
  .divider-tag {
    position: absolute;
    top: 50%;
    left: -7px;
    transform: translateY(-50%);
    background: #ffffff;
    padding: 6px 0;
    font-size: 8pt;
    color: #747d8c;
    writing-mode: vertical-rl;
    letter-spacing: 0.25em;
    font-weight: bold;
    white-space: nowrap;
  }

  /* 第三大題修辭直欄 - 14 號字 */
  .rhetoric-item {
    display: block;
    height: 200mm;
    font-size: 14pt;
    line-height: 1.45;
    letter-spacing: 0.03em;
    margin-left: 2.2mm;
    color: #2f3542;
    white-space: nowrap;
    box-sizing: border-box;
  }
  .rhetoric-tag {
    font-weight: bold;
    color: #1e272e;
    font-size: 14pt;
  }

  /* 教師解答卷紅字樣式 */
  .ans-hz {
    position: relative;
    z-index: 2;
    color: #eb4d4b;
    font-size: 8.5pt;
    font-weight: bold;
    writing-mode: vertical-rl;
  }
  .ans-zy {
    position: relative;
    z-index: 2;
    color: #eb4d4b;
    font-size: 5.5pt;
    font-weight: bold;
    writing-mode: vertical-rl;
    letter-spacing: -0.5px;
    line-height: 1;
  }
  .circle-mark {
    border: 1.8px solid #eb4d4b;
    border-radius: 50%;
    padding: 1px 3px;
    color: #eb4d4b;
    font-weight: bold;
    display: inline-block;
  }
"""

def make_boxes_student(count):
    html = '<div class="tianzi-word">'
    for _ in range(count):
        html += '<div class="tianzi-char"><div class="tianzi-hz"></div><div class="tianzi-zy"></div></div>'
    html += '</div>'
    return html

def make_boxes_teacher(word, pinyin):
    chars = list(word)
    pinyins = pinyin.strip().split()
    while len(pinyins) < len(chars):
        pinyins.append("")
    
    html = '<div class="tianzi-word" style="border-color:#eb4d4b;">'
    for hz, zy in zip(chars, pinyins):
        html += f'<div class="tianzi-char" style="border-bottom-color:#eb4d4b;"><div class="tianzi-hz" style="border-right-color:#eb4d4b;"><span class="ans-hz">{hz}</span></div><div class="tianzi-zy"><span class="ans-zy">{zy}</span></div></div>'
    html += '</div>'
    return html

def generate_html(data):
    grade = data.get("grade", "六年級")
    grade_short = data.get("grade_short", grade[:2] if len(grade) >= 2 else grade)
    lesson = data.get("lesson", "")
    title = data.get("title", "")
    vocab_list = data.get("vocabulary", [])
    idiom_list = data.get("idioms", [])
    rhetoric_list = data.get("rhetoric", [])

    # Student & Teacher Section 1 HTML
    vocab_html_student = ""
    vocab_html_teacher = ""
    for idx, item in enumerate(vocab_list, 1):
        num_str = ["⒈","⒉","⒊","⒋","⒌","⒍","⒎","⒏","⒐","⒑","⒒","⒓","⒔","⒕","⒖"][idx-1] if idx <= 15 else f"{idx}."
        w = item["word"]
        p = item["pinyin"]
        d = item["definition"]

        boxes_s = make_boxes_student(len(w))
        boxes_t = make_boxes_teacher(w, p)

        vocab_html_student += f"""
    <div class="q-col">
      <span class="q-num">{num_str}</span>
      {boxes_s}
      ：{d}
    </div>"""

        vocab_html_teacher += f"""
    <div class="q-col">
      <span class="q-num">{num_str}</span>
      {boxes_t}
      ：{d}
    </div>"""

    # Student & Teacher Section 2 HTML (Idioms)
    idiom_html_student = ""
    idiom_html_teacher = ""
    for idx, item in enumerate(idiom_list, 1):
        num_str = ["⒈","⒉","⒊","⒋","⒌","⒍","⒎","⒏"][idx-1] if idx <= 8 else f"{idx}."
        w = item["idiom"]
        p = item["pinyin"]
        d = item["definition"]

        boxes_s = make_boxes_student(len(w))
        boxes_t = make_boxes_teacher(w, p)

        idiom_html_student += f"""
    <div class="q-col">
      <span class="q-num">{num_str}</span>
      {boxes_s}
      ：{d}
    </div>"""

        idiom_html_teacher += f"""
    <div class="q-col">
      <span class="q-num">{num_str}</span>
      {boxes_t}
      ：{d}
    </div>"""

    # Student & Teacher Section 3 HTML (Rhetoric)
    rhetoric_html_student = ""
    rhetoric_html_teacher = ""
    for idx, item in enumerate(rhetoric_list, 1):
        num_str = ["⒈","⒉","⒊","⒋","⒌"][idx-1] if idx <= 5 else f"{idx}."
        name = item["name"]
        sent = item["sentence"]
        keywords = item.get("keywords", [])

        rhetoric_html_student += f"""
    <div class="rhetoric-item">
      <span class="q-num">{num_str}</span>
      <span class="rhetoric-tag">【{name}】</span>{sent}
    </div>"""

        sent_marked = sent
        for kw in keywords:
            sent_marked = sent_marked.replace(kw, f'<span class="circle-mark">{kw}</span>')

        rhetoric_html_teacher += f"""
    <div class="rhetoric-item">
      <span class="q-num">{num_str}</span>
      <span class="rhetoric-tag" style="color:#eb4d4b;">【{name}】</span>{sent_marked}
    </div>"""

    full_html = f"""<!DOCTYPE html>
<html lang="zh-TW">
<head>
<meta charset="UTF-8">
<title>國小{grade}國語科 {lesson}《{title}》隨堂小考評量卷</title>
<style>
{CSS_STYLES}
</style>
</head>
<body>

<div class="toolbar">
  <div style="font-weight: bold; font-size: 15px;">國小{grade}國語科 {lesson}《{title}》隨堂小考評量卷 <span style="font-size:12px; font-weight:normal; color:#a4b0be; margin-left:12px;">（【單面一張 A4・國字田字格＋右側注音格】・題目 12 號字・修辭 14 號字完稿版）</span></div>
  <button class="btn-print" onclick="window.print()">🖨️ 一鍵直接列印 / 存為 PDF</button>
</div>

<!-- ==================== 第 1 頁：學生單面 A4 隨堂小考卷 ==================== -->
<div class="page-sheet">

  <!-- 【左半頁】：第二大題（成語積累 12 號字） ＋ 第三大題（修辭練習 14 號字） -->
  <div class="half-page">

    <div class="sec-header">
      二、成語積累（寫出成語國字與注音）：請詳讀各題成語解釋，在前方格子內寫出成語國字與注音（田字格寫國字、右欄寫注音）。
    </div>

    {idiom_html_student}

    <div class="sec-header" style="margin-left: 3.2mm;">
      三、修辭練習（圈選關鍵字詞）：請詳讀例句，在句中直接「圈出」判斷該修辭的關鍵字詞。
    </div>

    {rhetoric_html_student}

  </div>

  <!-- 【中折線】：A4 對折標記線 -->
  <div class="center-divider">
    <div class="divider-tag">✁　請　向　左　半　頁　繼　續　作　答　✁</div>
  </div>

  <!-- 【右半頁】：卷頭資訊 ＋ 第一大題（語詞理解與國字注音 12 號字） -->
  <div class="half-page">

    <div class="header-col">
      <div class="exam-title">國小{grade}國語科 {lesson}《{title}》隨堂小考評量卷</div>
      <div class="info-bar">
        {grade_short}年　　　班　　座號：　　　　　　姓名：　　　　　　　　得分：
      </div>
    </div>

    <div class="sec-header">
      一、寫出國字或注音（依語詞解釋作答）：請詳讀語詞解釋，在前方格子內寫出詞語國字與注音（田字格寫國字、右欄寫注音）。
    </div>

    {vocab_html_student}

  </div>

</div>

<!-- ==================== 第 2 頁：教師解答卷・評分參考 ==================== -->
<div class="page-sheet" style="box-shadow: 0 4px 20px rgba(235, 77, 75, 0.25);">

  <!-- 【左半頁（解答）】：第二大題 ＋ 第三大題 -->
  <div class="half-page">

    <div class="sec-header" style="color: #eb4d4b;">
      二、成語積累（四字成語解答）：田字格為成語國字、右欄為成語注音。
    </div>

    {idiom_html_teacher}

    <div class="sec-header" style="margin-left: 3.2mm; color: #eb4d4b;">
      三、修辭練習（圈選關鍵字詞解答）：紅圈處為判斷修辭之關鍵字詞。
    </div>

    {rhetoric_html_teacher}

  </div>

  <!-- 【中折線】 -->
  <div class="center-divider">
    <div class="divider-tag" style="color: #eb4d4b;">✁　教　師　解　答　卷　・　評　分　參　考　✁</div>
  </div>

  <!-- 【右半頁（解答）】：卷頭 ＋ 第一大題 -->
  <div class="half-page">

    <div class="header-col">
      <div class="exam-title" style="color: #eb4d4b; border-bottom-color: #eb4d4b;">國小{grade}國語科 {lesson}《{title}》【教師解答卷】</div>
      <div class="info-bar" style="color: #eb4d4b;">
        滿分 100 分（一、60 分 二、30 分 三、10 分）
      </div>
    </div>

    <div class="sec-header" style="color: #eb4d4b;">
      一、寫出國字或注音（語詞解釋解答）：田字格為詞語國字、右欄為詞語注音。
    </div>

    {vocab_html_teacher}

  </div>

</div>

</body>
</html>
"""
    return full_html


def build_exam(json_path, output_dir=None, base_name=None):
    with open(json_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    if not output_dir:
        output_dir = os.path.dirname(os.path.abspath(json_path))
    os.makedirs(output_dir, exist_ok=True)

    grade = data.get("grade", "六年級")
    lesson = data.get("lesson", "")
    title = data.get("title", "")
    
    if not base_name:
        base_name = f"{grade}國語{lesson}_{title}_隨堂小考"
        base_name = "".join(c for c in base_name if c not in r'\/:*?"<>|')

    html_path = os.path.join(output_dir, f"{base_name}.html")
    pdf_path = os.path.join(output_dir, f"{base_name}_A4單面版.pdf")
    png_path = os.path.join(output_dir, f"{base_name}_A4單面版_預覽.png")

    html_content = generate_html(data)
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(html_content)

    print(f"✅ HTML 考卷產生完成: {html_path}")

    # Handle file lock on PDF
    if os.path.exists(pdf_path):
        try:
            os.remove(pdf_path)
        except Exception:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            pdf_path = os.path.join(output_dir, f"{base_name}_A4單面版_{timestamp}.pdf")
            print(f"⚠️ 原始 PDF 遭外部程式鎖定，已自動改存新檔名: {pdf_path}")

    chrome_bin = find_chrome()
    abs_html = os.path.abspath(html_path)
    abs_pdf = os.path.abspath(pdf_path)
    abs_png = os.path.abspath(png_path)

    cmd_pdf = [
        chrome_bin,
        "--headless=new",
        "--disable-gpu",
        "--no-pdf-header-footer",
        f"--print-to-pdf={abs_pdf}",
        abs_html
    ]
    res_pdf = subprocess.run(cmd_pdf, capture_output=True, text=True)
    if os.path.exists(abs_pdf):
        print(f"✅ 高解析度 PDF 編譯完成: {abs_pdf}")
    else:
        print(f"❌ PDF 編譯失敗: {res_pdf.stderr}")

    cmd_png = [
        chrome_bin,
        "--headless=new",
        "--disable-gpu",
        "--window-size=1600,1200",
        f"--screenshot={abs_png}",
        abs_html
    ]
    res_png = subprocess.run(cmd_png, capture_output=True, text=True)
    if os.path.exists(abs_png):
        print(f"✅ 預覽圖截圖完成: {abs_png}")

    return {
        "html": abs_html,
        "pdf": abs_pdf,
        "png": abs_png
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="國語各課小考考卷生成器")
    parser.add_argument("input_json", help="考卷資料 JSON 檔案路徑")
    parser.add_argument("--outdir", default=None, help="輸出資料夾")
    parser.add_argument("--name", default=None, help="輸出檔名基底")
    args = parser.parse_args()

    build_exam(args.input_json, args.outdir, args.name)
