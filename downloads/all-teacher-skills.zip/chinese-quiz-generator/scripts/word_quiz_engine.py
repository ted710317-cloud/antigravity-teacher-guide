# -*- coding: utf-8 -*-
"""
國小國語科 各課隨堂小考／單元評量卷 — 可編輯 Word (.docx) 生成引擎
- Word 原生直書（tbRl）＋ A4 橫向（297×210mm），所有題目與解答文字皆可在 Word 直接編輯
- 注音田字格（國字 1.5×1.5cm＋注音 1.5×0.5cm）以 600dpi 行內圖片嵌入，依詞語字數自動配格（1～6 字）
- 支援正面最多 12 題語詞，超過自動接續至背面（第 2 頁），並產出對應之教師紅字解答卷（第 3～4 頁）
"""
import os
import sys
import json
import shutil
import argparse
import tempfile
from datetime import datetime
from PIL import Image, ImageDraw
from docx import Document
from docx.shared import Mm, Pt, RGBColor
from docx.enum.section import WD_ORIENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

FONT = "標楷體"
RED = RGBColor(0xEB, 0x4D, 0x4B)
GRAY = RGBColor(0x57, 0x60, 0x6F)
CIRCLED_NUMS = ["⒈","⒉","⒊","⒋","⒌","⒍","⒎","⒏","⒐","⒑","⒒","⒓","⒔","⒕","⒖","⒗","⒘","⒙","⒚","⒛"]
DPI = 600


def num_label(idx: int) -> str:
    return CIRCLED_NUMS[idx] if idx < len(CIRCLED_NUMS) else f"{idx + 1}."


def _mm(v: float) -> int:
    return int(round(v / 25.4 * DPI))


def _dashed(draw, p1, p2, color, width, dash=None, gap=None):
    dash = dash or _mm(1.0)
    gap = gap or _mm(0.8)
    (x1, y1), (x2, y2) = p1, p2
    length = max(abs(x2 - x1), abs(y2 - y1))
    pos = 0
    while pos < length:
        end = min(pos + dash, length)
        if x1 == x2:
            draw.line([(x1, y1 + pos), (x1, y1 + end)], fill=color, width=width)
        else:
            draw.line([(x1 + pos, y1), (x1 + end, y1)], fill=color, width=width)
        pos += dash + gap


def build_grid_image(char_count: int, cache_dir: str) -> str:
    path = os.path.join(cache_dir, f"tianzi_{char_count}.png")
    if os.path.exists(path):
        return path
    w, ch = _mm(20), _mm(15)
    h = ch * char_count
    im = Image.new("RGB", (w, h), "white")
    d = ImageDraw.Draw(im)
    lw, hz = _mm(0.35), _mm(15)
    for i in range(char_count):
        y0 = i * ch
        _dashed(d, (0, y0 + ch // 2), (hz, y0 + ch // 2), (116, 125, 140), _mm(0.15))
        _dashed(d, (hz // 2, y0), (hz // 2, y0 + ch), (116, 125, 140), _mm(0.15))
        if i:
            d.line([(0, y0), (w, y0)], fill=(30, 39, 46), width=lw)
    d.line([(hz, 0), (hz, h)], fill=(30, 39, 46), width=lw)
    d.rectangle([0, 0, w - 1, h - 1], outline=(30, 39, 46), width=lw)
    im.save(path, dpi=(DPI, DPI))
    return path


def _set_font(run, size, bold=False, color=None):
    run.font.name = FONT
    run._element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:eastAsia"), FONT)
    run.font.size = Pt(size)
    run.font.bold = bold
    if color is not None:
        run.font.color.rgb = color


def _run_border(run, color="EB4D4B"):
    bdr = OxmlElement("w:bdr")
    for k, v in (("w:val", "single"), ("w:sz", "12"), ("w:space", "0"), ("w:color", color)):
        bdr.set(qn(k), v)
    run._element.get_or_add_rPr().append(bdr)


def _split_keywords(sentence: str, keywords: list[str]) -> list[tuple[str, bool]]:
    """將句子依 keywords 切分為 (片段, 是否高亮) 清單，不重複消耗重疊片段。"""
    if not keywords:
        return [(sentence, False)]
    marks = [False] * len(sentence)
    for kw in sorted(keywords, key=len, reverse=True):
        if not kw:
            continue
        start = 0
        while True:
            idx = sentence.find(kw, start)
            if idx == -1:
                break
            for i in range(idx, idx + len(kw)):
                marks[i] = True
            start = idx + len(kw)
    segs, cur, cur_flag = [], [], marks[0]
    for ch, flag in zip(sentence, marks):
        if flag == cur_flag:
            cur.append(ch)
        else:
            segs.append(("".join(cur), cur_flag))
            cur, cur_flag = [ch], flag
    if cur:
        segs.append(("".join(cur), cur_flag))
    return segs


def generate_docx(data: dict, out_path: str, front_limit: int = 12) -> str:
    grade = data.get("grade", "六年級")
    grade_short = data.get("grade_short", grade.replace("級", ""))
    lesson = data.get("lesson", "")
    title = data.get("title", "")
    vocab = data.get("vocabulary", [])
    idioms = data.get("idioms", [])
    rhetoric = data.get("rhetoric", [])

    front_vocab = vocab[:front_limit]
    back_vocab = vocab[front_limit:]

    doc = Document()
    st = doc.styles["Normal"]
    st.font.name = FONT
    st.element.rPr.rFonts.set(qn("w:eastAsia"), FONT)
    st.font.size = Pt(13)

    sec = doc.sections[0]
    sec.orientation = WD_ORIENT.LANDSCAPE
    sec.page_width, sec.page_height = Mm(297), Mm(210)
    sec.top_margin = sec.bottom_margin = Mm(6)
    sec.left_margin = sec.right_margin = Mm(6)
    td = OxmlElement("w:textDirection")
    td.set(qn("w:val"), "tbRl")
    sect_pr = sec._sectPr
    sect_pr.insert(sect_pr.index(sect_pr.find(qn("w:pgMar"))) + 1, td)
    for g in sect_pr.findall(qn("w:docGrid")):
        sect_pr.remove(g)

    def para(space_left_mm=0.0, page_break=False):
        p = doc.add_paragraph()
        pf = p.paragraph_format
        pf.space_before = Pt(0)
        pf.space_after = Mm(space_left_mm) if space_left_mm else Pt(0)
        pf.line_spacing = 1.0
        pf.page_break_before = page_break
        return p

    def add(p, text, size=13, bold=False, color=None):
        r = p.add_run(text)
        _set_font(r, size, bold, color)
        return r

    with tempfile.TemporaryDirectory() as tmpdir:
        def word_item(idx: int, item: dict, teacher: bool):
            word = item["word"]
            pinyin = item.get("pinyin", "")
            defn = item.get("definition", "")
            p = para(4.5 if teacher else 0.7)
            sz = 12 if teacher else 13
            add(p, num_label(idx) + " ", sz, True)
            if teacher:
                add(p, word, 13, True, RED)
                if pinyin:
                    zy_str = "　".join(pinyin.split())
                    add(p, f"（{zy_str}）", 10.5, True, RED)
            else:
                n = max(1, len(word))
                grid = build_grid_image(n, tmpdir)
                p.add_run().add_picture(grid, width=Mm(20), height=Mm(15 * n))
            add(p, "：" + defn, sz)

        for teacher in (False, True):
            c = RED if teacher else None
            # ---- 正面 ----
            p = para(1.5, page_break=teacher)
            add(p, f"國小{grade}國語科　{lesson}《{title}》" + ("【教師解答卷】" if teacher else "隨堂小考評量卷"), 14, True, c)
            p = para(3)
            if teacher:
                add(p, "滿分 100 分（一、語詞國字注音　二、成語積累　三、修辭練習）", 12, True, c)
            else:
                add(p, f"{grade_short}　　　班　　座號：　　　　　　姓名：　　　　　　　　得分：", 12, True)

            p = para(1.5)
            cont_hint = f"（第{num_label(front_limit)}題起在背面）" if back_vocab else ""
            add(p, f"一、寫出國字或注音（解答）：" if teacher else f"一、寫出國字或注音：請詳讀語詞解釋，在格子內寫出詞語國字與注音{cont_hint}。", 11, True, c)
            for idx, item in enumerate(front_vocab):
                word_item(idx, item, teacher)

            # ---- 背面 ----
            p = para(1.5, page_break=True)
            if back_vocab:
                add(p, "一、寫出國字或注音（接續正面）：", 11, True, c)
                for offset, item in enumerate(back_vocab):
                    word_item(front_limit + offset, item, teacher)
                para(3)
                p = para(1.5)

            add(p, "二、成語積累（解答）：" if teacher else "二、成語積累：請詳讀各題成語解釋，在格子內寫出成語國字與注音（田字格寫國字、右欄寫注音）。", 11, True, c)
            for idx, item in enumerate(idioms):
                word_item(idx, {"word": item["idiom"], "pinyin": item.get("pinyin", ""), "definition": item.get("definition", "")}, teacher)

            if rhetoric:
                para(3)
                p = para(1.5)
                add(p, "三、修辭練習（解答）：紅框處為關鍵字詞。" if teacher else "三、修辭練習：請詳讀例句，在句中直接「圈出」判斷該修辭的關鍵字詞。", 11, True, c)
                for idx, item in enumerate(rhetoric):
                    p = para(2.5)
                    add(p, num_label(idx), 13.5, True)
                    add(p, f"【{item['name']}】", 13.5, True, c)
                    for seg, hl in _split_keywords(item["sentence"], item.get("keywords", [])):
                        if hl and teacher:
                            r = add(p, seg, 13.5, True, RED)
                            _run_border(r)
                        else:
                            add(p, seg, 13.5)

            p = para()
            add(p, "✔教師解答卷結束" if teacher else "✔全卷作答完畢，請仔細檢查", 10, True, c or GRAY)

    # 移除開頭預設空白段落
    first = doc.paragraphs[0]
    if not first.text and not first.runs:
        first._element.getparent().remove(first._element)

    try:
        doc.save(out_path)
        return out_path
    except PermissionError:
        base, ext = os.path.splitext(out_path)
        fallback = f"{base}_{datetime.now().strftime('%H%M%S')}{ext}"
        doc.save(fallback)
        return fallback


DEFAULT_MIRROR_DIR = r"G:\我的雲端硬碟\antigravty\考卷"


def main():
    parser = argparse.ArgumentParser(description="生成可編輯 Word (.docx) 國語小考考卷")
    parser.add_argument("json_path", help="題庫 JSON 檔案路徑")
    parser.add_argument("--outdir", default=r"D:\考卷", help="輸出資料夾")
    parser.add_argument("--mirror-dir", default=DEFAULT_MIRROR_DIR, help="同步備份 DOCX 的雲端資料夾（設為空字串可停用）")
    parser.add_argument("--front-limit", type=int, default=12, help="正面第一大題最多放幾題（預設 12）")
    args = parser.parse_args()

    with open(args.json_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    os.makedirs(args.outdir, exist_ok=True)
    grade = data.get("grade", "六年級")
    lesson = data.get("lesson", "")
    title = data.get("title", "")
    out_docx = os.path.join(args.outdir, f"{grade}國語{lesson}_{title}_隨堂小考_可編輯Word版.docx")

    saved = generate_docx(data, out_docx, front_limit=args.front_limit)
    print(f"✅ 已產出可編輯 Word 考卷：{saved}")

    if args.mirror_dir:
        try:
            os.makedirs(args.mirror_dir, exist_ok=True)
            mirrored = os.path.join(args.mirror_dir, os.path.basename(saved))
            shutil.copy2(saved, mirrored)
            print(f"☁️ 已同步 DOCX 至雲端資料夾：{mirrored}")
        except OSError as e:
            print(f"⚠️ 無法同步至 {args.mirror_dir}：{e}")


if __name__ == "__main__":
    main()
