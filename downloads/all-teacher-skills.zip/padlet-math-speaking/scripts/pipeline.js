#!/usr/bin/env node
/**
 * 說數學 (Talking Math) AI 自動化批改與轉錄產線
 * 整合 Padlet MCP 與 Google Gemini 多模態模型
 */

import fs from 'node:fs';
import path from 'node:path';
import https from 'node:https';
import http from 'node:http';
import os from 'node:os';
import child_process from 'node:child_process';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function getGoogleGenAI() {
  try {
    const mod = await import('@google/genai');
    return mod.GoogleGenAI;
  } catch {
    const candidates = [
      path.join(process.cwd(), 'node_modules', '@google', 'genai', 'dist', 'node', 'index.mjs'),
      path.join('d:', 'padlet', 'node_modules', '@google', 'genai', 'dist', 'node', 'index.mjs'),
      path.join(os.homedir(), '.gemini', 'node_modules', '@google', 'genai', 'dist', 'node', 'index.mjs'),
      path.join(process.cwd(), 'node_modules', '@google', 'genai', 'dist', 'index.mjs'),
      path.join('d:', 'padlet', 'node_modules', '@google', 'genai', 'dist', 'index.mjs'),
      path.join(os.homedir(), '.gemini', 'node_modules', '@google', 'genai', 'dist', 'index.mjs')
    ];
    for (const p of candidates) {
      if (fs.existsSync(p)) {
        const mod = await import('file:///' + p.replace(/\\/g, '/'));
        return mod.GoogleGenAI;
      }
    }
    throw new Error('找不到 @google/genai 套件，請在專案目錄執行 npm install @google/genai');
  }
}

// ── 讀取金鑰 ──
function getPadletApiKey(customKey) {
  if (customKey) return customKey;
  if (process.env.PADLET_API_KEY) return process.env.PADLET_API_KEY;
  try {
    const cfgPath = path.join(os.homedir(), '.gemini', 'config', 'mcp_config.json');
    if (fs.existsSync(cfgPath)) {
      const cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf8'));
      if (cfg.mcpServers?.padlet?.env?.PADLET_API_KEY) {
        return cfg.mcpServers.padlet.env.PADLET_API_KEY;
      }
    }
  } catch {}
  return null;
}

function getGeminiApiKey(customKey) {
  if (customKey) return customKey;
  if (process.env.GEMINI_API_KEY) return process.env.GEMINI_API_KEY;
  if (process.env.GOOGLE_API_KEY) return process.env.GOOGLE_API_KEY;
  const envPath = path.join(process.cwd(), '.env');
  if (fs.existsSync(envPath)) {
    const lines = fs.readFileSync(envPath, 'utf8').split('\n');
    for (const line of lines) {
      const match = line.match(/^\s*(?:GEMINI_API_KEY|GOOGLE_API_KEY)\s*=\s*([^\s#]+)/);
      if (match) return match[1].trim();
    }
  }
  return null;
}

// ── 工具函式 ──
const ID_RE = /^[A-Za-z0-9_]{15,22}$/;
function resolveBoardId(input) {
  const s = input.trim();
  if (ID_RE.test(s)) return s;
  if (s.includes('padlet.')) {
    try {
      const parsedUrl = new URL(s.startsWith('http') ? s : `https://${s}`);
      const lastSegment = parsedUrl.pathname.split('/').filter(Boolean).pop() ?? '';
      const hash = lastSegment.split('-').pop() ?? '';
      if (ID_RE.test(hash)) return hash;
    } catch {}
  }
  throw new Error(`無法從「${input}」解析出 board ID。請確認 Padlet 網址或 15-22 碼的 board ID。`);
}

function sanitizeFilename(name) {
  return name.replace(/[\\/:*?"<>|\r\n\t]/g, '_').trim().slice(0, 50);
}

function downloadFile(url, destPath) {
  return new Promise((resolve, reject) => {
    const client = url.startsWith('https') ? https : http;
    const req = client.get(url, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return downloadFile(res.headers.location, destPath).then(resolve).catch(reject);
      }
      if (res.statusCode !== 200) {
        return reject(new Error(`下載失敗，HTTP 狀態碼：${res.statusCode}`));
      }
      const total = parseInt(res.headers['content-length'] || '0', 10);
      let downloaded = 0;
      const fileStream = fs.createWriteStream(destPath);
      res.on('data', (chunk) => {
        downloaded += chunk.length;
      });
      res.pipe(fileStream);
      fileStream.on('finish', () => {
        fileStream.close();
        resolve({ destPath, size: downloaded, total });
      });
      fileStream.on('error', (err) => {
        try { fs.unlinkSync(destPath); } catch {}
        reject(err);
      });
    });
    req.on('error', reject);
  });
}

async function postPadletComment(padletApiKey, postId, commentHtml) {
  const res = await fetch(`https://api.padlet.dev/v1/posts/${postId}/comments`, {
    method: 'POST',
    headers: {
      'X-API-KEY': padletApiKey,
      'Content-Type': 'application/vnd.api+json',
      Accept: 'application/vnd.api+json',
    },
    body: JSON.stringify({
      data: { type: 'comment', attributes: { htmlContent: commentHtml } },
    }),
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`留言失敗 (${res.status}): ${text}`);
  }
  return await res.json();
}

function getGoogleDriveMathDir(customPath) {
  // 依教師指示：預設不再儲存/同步至 D:\Google 雲端硬碟，僅在明確指定時使用
  if (customPath) {
    if (!fs.existsSync(customPath)) fs.mkdirSync(customPath, { recursive: true });
    return customPath;
  }
  if (process.env.GOOGLE_DRIVE_MATH_PATH) {
    const p = process.env.GOOGLE_DRIVE_MATH_PATH;
    if (!fs.existsSync(p)) fs.mkdirSync(p, { recursive: true });
    return p;
  }
  return null;
}

function escapeHtml(str) {
  if (!str) return '';
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function generateMasterReports({ outputDir, sectionName, boardTitle, topicDesc, reports, customGdrive }) {
  const cleanPrefix = sanitizeFilename(sectionName);

  // 1. Markdown 格式審核表
  let md = `# 📋 ${boardTitle} - ${sectionName} 全班說數學評分審核表\n\n`;
  md += `> **看板名稱**：${boardTitle}\n`;
  md += `> **解題主題**：${topicDesc || sectionName}\n`;
  md += `> **審核機制**：此文件為 AI 初審結果，預設未直接發布至 Padlet。老師審核確認後可手動複製或一鍵發布。\n\n---\n\n`;

  for (const r of reports) {
    md += `### 👤 學生：${r.studentName}（${r.author}）\n`;
    md += `- **Padlet 卡片 ID**：\`${r.postId}\`\n`;
    md += `- **總體評等**：${r.rating}\n`;
    md += `- **說理診斷重點（發布評語）**：${r.conceptSummary}\n`;
    if (r.transcript) {
      md += `\n#### 🎙️ 【語音逐字稿】：\n${r.transcript}\n`;
    }
    md += `\n#### ✏️ 【老師審核區・擬發布回饋評語】：\n\`\`\`text\n${r.comment}\n\`\`\`\n\n---\n\n`;
  }

  const mdFileName = `${cleanPrefix}_說數學評分審核表.md`;
  const mdPath = path.join(outputDir, mdFileName);
  fs.writeFileSync(mdPath, md, 'utf8');

  // 2. HTML 互動審核表
  let html = `<!DOCTYPE html>
<html lang="zh-TW">
<head>
  <meta charset="UTF-8">
  <title>${sectionName} 說數學評分審核表</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, "Microsoft JhengHei", sans-serif; line-height: 1.6; color: #333; max-width: 960px; margin: 0 auto; padding: 24px 16px; background-color: #f8fafc; }
    .header { background: linear-gradient(135deg, #1e3a8a, #2563eb); color: white; padding: 24px; border-radius: 12px; margin-bottom: 20px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); }
    .header h1 { margin: 0 0 8px 0; font-size: 22px; }
    .header p { margin: 4px 0; opacity: 0.9; font-size: 14px; }
    .notice { background: #fef3c7; border-left: 4px solid #f59e0b; padding: 12px 16px; border-radius: 6px; margin-bottom: 20px; font-size: 14px; color: #92400e; }
    .card { background: white; border-radius: 10px; padding: 20px; margin-bottom: 18px; border: 1px solid #e2e8f0; box-shadow: 0 2px 4px rgba(0,0,0,0.04); }
    .card-head { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #f1f5f9; padding-bottom: 10px; margin-bottom: 12px; }
    .st-name { font-size: 17px; font-weight: bold; color: #1e293b; }
    .badge { background: #dbeafe; color: #1d4ed8; padding: 4px 10px; border-radius: 9999px; font-size: 13px; font-weight: 600; margin-left: 6px; }
    .badge-star { background: #fef3c7; color: #b45309; }
    .badge-star-alert { background: #fee2e2; color: #b91c1c; font-weight: bold; border: 1px solid #f87171; }
    .diag-box { font-size: 14px; color: #475569; margin-bottom: 10px; background: #f1f5f9; padding: 8px 12px; border-radius: 6px; }
    .silence-alert { background: #fef2f2; border-left: 4px solid #ef4444; padding: 10px 14px; border-radius: 6px; font-size: 13.5px; color: #991b1b; margin-bottom: 12px; }
    .transcript-box { background: #f8fafc; border: 1px solid #cbd5e1; border-radius: 8px; padding: 10px 14px; margin: 10px 0; }
    .transcript-box summary { font-size: 13.5px; font-weight: bold; color: #1e40af; cursor: pointer; user-select: none; outline: none; }
    .transcript-content { font-size: 13px; color: #334155; line-height: 1.6; max-height: 240px; overflow-y: auto; background: #ffffff; padding: 12px; border-radius: 6px; border: 1px solid #e2e8f0; white-space: pre-wrap; margin-top: 8px; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif; }
    .comment-box { background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 8px; padding: 12px; margin-top: 10px; }
    .comment-box textarea { width: 100%; height: 86px; font-size: 14px; font-family: inherit; padding: 8px; border: 1px solid #86efac; border-radius: 6px; box-sizing: border-box; line-height: 1.5; resize: vertical; }
    .btn { background: #2563eb; color: white; border: none; padding: 7px 16px; border-radius: 6px; cursor: pointer; font-size: 13px; font-weight: 600; margin-top: 8px; display: inline-flex; align-items: center; gap: 4px; }
    .btn:hover { background: #1d4ed8; }
  </style>
</head>
<body>
  <div class="header">
    <h1>📋 ${boardTitle} - ${sectionName} 評分審核表</h1>
    <p>📌 題目/主題：${topicDesc || sectionName}</p>
    <p>👥 審核進度：已完成 ${reports.length} 位學生診斷 ｜ 狀態：待教師覆核</p>
  </div>
  <div class="notice">
    💡 <strong>操作說明</strong>：此審核表匯整了 AI 對每位同學解題錄影的逐字稿與初審診斷。您可直接在下方文字框修改評語，點擊「📋 複製評語」手動發布，或審核確認後由系統一鍵批次發布至 Padlet！
  </div>
`;

  for (let i = 0; i < reports.length; i++) {
    const r = reports[i];
    const isSilentAlert = r.isSilent || (r.rating && (r.rating.includes('1') || r.rating.includes('重新錄製')));
    const badgeStarClass = isSilentAlert ? 'badge badge-star-alert' : 'badge badge-star';

    html += `
  <div class="card">
    <div class="card-head">
      <div class="st-name">👤 ${r.studentName}（作者：${r.author}）</div>
      <div>
        <span class="${badgeStarClass}">${r.rating}</span>
        <span class="badge">Post: ${r.postId}</span>
      </div>
    </div>
    ${isSilentAlert ? `
    <div class="silence-alert">
      ⚠️ <strong>聲音異常警示：</strong>檢測到影片無聲音、未開啟麥克風或口語聽不清楚，已依規定判定為 1 顆星，建議請學生重新錄製繳交。
    </div>` : ''}
    <div class="diag-box">
      <strong>說理診斷重點（發布評語）：</strong>${escapeHtml(r.conceptSummary)}
    </div>
    <details class="transcript-box" open>
      <summary>🎙️ 語音逐字稿（點擊收合/展開）</summary>
      <div class="transcript-content">${escapeHtml(r.transcript || '（無逐字稿記錄）')}</div>
    </details>
    <div class="comment-box">
      <label style="font-size: 12px; font-weight: bold; color: #166534; display: block; margin-bottom: 6px;">✏️ 擬發布評語（可直接修改）：</label>
      <textarea id="c-${i}">${escapeHtml(r.comment)}</textarea>
      <button class="btn" onclick="navigator.clipboard.writeText(document.getElementById('c-${i}').value); alert('已複製【${r.studentName}】的評語！')">📋 複製評語</button>
    </div>
  </div>`;
  }

  html += `\n</body>\n</html>`;
  const htmlFileName = `${cleanPrefix}_說數學評分審核表.html`;
  const htmlPath = path.join(outputDir, htmlFileName);
  fs.writeFileSync(htmlPath, html, 'utf8');

  // 同步備份至 Google 雲端硬碟（說數學），不寫入桌面
  const gdriveMathDir = getGoogleDriveMathDir(customGdrive);
  if (gdriveMathDir && fs.existsSync(gdriveMathDir)) {
    try { fs.copyFileSync(htmlPath, path.join(gdriveMathDir, htmlFileName)); } catch {}
    try { fs.copyFileSync(mdPath, path.join(gdriveMathDir, mdFileName)); } catch {}
  }

  // 3. 自動呼叫 generate_summary_docx.py 產出 A4 橫向 Word 評語摘要總表 (.docx)
  let docxPath = null;
  try {
    const summaryScript = path.join(__dirname, 'generate_summary_docx.py');
    if (fs.existsSync(summaryScript) && reports.length > 0) {
      const summaryDataPath = path.join(outputDir, `${cleanPrefix}_summary_data.tmp.json`);
      fs.writeFileSync(summaryDataPath, JSON.stringify({
        boardTitle,
        sectionName,
        topicDesc,
        outputDir,
        customGdrive,
        reports: reports.map(r => ({
          studentName: r.studentName,
          rating: r.rating,
          conceptSummary: r.conceptSummary,
          comment: r.comment,
        }))
      }, null, 2), 'utf8');

      const pyRes = child_process.spawnSync('python', [summaryScript, '--json', summaryDataPath], {
        encoding: 'utf8',
        timeout: 30000,
      });

      if (fs.existsSync(summaryDataPath)) {
        try { fs.unlinkSync(summaryDataPath); } catch {}
      }

      if (pyRes.status === 0) {
        docxPath = path.join(outputDir, `${cleanPrefix}_說數學評語摘要總表.docx`);
      }
    }
  } catch (docxErr) {
    // 略過非關鍵性錯誤
  }

  return { htmlPath, mdPath, docxPath, gdriveMathDir };
}

function extractReportFields(reportText) {
  let transcript = '';
  const transMatch = reportText.match(/(?:###\s*)?任務一[：:\s]*(?:完整)?語音逐字稿[^\n]*\n+([\s\S]+?)(?=\n+(?:---|###\s*任務二|任務二|###\s*說數學解題評分|【總體評等】|####\s*總體評等|$))/i);
  if (transMatch) {
    transcript = transMatch[1].trim();
  } else {
    const fallbackTrans = reportText.match(/(?:逐字稿|語音記錄)[^\n]*\n+([\s\S]+?)(?=\n+---)/i);
    if (fallbackTrans) transcript = fallbackTrans[1].trim();
  }

  const starMatch = reportText.match(/([🌟⭐]+[^\n]+)/) || reportText.match(/總體評等[：:\s]*([^\n]+)/);
  let rating = starMatch ? starMatch[1].trim() : '🌟🌟🌟🌟 優等';

  let comment = '';
  const textBlockMatch = reportText.match(/(?:(?:給學生[^\n]*?評語|說理診斷重點)[^\n]*?\n+)?```text\s*([\s\S]*?)\s*```/);
  if (textBlockMatch) {
    comment = textBlockMatch[1].trim();
  } else {
    const quoteMatch = reportText.match(/(?:給學生[^\n]*?評語|說理診斷重點)[^\n]*?>\s*([^\n]+(?:\n>[^\n]+)*)/);
    if (quoteMatch) {
      comment = quoteMatch[1].replace(/^>\s*/gm, '').trim();
    } else {
      const plainMatch = reportText.match(/(?:【|\[|\*\*)?(?:給學生[^\n]*?評語|說理診斷重點)[^\n]*?\n+([\s\S]+?)(?:\n\n|\n#|$)/);
      if (plainMatch) comment = plainMatch[1].trim();
    }
  }

  let conceptSummary = '';
  const csMatch = reportText.match(/(?:【|\[|\*\*)?(?:說理診斷重點|評分診斷摘要|數學概念正確性)(?:】|\]|\*\*)?[^\n]*\n*([^\n]+)/);
  if (csMatch) conceptSummary = csMatch[1].replace(/^[：:\s*#\-1\.]+/, '').trim();
  if (!conceptSummary) {
    const hlMatch = reportText.match(/(?:【|\[|\*\*)?解題亮點(?:】|\]|\*\*)?[：:\s]*\n+([\s\S]+?)(?:\n\n|\n#|$)/);
    if (hlMatch) conceptSummary = hlMatch[1].trim().split('\n')[0].replace(/^\d+[\.、]\s*/, '').replace(/\*\*/g, '');
  }

  // 依教師要求：發布評語自動註明獲得的星等
  const starNumMatch = rating.match(/([1-5])\s*顆星/) || rating.match(/([🌟⭐]+)/);
  let starCount = 4;
  if (starNumMatch) {
    if (starNumMatch[1].match(/^[1-5]$/)) {
      starCount = parseInt(starNumMatch[1], 10);
    } else {
      starCount = (starNumMatch[1].match(/[🌟⭐]/g) || []).length || 4;
    }
  }
  const starPrefix = `【評等：${'🌟'.repeat(starCount)} ${starCount}顆星】`;

  // 依教師要求：發布評語的內容與說理診斷重點相同
  if (comment) {
    if (!comment.includes('顆星') && !comment.includes('評等')) {
      comment = `${starPrefix}${comment}`;
    }
    conceptSummary = comment;
  } else if (conceptSummary) {
    if (!conceptSummary.includes('顆星') && !conceptSummary.includes('評等')) {
      conceptSummary = `${starPrefix}${conceptSummary}`;
    }
    comment = conceptSummary;
  } else {
    comment = `${starPrefix}計算過程正確！概念提醒：請確認解題說理完整，清楚解釋算式背後原因。`;
    conceptSummary = comment;
  }

  const isSilentOrInaudible = (
    /無聲音|沒有聲音|未開啟麥克風|未錄到聲音|未錄製到口語|缺少語音|聽不清楚|聲音過於模糊|聲音太小聽不到|聲音微弱無法辨識|靜音錄影/i.test(reportText) &&
    (!transcript || transcript.length < 35 || /無聲|靜音|未錄到|聽不清楚|未開啟麥克風|無語音/i.test(transcript))
  ) || (
    transcript && transcript.replace(/\[\d+[:：]\d+.*?\]/g, '').replace(/[\s\-\*\(\)>]/g, '').length < 8
  );

  if (isSilentOrInaudible) {
    rating = '⭐ 1 顆星（待加強 / 請重新錄製）';
    if (!comment || !comment.includes('重新錄製')) {
      comment = `未錄到清楚聲音（請檢查麥克風），說數學需開口說理，請重新錄製上傳。`;
    }
    if (!conceptSummary || conceptSummary.includes('掌握') || conceptSummary.includes('正確')) {
      conceptSummary = '影片未錄到清晰聲音或聲音模糊無法辨識，依規判定 1 顆星，需重新錄製。';
    }
  }

  return { transcript, rating, comment, conceptSummary, isSilentOrInaudible };
}

// ── 主流程 ──
async function main() {
  const args = process.argv.slice(2);
  const getOpt = (name) => {
    const idx = args.indexOf(name);
    return idx >= 0 && args[idx + 1] ? args[idx + 1] : null;
  };
  const hasFlag = (name) => args.includes(name);

  const boardArg = getOpt('--board') || args[0];
  const sectionFilter = getOpt('--section') || getOpt('--class');
  let outputDir = getOpt('--out') || getOpt('--output');
  let customTopic = getOpt('--topic') || getOpt('--prompt');
  const topicFile = getOpt('--topic-file');
  if (topicFile && fs.existsSync(topicFile)) {
    customTopic = fs.readFileSync(topicFile, 'utf8').trim();
  }
  const studentFilter = getOpt('--students') || getOpt('--student');
  const customGdrive = getOpt('--gdrive') || getOpt('--google-drive');
  const autoComment = hasFlag('--comment') || hasFlag('--auto-comment');

  if (!boardArg || hasFlag('--help') || hasFlag('-h')) {
    console.log(`
🎓「說數學」AI 自動化批改與轉錄產線
===================================================
使用方式:
  node pipeline.js --board <Padlet網址或ID> [選項]

選項:
  --section, --class <名稱> 班級或區段名稱（例如 "911"、"數重46（2）用分配律方式解題"）
  --students <座號清單>     指定評審學生（以逗號分隔，例如 "01,12,14,22,26"）
  --topic, --prompt <題目>  指定解題主題與標準解法說明
  --gdrive <目錄>          指定 Google 雲端硬碟說數學同步目錄（預設為 D:\\Google 雲端硬碟\\說數學）
  --out <目錄>             檔案儲存目錄（預設為 ./<section名稱>）
  --comment                跳過教師審核表，直接自動把評語留言到 Padlet 卡片下方
  --help, -h               顯示說明
    `);
    process.exit(boardArg ? 0 : 1);
  }

  const padletKey = getPadletApiKey(getOpt('--padlet-key'));
  const geminiKey = getGeminiApiKey(getOpt('--gemini-key'));

  if (!padletKey) {
    console.error('❌ 錯誤：找不到 PADLET_API_KEY，請確認 mcp_config.json 或環境變數。');
    process.exit(1);
  }
  if (!geminiKey) {
    console.error('❌ 錯誤：找不到 GEMINI_API_KEY，請確認 .env 或環境變數。');
    process.exit(1);
  }

  const GoogleGenAI = await getGoogleGenAI();
  const ai = new GoogleGenAI({ apiKey: geminiKey });
  let boardId = null;
  let autoSectionId = null;
  if (boardArg.includes('/breakout-room/')) {
    const m = boardArg.match(/\/breakout-room\/([A-Za-z0-9_]+)-/);
    if (m) {
      autoSectionId = m[1].startsWith('sec_') ? m[1] : `sec_${m[1]}`;
      console.log(`🔍 偵測到分組討論室（Breakout Room）網址，目標區段 ID：${autoSectionId}`);
      // 先嘗試從網頁中快速抓取 og:url 取得母看板 ID
      try {
        const pageRes = await fetch(boardArg, { headers: { 'User-Agent': 'Mozilla/5.0' } });
        if (pageRes.ok) {
          const html = await pageRes.text();
          const ogMatch = html.match(/property="og:url"\s+content="[^"]*\/padlet-([A-Za-z0-9_]+)"/) ||
                          html.match(/\/padlets\/([A-Za-z0-9_]+)\//) ||
                          html.match(/board\/([A-Za-z0-9_]+)\//);
          if (ogMatch) {
            boardId = ogMatch[1];
            console.log(`✅ 從網頁中快速解析出母看板 ID：${boardId}`);
          }
        }
      } catch {}

      if (!boardId) {
        // 備援：搜尋此使用者的看板以鎖定母看板
        try {
          const meRes = await fetch(`https://api.padlet.dev/v1/me?include=boards`, {
            headers: { 'X-API-KEY': padletKey },
          });
          if (meRes.ok) {
            const meData = await meRes.json();
            const userBoards = (meData.included || []).filter((x) => x.type === 'board');
            for (const b of userBoards) {
              try {
                const bRes = await fetch(`https://api.padlet.dev/v1/boards/${b.id}?include=sections`, {
                  headers: { 'X-API-KEY': padletKey },
                });
                if (bRes.ok) {
                  const bData = await bRes.json();
                  const hasSec = (bData.included || []).some((s) => s.id === autoSectionId);
                  if (hasSec) {
                    boardId = b.id;
                    console.log(`✅ 自動比對到所屬母看板：${b.attributes?.title} (${boardId})`);
                    break;
                  }
                }
              } catch {}
            }
          }
        } catch {}
      }
    }
  }

  if (!boardId) {
    boardId = resolveBoardId(boardArg);
  }

  console.log(`\n========================================`);
  console.log(`🏫 正在連結 Padlet 看板：${boardId}`);
  console.log(`========================================`);

  const res = await fetch(`https://api.padlet.dev/v1/boards/${boardId}?include=posts,sections,comments`, {
    headers: {
      'X-API-KEY': padletKey,
      'Content-Type': 'application/vnd.api+json',
      Accept: 'application/vnd.api+json',
    },
  });

  if (!res.ok) {
    throw new Error(`讀取看板失敗 (${res.status}): ${await res.text()}`);
  }

  const json = await res.json();
  const boardTitle = json.data?.attributes?.title || boardId;
  const included = json.included || [];
  const sections = included.filter((x) => x.type === 'section');
  const posts = included.filter((x) => x.type === 'post');

  console.log(`📌 看板標題：「${boardTitle}」`);

  // 鎖定區段/班級
  let targetSection = null;
  if (autoSectionId) {
    targetSection = sections.find((s) => s.id === autoSectionId);
  }
  if (!targetSection && sectionFilter) {
    targetSection = sections.find(
      (s) => s.id === sectionFilter || (s.attributes?.title || '').toLowerCase().includes(sectionFilter.toLowerCase())
    );
    if (!targetSection) {
      console.error(`❌ 找不到符合「${sectionFilter}」的班級/區段。目前看板區段：`);
      sections.forEach((s) => console.log(`  - ${s.attributes?.title} (ID: ${s.id})`));
      process.exit(1);
    }
  } else if (!targetSection) {
    targetSection = sections[0];
  }

  const sectionName = targetSection.attributes?.title || '未命名區段';
  console.log(`🎯 目標班級/區段：「${sectionName}」`);

  // 確定存放資料夾
  outputDir ??= path.join(process.cwd(), sanitizeFilename(sectionName));
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }
  console.log(`📁 本地儲存資料夾：${outputDir}`);

  // 自動探測老師題目卡片或解題要求
  let detectedTopic = customTopic || '';
  const teacherPromptPost = posts.find(
    (p) =>
      p.relationships?.section?.data?.id === targetSection.id &&
      (p.attributes?.content?.subject?.includes('題目') ||
       p.attributes?.author?.username === (process.env.PADLET_TEACHER_USERNAME || '<您的Padlet帳號>'))
  );
  if (teacherPromptPost && !detectedTopic) {
    detectedTopic = teacherPromptPost.attributes?.content?.body ||
                    teacherPromptPost.attributes?.content?.subject ||
                    sectionName;
  }

  // 篩選出該區段中含有影片的學生貼文
  const videoExts = ['.mp4', '.mov', '.webm', '.m4v', '.mkv'];
  let matchedPosts = posts.filter((p) => {
    if (p.relationships?.section?.data?.id !== targetSection.id) return false;
    // 排除純題目貼文
    if (p.attributes?.content?.subject?.includes('題目') ||
        p.attributes?.content?.subject?.includes('數課') ||
        p.attributes?.author?.username === (process.env.PADLET_TEACHER_USERNAME || '<您的Padlet帳號>')) return false;
    const url = p.attributes?.content?.attachment?.url;
    if (!url) return false;
    const lowerUrl = url.toLowerCase();
    return videoExts.some(ext => lowerUrl.includes(ext)) ||
           lowerUrl.includes('screenrecording') ||
           lowerUrl.includes('rpreplay');
  });

  // 自動建立歷史座號作者對照表，若學生貼文未填座號則自動補齊
  const historicalSeatMap = new Map();
  try {
    const searchDirs = [process.cwd(), path.join(process.cwd(), '..')];
    for (const sDir of searchDirs) {
      if (!fs.existsSync(sDir)) continue;
      const dirs = fs.readdirSync(sDir);
      for (const d of dirs) {
        const fullD = path.join(sDir, d);
        try {
          if (fs.statSync(fullD).isDirectory()) {
            const files = fs.readdirSync(fullD).filter(f => f.endsWith('_評分報告.md'));
            for (const f of files) {
              const m = f.match(/^(\d+)_([^_]+)_/);
              if (m) {
                historicalSeatMap.set(m[2].trim(), m[1]);
              }
            }
          }
        } catch {}
      }
    }
  } catch {}

  for (const p of matchedPosts) {
    let s = (p.attributes?.content?.subject || '').trim();
    const a = (p.attributes?.author?.fullName || p.attributes?.author?.shortName || '').trim();
    const classNumMatch = s.match(/^6\d{2}(\d{2})$/);
    if (classNumMatch) {
      s = String(parseInt(classNumMatch[1], 10));
      p.attributes.content = p.attributes.content || {};
      p.attributes.content.subject = s;
    }
    if (!s || !/^\d+/.test(s)) {
      if (historicalSeatMap.has(a)) {
        p.attributes.content = p.attributes.content || {};
        p.attributes.content.subject = historicalSeatMap.get(a);
      }
    }
  }

  if (studentFilter) {
    const targetList = studentFilter.split(/[,，\s]+/).map(s => s.trim()).filter(Boolean);
    matchedPosts = matchedPosts.filter(p => {
      let subj = (p.attributes?.content?.subject || '').trim();
      const m5 = subj.match(/^6\d{2}(\d{2})$/);
      if (m5) subj = String(parseInt(m5[1], 10));
      const author = (p.attributes?.author?.fullName || p.attributes?.author?.shortName || '').trim();
      return targetList.some(t => {
        if (t.includes('-') || subj.includes('-')) {
          return subj.split(/[（\s_]/)[0].trim() === t.trim() || subj.startsWith(t.trim());
        }
        const numT = parseInt(t.replace(/^6\d{2}/, ''), 10);
        const numSubj = parseInt(subj, 10);
        if (!isNaN(numT) && !isNaN(numSubj) && numT === numSubj) return true;
        return subj.split(/[（\s_]/)[0].trim() === t.trim() || author.includes(t);
      });
    });
    console.log(`🎯 指定評審名單：${targetList.join(', ')}（篩選出 ${matchedPosts.length} 部影片）`);
  }

  // 去除重複提交（相同附件網址或相同座號作者取最新一筆）
  const seenUrls = new Set();
  const dedupedPosts = [];
  matchedPosts.sort((a, b) => {
    const timeA = new Date(a.attributes?.updatedAt || a.attributes?.createdAt || 0).getTime();
    const timeB = new Date(b.attributes?.updatedAt || b.attributes?.createdAt || 0).getTime();
    return timeB - timeA;
  });
  for (const p of matchedPosts) {
    const attachUrl = p.attributes?.content?.attachment?.url;
    const author = p.attributes?.author?.username || p.attributes?.author?.fullName || '';
    const subj = p.attributes?.content?.subject || '';
    const key = attachUrl ? attachUrl.split('?')[0] : `${author}_${subj}`;
    if (!seenUrls.has(key)) {
      seenUrls.add(key);
      dedupedPosts.push(p);
    }
  }
  matchedPosts = dedupedPosts;

  matchedPosts.sort((a, b) => {
    const numA = parseInt(a.attributes?.content?.subject || '999', 10);
    const numB = parseInt(b.attributes?.content?.subject || '999', 10);
    return numA - numB;
  });

  console.log(`📹 發現待批改影片數量：${matchedPosts.length} 部\n`);

  if (matchedPosts.length === 0) {
    console.log('ℹ️ 該區段未發現任何學生錄影。');
    process.exit(0);
  }

  const reports = [];

  for (let i = 0; i < matchedPosts.length; i++) {
    const post = matchedPosts[i];
    const authorName = post.attributes?.author?.fullName || post.attributes?.author?.shortName || post.attributes?.author?.name || '未知學生';
    const subject = post.attributes?.content?.subject || `作業_${i + 1}`;
    const displaySubject = subject.includes(authorName) ? subject : `${subject}_${authorName}`;
    const cleanSubject = sanitizeFilename(displaySubject.trim());
    const simpleSubject = sanitizeFilename(subject.trim());
    let reportFile = [
      path.join(outputDir, `${cleanSubject}_評分報告.md`),
      path.join(outputDir, `${simpleSubject}_評分報告.md`),
    ].find(f => fs.existsSync(f));

    if (!reportFile && fs.existsSync(outputDir)) {
      const dirFiles = fs.readdirSync(outputDir);
      const matchFile = dirFiles.find(f =>
        (f.startsWith(`${simpleSubject}_`) || f.startsWith(`${cleanSubject}_`) || f === `${simpleSubject}_評分報告.md`) &&
        f.endsWith('評分報告.md')
      );
      if (matchFile) reportFile = path.join(outputDir, matchFile);
    }

    let reportText = '';

    // 1. 若已有評分報告則直接讀取（支援中斷續跑與快取）
    if (reportFile && fs.existsSync(reportFile)) {
      console.log(`⚡ 發現已有評分報告：${path.basename(reportFile)}，直接載入！`);
      reportText = fs.readFileSync(reportFile, 'utf8');
    } else {
      reportFile = path.join(outputDir, `${cleanSubject}_評分報告.md`);
      const attachUrl = post.attributes?.content?.attachment?.url;
      const urlObj = new URL(attachUrl);
      const ext = path.extname(urlObj.pathname).toLowerCase() || '.mp4';
      const videoFileName = `${post.id}${ext}`;
      const localVideoPath = path.join(outputDir, videoFileName);

      // 下載影片
      if (!fs.existsSync(localVideoPath)) {
        console.log(`⬇️ 下載影片中：${videoFileName} ...`);
        const dl = await downloadFile(attachUrl, localVideoPath);
        console.log(`✅ 下載完成 (${(dl.size / (1024 * 1024)).toFixed(2)} MB)`);
      } else {
        console.log(`⚡ 本機已有該影片，直接進行分析`);
      }

      // 上傳至 Gemini Files API（正確處理 MOV 與 MP4 MIME Type）
      console.log(`⬆️ 上傳至 Gemini API 進行多模態視訊＋語音分析...`);
      let mimeType = 'video/mp4';
      if (ext === '.mov') mimeType = 'video/quicktime';
      else if (ext === '.webm') mimeType = 'video/webm';

      const uploadResult = await ai.files.upload({
        file: localVideoPath,
        mimeType: mimeType,
        config: { mimeType: mimeType },
      });

      let fileInfo = await ai.files.get({ name: uploadResult.name });
      while (fileInfo.state === 'PROCESSING') {
        process.stdout.write('.');
        await new Promise((r) => setTimeout(r, 4000));
        fileInfo = await ai.files.get({ name: uploadResult.name });
      }
      console.log('');

      if (fileInfo.state === 'FAILED') {
        console.error(`❌ 影片轉碼處理失敗，跳過此學生。`);
        continue;
      }

      console.log(`🧠 AI 正在產生逐字稿與說數學教學評分...`);
      const prompt = `
你是一位專業、有愛心且嚴謹的國小/國中數學專業教師。
這是一段學生「說數學 / 解題說明」的錄影作業（包含學生的語音與畫面算式書寫筆跡）。
【解題單元/題目內容】：${detectedTopic || sectionName}

請仔細觀看並聆聽學生的解題影片，完成以下教學診斷：

### 任務一：完整語音逐字稿（繁體中文）
- 依時間軸 [分:秒] 精準記錄學生在影片中所說的每句話。
- 忠實記錄算式唸法、口誤與自我修正。
- 若影片為無聲音/未開啟麥克風/靜音錄影，請在逐字稿開頭明確註明「（無聲錄影 / 未開啟麥克風）」，並記錄畫面算式書寫歷程。

### 任務二：說數學解題評分與教學回饋
請依據「說數學」三項規準評分：
1. **數學概念正確性（40%）**：是否正確理解題意？算式拆解/推導是否精確？計算結果是否正確？有無常見迷思觀念？
2. **解題邏輯與說理（30%）**：是否能清楚說明「為什麼這樣算」？步驟推導是否層層遞進、清晰連貫？
3. **口語表達與螢幕算式配合（30%）**：口齒咬字與語速是否適中？語音說明與螢幕算式指引是否同步？

【🚨 重大核心規定 - 語音檢查與無聲/模糊判定】：
本項作業的核心是「說數學」，學生必須開口說理、用自己的話講解算式！
- 若影片完全沒有聲音、為靜音錄影、只有背景環境雜音、未開啟麥克風、或說話聲音過於模糊微弱完全聽不清楚，請一律直接判定為：
  - **總體評等**：⭐ 1 顆星（待加強 / 請重新錄製）
  - **精進建議**：明確指出影片沒有錄到清楚聲音或未開啟麥克風的問題，提醒檢查設備。
  - **給學生的回饋評語**：「未錄到清楚聲音（請檢查麥克風），說數學需開口說理，請重新錄製上傳。」

【🎯 說理診斷重點與發布評語規範 - 兩者內容保持相同】：
- **發布評語與說理診斷重點完全一致**：發布給學生的回饋評語直接作為「說理診斷重點」，開頭必須註明【評等：🌟... X顆星】，精準聚焦於學生的數學觀念、解題邏輯與說理過程（例如：肯定其運用換單位量擴充為整數除法的清晰觀念、或指出小數點移位原理、商與餘數小數點說明、估算檢驗等核心焦點）。
- **口語嚴謹度與口誤規定**：口語表達是「說數學」的重要一環。
  1. 【觀念正確但有口誤】：解題概念與算理推導完全正確，但在口述過程中有讀錯數字、算式或口快口誤者，最高評等評為 3 顆星（⭐⭐⭐ 3顆星），並需於評語中明確點出口誤處以利學生訂正。
  2. 【觀念錯誤／答案說錯】：解題概念錯誤、算式符號混淆（如比直接等於除法）或計算答案說錯者，評等為 2 顆星以下（⭐⭐ 2顆星或以下）。
- **精簡約 50 字直截回饋**：文字精煉直白（約 50 字左右），徹底屏除客套話與緩衝詞（嚴禁「同學你好、請加油」等套話），兼顧具體亮點肯定與關鍵概念修正，直接點明算理本質。

【輸出結構要求】：
- **總體評等**：🌟 星級評等（1~5 顆星）與等級（特優 / 優等 / 良好 / 待加強）。若無聲或聽不清楚，一律為 ⭐ 1 顆星（待加強 / 請重新錄製）。若「觀念正確但有口誤」為 3 顆星；若「觀念錯誤或答案說錯」為 2 顆星以下。
- **說理診斷重點（即發布評語）**：請以 \`\`\`text 區塊包覆，開頭註明【評等：🌟... X顆星】，後續緊接精準聚焦於學生的數學觀念、解題邏輯與說理過程（約 50 字左右，直指核心，發布評語內容與說理診斷重點完全相同），適合作為 Padlet 留言回饋。
- **解題亮點**：條列 2~3 項學生做得棒的具體細節（若無聲，可肯定其畫面操作或書寫工整）。
- **精進建議**：條列 1~2 項能讓說理更嚴謹、觀念更透徹的改進提醒（若無聲，指出聲音錄製問題；若有口誤，明確指出）。
`;

      let response = null;
      const candidateModels = [
        'gemini-4-hydrogen',
        'gemini-3.8-flash',
        'gemini-3.7-flash',
        'gemini-3.6-flash',
        'gemini-3.5-flash',
        'gemini-3.5-flash-lite',
      ];
      let modelIdx = 0;

      for (let attempt = 1; attempt <= 10; attempt++) {
        const currentModel = candidateModels[modelIdx % candidateModels.length];
        try {
          console.log(`🤖 使用模型 ${currentModel} 進行評分...`);
          response = await ai.models.generateContent({
            model: currentModel,
            contents: [
              {
                fileData: {
                  fileUri: fileInfo.uri,
                  mimeType: fileInfo.mimeType,
                },
              },
              prompt,
            ],
          });
          break;
        } catch (err) {
          console.warn(`⚠️ 模型 ${currentModel} 回應異常 (${err.message?.slice(0, 120)}...)`);
          let switched = false;
          if (err.message?.includes('RESOURCE_EXHAUSTED') || err.message?.includes('429') || err.message?.includes('503') || err.message?.includes('UNAVAILABLE') || err.message?.includes('404') || err.message?.includes('NOT_FOUND')) {
            modelIdx++;
            switched = true;
            const nextModel = candidateModels[modelIdx % candidateModels.length];
            console.log(`🔄 自動切換至模型：${nextModel}`);
          }
          if (attempt < 10) {
            let waitSec;
            if (switched) {
              waitSec = 2;
            } else {
              const delayMatch = err.message?.match(/retry in ([\d.]+)s/i) || err.message?.match(/retryDelay["']?:\s*["']?(\d+)s/i);
              waitSec = delayMatch ? Math.ceil(parseFloat(delayMatch[1])) + 2 : Math.min(attempt * 3 + 2, 20);
              waitSec = Math.max(5, Math.min(waitSec, 30));
            }
            console.log(`⏳ 等待 ${waitSec} 秒後重試 (${attempt}/10)...`);
            await new Promise((r) => setTimeout(r, waitSec * 1000));
          } else {
            throw err;
          }
        }
      }

      try {
        await ai.files.delete({ name: fileInfo.name });
      } catch {}

      reportText = response.text;
      fs.writeFileSync(reportFile, reportText, 'utf8');
      console.log(`📝 已儲存個別評分報告：${cleanSubject}_評分報告.md`);
    }

    // 擷取逐字稿、評等與評語
    const { transcript, rating, comment, conceptSummary, isSilentOrInaudible } = extractReportFields(reportText);

    reports.push({
      postId: post.id,
      studentName: displaySubject,
      author: authorName,
      rating,
      conceptSummary,
      transcript,
      comment,
      isSilent: isSilentOrInaudible,
    });

    // 每批改完一位學生，即時更新審核總表
    generateMasterReports({
      outputDir,
      sectionName,
      boardTitle,
      topicDesc: detectedTopic,
      reports,
      customGdrive,
    });
    console.log(`🔄 已同步更新審核總表（已完成 ${reports.length}/${matchedPosts.length} 位）`);

    // 若啟用 --comment，才自動留言至 Padlet
    if (autoComment) {
      try {
        console.log(`💬 自動上傳評語至學生 Padlet 卡片...`);
        await postPadletComment(padletKey, post.id, `<p>${comment}</p>`);
        console.log(`✅ 已成功回貼評語！`);
      } catch (commentErr) {
        console.warn(`⚠️ 回貼留言失敗：${commentErr.message}`);
      }
    }
  }

  // 若有指定 studentFilter，將 outputDir 中已存在的其他學生評分報告一同載入合併，保持全班總表完整
  if (studentFilter && fs.existsSync(outputDir)) {
    const allReportFiles = fs.readdirSync(outputDir).filter((f) => f.endsWith('評分報告.md'));
    for (const f of allReportFiles) {
      const baseName = f.replace('_評分報告.md', '');
      if (
        reports.some(
          (r) =>
            r.studentName === baseName ||
            sanitizeFilename(r.studentName) === baseName ||
            f.startsWith(sanitizeFilename(r.studentName))
        )
      ) {
        continue;
      }
      try {
        const rText = fs.readFileSync(path.join(outputDir, f), 'utf8');
        const fields = extractReportFields(rText);
        const matchedPost = posts.find((p) => {
          const subj = (p.attributes?.content?.subject || '').trim();
          const author = (
            p.attributes?.author?.fullName ||
            p.attributes?.author?.shortName ||
            p.attributes?.author?.name ||
            ''
          ).trim();
          const disp = subj.includes(author) ? subj : `${subj}_${author}`;
          return (
            sanitizeFilename(disp) === baseName ||
            sanitizeFilename(subj) === baseName ||
            (disp && baseName.startsWith(sanitizeFilename(subj)))
          );
        });
        reports.push({
          postId: matchedPost ? matchedPost.id : 'cached',
          studentName: baseName,
          author: matchedPost
            ? matchedPost.attributes?.author?.fullName || matchedPost.attributes?.author?.name || '學生'
            : '學生',
          rating: fields.rating,
          conceptSummary: fields.conceptSummary,
          transcript: fields.transcript,
          comment: fields.comment,
          isSilent: fields.isSilentOrInaudible,
        });
      } catch (err) {}
    }
    // 依座號重新排序
    reports.sort((a, b) => {
      const numA = parseInt(a.studentName || '999', 10);
      const numB = parseInt(b.studentName || '999', 10);
      return numA - numB;
    });
  }

  const { htmlPath, mdPath, docxPath, gdriveMathDir } = generateMasterReports({
    outputDir,
    sectionName,
    boardTitle,
    topicDesc: detectedTopic,
    reports,
    customGdrive,
  });

  console.log(`\n========================================`);
  console.log(`🎉 說數學批改產線全數完成！共批改 ${reports.length} 位學生。`);
  console.log(`========================================`);
  console.log(`審核表與評語總表已放置於：`);
  console.log(`  - 本地 HTML 互動審核表：${htmlPath}`);
  console.log(`  - 本地 Markdown 審核總表：${mdPath}`);
  if (docxPath && fs.existsSync(docxPath)) {
    console.log(`  - 本地 Word 評語總表 (.docx)：${docxPath}`);
  }
  if (gdriveMathDir && fs.existsSync(gdriveMathDir)) {
    console.log(`  - Google 雲端硬碟（說數學）：${path.join(gdriveMathDir, path.basename(htmlPath))}`);
    if (docxPath) {
      console.log(`  - Google 雲端硬碟（Word 總表）：${path.join(gdriveMathDir, path.basename(docxPath))}`);
    }
  }
  console.log(`\n💡 老師可先於 Google 雲端硬碟開啟 HTML 審核表或 Word 評語摘要總表檢視確認，無誤後再手動張貼或使用 upload_approved.js 一鍵上傳！`);
}

main().catch((err) => {
  console.error('❌ 執行錯誤:', err.message);
  process.exit(1);
});
