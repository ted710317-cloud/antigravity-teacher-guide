#!/usr/bin/env node
/**
 * 批次上傳教師審核通過的說數學評語至 Padlet 卡片
 */

import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';

function getPadletApiKey() {
  if (process.env.PADLET_API_KEY) return process.env.PADLET_API_KEY;
  try {
    const cfgPath = path.join(os.homedir(), '.gemini', 'config', 'mcp_config.json');
    if (fs.existsSync(cfgPath)) {
      const cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf8'));
      if (cfg.mcpServers?.padlet?.env?.PADLET_API_KEY) {
        return cfg.mcpServers.padlet.env.PADLET_API_KEY;
      }
    }
  } catch {}
  return null;
}

function formatToHtml(text) {
  const cleaned = text.split('\n').map(l => l.replace(/^\s*>\s?/, '')).join('\n');
  return cleaned
    .split(/\n\n+/)
    .map(p => {
      let line = p
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
        .replace(/\*(.*?)\*/g, '<em>$1</em>')
        .replace(/\n/g, '<br>');
      return `<p>${line.trim()}</p>`;
    })
    .filter(p => p !== '<p></p>')
    .join('');
}

async function postComment(padletKey, postId, html) {
  const res = await fetch(`https://api.padlet.dev/v1/posts/${postId}/comments`, {
    method: 'POST',
    headers: {
      'X-API-KEY': padletKey,
      'Content-Type': 'application/vnd.api+json',
      Accept: 'application/vnd.api+json',
    },
    body: JSON.stringify({
      data: {
        type: 'comment',
        attributes: { htmlContent: html },
      },
    }),
  });
  if (!res.ok) {
    throw new Error(`留言失敗 (${res.status}): ${await res.text()}`);
  }
  return await res.json();
}

async function main() {
  const args = process.argv.slice(2);
  const target = args[0] || '數重46_2';

  let reviewFilePath = target;
  if (!fs.existsSync(reviewFilePath) || fs.statSync(reviewFilePath).isDirectory()) {
    // 優先在本地專案目錄與 D:\說數學 中尋找
    const candidates = [
      path.join(process.cwd(), target, `${target}_說數學評分審核表.md`),
      path.join(process.cwd(), `${target}_說數學評分審核表.md`),
      path.join('D:\\', '說數學', `${target}_說數學評分審核表.md`),
      path.join('D:\\', 'padlet', target, `${target}_說數學評分審核表.md`),
    ];

    for (const c of candidates) {
      if (fs.existsSync(c)) {
        reviewFilePath = c;
        break;
      }
    }

    if (!fs.existsSync(reviewFilePath)) {
      console.error(`❌ 找不到審核文件：${target}`);
      console.log(`請提供審核表完整路徑或區段名稱，例如：`);
      console.log(`  node upload_approved.js 數重46_2`);
      console.log(`  node upload_approved.js "D:\\Google 雲端硬碟\\說數學\\數重46_2_說數學評分審核表.md"`);
      process.exit(1);
    }
  }

  const padletKey = getPadletApiKey();
  if (!padletKey) {
    console.error('❌ 找不到 PADLET_API_KEY，請檢查 mcp_config.json 或環境變數。');
    process.exit(1);
  }

  console.log(`📖 正在讀取審核文件：${reviewFilePath}`);
  const content = fs.readFileSync(reviewFilePath, 'utf8');

  // 正則支援「學生」或「座號」，容納冒號與換行，並擷取卡片ID、總體評等與擬發布評語
  const studentRegex = /### 👤 (?:學生|座號)[：:]\s*([^\n]+)[\s\S]*?Padlet 卡片 ID[^\`]*?`([^`]+)`[\s\S]*?(?:總體評等|\*\*總體評等\*\*)[：:\s]*([^\n]+)[\s\S]*?【老師審核區・擬發布回饋評語】[^\n]*\n```text\s*([\s\S]*?)\s*```/g;

  const getOpt = (name) => {
    const idx = args.indexOf(name);
    return idx >= 0 && args[idx + 1] ? args[idx + 1] : null;
  };
  const studentFilter = getOpt('--students') || getOpt('--student');
  const targetList = studentFilter ? studentFilter.split(/[,，\s]+/).map(s => s.trim()).filter(Boolean) : null;

  if (targetList) {
    console.log(`🎯 指定上傳名單：${targetList.join(', ')}`);
  }

  let match;
  let count = 0;
  let successCount = 0;

  while ((match = studentRegex.exec(content)) !== null) {
    const studentName = match[1].trim();
    const postId = match[2].trim();
    const ratingStr = match[3].trim();
    const commentText = match[4].trim();

    if (targetList && targetList.length > 0) {
      const isTarget = targetList.some(t => {
        if (t.includes('-') || studentName.includes('-')) {
          return studentName.split(/[（\s_]/)[0].trim() === t.trim() || studentName.startsWith(t.trim());
        }
        const numT = parseInt(t, 10);
        const matchSubjNum = studentName.match(/^0*(\d+)/);
        if (!isNaN(numT) && matchSubjNum) {
          return numT === parseInt(matchSubjNum[1], 10);
        }
        return studentName.split(/[（\s_]/)[0].trim() === t.trim();
      });
      if (!isTarget) continue;
    }

    if (!commentText) {
      console.log(`⏩ [${++count}] 略過學生「${studentName}」（評語為空）`);
      continue;
    }

    // 依教師要求：發布留言自動註明學生獲得的星等
    let finalComment = commentText;
    if (!finalComment.includes('顆星') && !finalComment.includes('評等')) {
      const starNumMatch = ratingStr.match(/([1-5])\s*顆星/) || ratingStr.match(/([🌟⭐]+)/);
      let starCount = 4;
      if (starNumMatch) {
        if (starNumMatch[1].match(/^[1-5]$/)) {
          starCount = parseInt(starNumMatch[1], 10);
        } else {
          starCount = (starNumMatch[1].match(/[🌟⭐]/g) || []).length || 4;
        }
      }
      finalComment = `【評等：${'🌟'.repeat(starCount)} ${starCount}顆星】${finalComment}`;
    }

    console.log(`\n📤 [${++count}] 正在上傳：${studentName} (Post: ${postId})...`);
    console.log(`💬 評語：${finalComment.slice(0, 70)}...`);

    let uploaded = false;
    for (let attempt = 1; attempt <= 3; attempt++) {
      try {
        await postComment(padletKey, postId, formatToHtml(finalComment));
        console.log(`✅ 上傳成功！`);
        successCount++;
        uploaded = true;
        await new Promise(r => setTimeout(r, 1000));
        break;
      } catch (e) {
        if (e.message.includes('429') || e.message.includes('RATE_LIMIT_EXCEEDED')) {
          console.warn(`⏳ 達到 Padlet 留言頻率限制 (429)，等待 60 秒後自動重試 (${attempt}/3)...`);
          await new Promise(r => setTimeout(r, 60000));
        } else {
          console.error(`❌ 上傳失敗：`, e.message);
          break;
        }
      }
    }
  }

  if (count === 0) {
    console.log('⚠️ 未在審核表中解析到任何學生回饋評語，請確認檔案格式是否包含：');
    console.log('  ### 👤 學生：...');
    console.log('  - **Padlet 卡片 ID**：`post_...`');
    console.log('  #### ✏️ 【老師審核區・擬發布回饋評語】：```text ... ```');
  } else {
    console.log(`\n🎉 全部審核評語處理完成！共成功上傳 ${successCount}/${count} 筆留言至 Padlet。`);
  }
}

main().catch(console.error);
