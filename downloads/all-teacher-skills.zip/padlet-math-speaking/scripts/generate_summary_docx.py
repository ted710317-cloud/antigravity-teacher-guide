# -*- coding: utf-8 -*-
"""
🎓 說數學 (Talking Math) - Word 評語摘要總表 (.docx) 自動生成器
============================================================
功能：
1. 支援接收 pipeline.js 傳遞之 JSON 資料、或由目錄/Markdown 自動讀取評審成果。
2. 排版為專業 A4 橫向 (Landscape) 表格，包含單元主題、評量規準說明、學生評等與發布評語。
3. 自動保存至本地目錄並鏡像同步至 Google 雲端硬碟（說數學），不寫入桌面。
"""

import os
import sys
import json
import re
import shutil
import argparse
from datetime import datetime

if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass

try:
    import docx
    from docx.shared import Inches, Pt, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
    from docx.oxml import parse_xml, OxmlElement
    from docx.oxml.ns import nsdecls, qn
except ImportError:
    print("❌ 錯誤：未安裝 python-docx 套件。請執行：pip install python-docx")
    sys.exit(1)


def get_gdrive_math_dir(custom_path=None):
    # 依教師指示：預設不再儲存/同步至 D:\Google 雲端硬碟，僅在明確指定時使用
    if custom_path and os.path.exists(custom_path):
        return custom_path
    if os.environ.get("GOOGLE_DRIVE_MATH_PATH") and os.path.exists(os.environ.get("GOOGLE_DRIVE_MATH_PATH")):
        return os.environ.get("GOOGLE_DRIVE_MATH_PATH")
    return None


def clean_markdown_inline(text):
    """清理 Markdown 格式符號（如 **粗體**、`code`、<br> 等）便於 Word 排版"""
    if not text:
        return ""
    text = re.sub(r"<br\s*/?>", "\n", text, flags=re.IGNORECASE)
    text = re.sub(r"\*\*([^\*]+)\*\*", r"\1", text)
    text = re.sub(r"\*([^\*]+)\*", r"\1", text)
    text = re.sub(r"`([^`]+)`", r"\1", text)
    text = text.replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&")
    return text.strip()


def parse_summary_md_file(md_path):
    """解析已存在的 [區段]_說數學評語摘要總表.md 檔案"""
    if not os.path.exists(md_path):
        return None

    with open(md_path, "r", encoding="utf-8") as f:
        content = f.read()

    meta = {}
    title_m = re.search(r"^#\s*📋?\s*([^\n]+)", content, re.MULTILINE)
    if title_m:
        meta["title"] = title_m.group(1).strip()

    board_m = re.search(r">\s*\*\*看板名稱\*\*[：:\s]*([^\n]+)", content)
    if board_m:
        meta["boardTitle"] = board_m.group(1).strip()

    topic_m = re.search(r">\s*\*\*單元主題\*\*[：:\s]*([^\n]+)", content)
    if topic_m:
        meta["topicDesc"] = topic_m.group(1).strip()

    section_m = re.search(r">\s*\*\*評核區段\*\*[：:\s]*([^\n]+)", content)
    if section_m:
        meta["sectionName"] = section_m.group(1).strip()

    # 提取評量核心標準說明
    standards = []
    std_block_m = re.search(r"###\s*🎯\s*教師指定.*?標準說明[：:]?\s*\n([\s\S]+?)(?:\n\n---|\n##|$)", content)
    if std_block_m:
        std_lines = std_block_m.group(1).strip().split("\n")
        for line in std_lines:
            line_s = line.strip()
            if line_s:
                standards.append(clean_markdown_inline(line_s))
    meta["standards"] = standards

    # 提取表格資料
    table_m = re.search(r"(\|\s*項次[\s\S]+?\n)(?:\n---|\n###|\n$)", content)
    if not table_m:
        # 嘗試尋找任何 Markdown 表格
        table_m = re.search(r"(\|\s*[^\n]+\|\n\|\s*[-:\s|]+\|\n(?:\|[^\n]+\|\n?)+)", content)

    rows_data = []
    headers = []
    if table_m:
        lines = [l.strip() for l in table_m.group(1).strip().split("\n") if l.strip()]
        if len(lines) >= 3:
            headers = [clean_markdown_inline(c.strip()) for c in lines[0].split("|")[1:-1]]
            for line in lines[2:]:
                cols = [clean_markdown_inline(c.strip()) for c in line.split("|")[1:-1]]
                if cols:
                    rows_data.append(cols)

    meta["headers"] = headers
    meta["rows"] = rows_data

    # 若無表格，嘗試從「說數學評分審核表.md」的卡片結構解析
    if not rows_data:
        topic_alt_m = re.search(r">\s*\*\*解題主題\*\*[：:\s]*([^\n]+)", content)
        if topic_alt_m and not meta.get("topicDesc"):
            meta["topicDesc"] = topic_alt_m.group(1).strip()

        # 從解題主題中解析教師評量規準（若有）
        if meta.get("topicDesc") and "教師特別評量" in meta["topicDesc"] and not meta.get("standards"):
            std_match = re.search(r"教師特別評量.*?[：:]\s*(.+)", meta["topicDesc"])
            if std_match:
                stds = re.split(r"(?<=\))\s*(?=\d+[\.、])", std_match.group(1).strip())
                meta["standards"] = [clean_markdown_inline(s) for s in stds if s.strip()]

        student_blocks = re.findall(
            r"###\s*👤\s*學生[：:]\s*([^\n]+)\n([\s\S]*?)(?=\n###\s*👤|\n---\s*\n###\s*👤|$)",
            content
        )
        if student_blocks:
            meta["headers"] = ["項次", "座號 / 姓名", "評等", "診斷摘要與解題重點", "Padlet 發布回饋評語"]
            for idx, (st_line, st_body) in enumerate(student_blocks, start=1):
                st_name = clean_markdown_inline(re.sub(r"（.*?）", "", st_line).strip())
                star_m = re.search(r"-\s*\*\*總體評等\*\*[：:\s]*([^\n]+)", st_body)
                rating = clean_markdown_inline(star_m.group(1).strip()) if star_m else "優等"
                diag_m = re.search(r"-\s*\*\*(?:評分診斷摘要|說理診斷重點[^\*]*)\*\*[：:\s]*([^\n]+)", st_body)
                diag = clean_markdown_inline(diag_m.group(1).strip()) if diag_m else ""
                cm_m = re.search(r"```(?:text)?\s*([\s\S]*?)\s*```", st_body)
                comment = clean_markdown_inline(cm_m.group(1).strip()) if cm_m else ""
                if not diag and comment:
                    diag = comment
                elif not comment and diag:
                    comment = diag
                meta["rows"].append([str(idx), st_name, rating, diag, comment])

    return meta


def build_docx_document(data, output_docx_path, gdrive_dir=None):
    """根據結構化資料建立高品質 A4 橫向 Word 文件"""
    board_title = data.get("boardTitle") or "說數學解題評量"
    section_name = data.get("sectionName") or "班級總表"
    topic_desc = data.get("topicDesc") or "說數學解題說明"
    title_text = data.get("title") or f"📋 {board_title} - {section_name} 全班評語摘要總表"
    standards = data.get("standards") or []
    headers = data.get("headers") or []
    rows = data.get("rows") or []

    doc = docx.Document()

    # 1. 版面配置：A4 橫向 (Landscape)，邊距 0.6 英吋以容納寬表格
    for s in doc.sections:
        s.page_width = Inches(11.69)
        s.page_height = Inches(8.27)
        s.top_margin = Inches(0.6)
        s.bottom_margin = Inches(0.6)
        s.left_margin = Inches(0.6)
        s.right_margin = Inches(0.6)

    # 2. 標題
    title_p = doc.add_paragraph()
    title_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title_p.paragraph_format.space_before = Pt(0)
    title_p.paragraph_format.space_after = Pt(2)
    run_title = title_p.add_run(title_text)
    run_title.font.name = "微軟正黑體"
    run_title.font.size = Pt(17)
    run_title.font.bold = True
    run_title.font.color.rgb = RGBColor(30, 58, 138)  # 深海藍

    # 3. 副標題資訊列
    today_str = datetime.now().strftime("%Y-%m-%d")
    info_p = doc.add_paragraph()
    info_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    info_p.paragraph_format.space_after = Pt(8)
    info_text = f"📌 單元主題：{topic_desc}   ｜   👥 評核區段：{section_name}（共 {len(rows)} 位學生）   ｜   📅 產出日期：{today_str}"
    run_info = info_p.add_run(info_text)
    run_info.font.name = "微軟正黑體"
    run_info.font.size = Pt(9.5)
    run_info.font.color.rgb = RGBColor(100, 116, 139)  # Slate-500

    # 4. 評量規準說明區塊 (淡灰藍底色小卡)
    if standards:
        box = doc.add_table(rows=1, cols=1)
        box.alignment = WD_TABLE_ALIGNMENT.CENTER
        box.autofit = False
        box.columns[0].width = Inches(10.4)
        cell = box.cell(0, 0)

        tcPr = cell._tc.get_or_add_tcPr()
        shd = parse_xml(f'<w:shd {nsdecls("w")} w:fill="F1F5F9"/>')
        tcPr.append(shd)

        bp = cell.paragraphs[0]
        bp.paragraph_format.space_before = Pt(4)
        bp.paragraph_format.space_after = Pt(4)
        r_box_title = bp.add_run("【教師指定兩大評量核心標準】：\n")
        r_box_title.font.name = "微軟正黑體"
        r_box_title.font.size = Pt(9.5)
        r_box_title.font.bold = True
        r_box_title.font.color.rgb = RGBColor(30, 58, 138)

        for std in standards:
            r_std = bp.add_run(f"{std}\n")
            r_std.font.name = "微軟正黑體"
            r_std.font.size = Pt(9)
            r_std.font.color.rgb = RGBColor(51, 65, 85)

        # 移除最後多餘換行
        if bp.runs and bp.runs[-1].text.endswith("\n"):
            bp.runs[-1].text = bp.runs[-1].text[:-1]

        doc.add_paragraph().paragraph_format.space_after = Pt(6)

    # 5. 表格寬度與欄位權重計算 (A4 橫向可用總寬約 10.4 英吋)
    col_count = len(headers) if headers else (len(rows[0]) if rows else 5)

    if col_count == 6:  # [項次, 座號/姓名, 評等, 標準一, 標準二, 發布評語]
        col_widths = [Inches(0.6), Inches(1.3), Inches(0.9), Inches(2.0), Inches(1.8), Inches(3.8)]
    elif col_count == 5:  # [座號/姓名, 評等, 標準一, 標準二, 發布評語]
        col_widths = [Inches(1.4), Inches(0.9), Inches(2.1), Inches(2.0), Inches(4.0)]
    elif col_count == 4:  # [座號/姓名, 評等, 診斷摘要, 發布評語]
        col_widths = [Inches(1.5), Inches(1.0), Inches(3.4), Inches(4.5)]
    else:
        # 動態均分
        w = 10.4 / col_count
        col_widths = [Inches(w)] * col_count

    table = doc.add_table(rows=len(rows) + 1, cols=col_count)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False

    # 表格表頭造型 (深藍色底、白色字體、置中)
    hdr_cells = table.rows[0].cells
    for idx, h_text in enumerate(headers):
        hdr_cells[idx].width = col_widths[min(idx, len(col_widths) - 1)]
        tcPr = hdr_cells[idx]._tc.get_or_add_tcPr()
        shd = parse_xml(f'<w:shd {nsdecls("w")} w:fill="1E3A8A"/>')
        tcPr.append(shd)

        p = hdr_cells[idx].paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_before = Pt(5)
        p.paragraph_format.space_after = Pt(5)
        run = p.add_run(h_text)
        run.font.name = "微軟正黑體"
        run.font.bold = True
        run.font.size = Pt(9.5)
        run.font.color.rgb = RGBColor(255, 255, 255)

    # 填入資料列 (斑馬紋交替背景 #F8FAFC 與 #FFFFFF)
    for row_idx, r_cols in enumerate(rows):
        row_cells = table.rows[row_idx + 1].cells
        bg_color = "F8FAFC" if row_idx % 2 == 1 else "FFFFFF"

        for c_idx in range(col_count):
            cell_item = row_cells[c_idx]
            cell_item.width = col_widths[min(c_idx, len(col_widths) - 1)]
            tcPr = cell_item._tc.get_or_add_tcPr()
            shd = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{bg_color}"/>')
            tcPr.append(shd)

            text_val = r_cols[c_idx] if c_idx < len(r_cols) else ""
            p = cell_item.paragraphs[0]
            p.paragraph_format.space_before = Pt(3)
            p.paragraph_format.space_after = Pt(3)

            # 針對項次、座號姓名、評等進行置中
            if c_idx in (0, 1) and col_count >= 5 and len(text_val) < 15:
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            elif c_idx == 2 and ("星" in text_val or "🌟" in text_val or "⭐" in text_val):
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            else:
                p.alignment = WD_ALIGN_PARAGRAPH.LEFT

            run = p.add_run(text_val)
            run.font.name = "微軟正黑體"
            run.font.size = Pt(8.5)

            # 座號姓名加粗
            if (col_count >= 5 and c_idx == 1) or (col_count == 4 and c_idx == 0):
                run.font.bold = True
                run.font.size = Pt(9)

    # 儲存本機檔案
    output_dir = os.path.dirname(output_docx_path)
    if output_dir and not os.path.exists(output_dir):
        os.makedirs(output_dir, exist_ok=True)
    saved_path = output_docx_path
    try:
        doc.save(output_docx_path)
        print(f"✅ Word 文件總表已建立：{output_docx_path}")
    except PermissionError:
        saved_path = output_docx_path.replace(".docx", "_最新.docx")
        try:
            doc.save(saved_path)
            print(f"⚠️ 原始檔案正被 Word 開啟鎖定中，已另存為：{saved_path}")
        except Exception as e:
            print(f"⚠️ 無法儲存 Word 文件：{e}")
            return None

    # 同步鏡像至 Google 雲端硬碟（說數學），絕不寫入桌面
    gdrive = get_gdrive_math_dir(gdrive_dir)
    if gdrive and os.path.exists(gdrive):
        gdrive_target = os.path.join(gdrive, os.path.basename(output_docx_path))
        try:
            shutil.copyfile(saved_path, gdrive_target)
            print(f"☁️ 已同步鏡像至 Google 雲端硬碟：{gdrive_target}")
        except Exception as e:
            print(f"⚠️ 同步至 Google 雲端硬碟失敗：{e}")

    return saved_path


def generate_from_pipeline_json(json_path, output_dir=None, custom_gdrive=None):
    """從 pipeline.js 輸出的 summary json 產生 docx 與 md 總表"""
    with open(json_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    board_title = data.get("boardTitle", "說數學解題說明")
    section_name = data.get("sectionName", "班級區段")
    topic_desc = data.get("topicDesc", "")
    reports = data.get("reports", [])
    custom_gdrive = custom_gdrive or data.get("customGdrive")
    output_dir = output_dir or data.get("outputDir") or "."

    clean_prefix = re.sub(r'[\\/:*?"<>|]', "_", section_name).strip()

    # 檢查是否有自訂評核標準
    standards = []
    if "因數" in topic_desc or "倍數" in topic_desc or "長方形" in topic_desc:
        standards = [
            "1. 判斷公倍數說理：說明因長方形「往外拼大」，正方形邊長必為長與寬之倍數，且邊長最短故求最小公倍數 [12, 16] = 48 cm。",
            "2. 計算長方形張數：需清楚說明並計算需幾張長方形（48÷16=3、48÷12=4，共 3×4=12 張）。"
        ]
    elif "火柴棒" in topic_desc or "說法一" in topic_desc or "924" in str(section_name):
        standards = [
            "1. 說法一（以第1根為基準）：1+6*4=25根。第一根先擺上，後面每增加一個圖形就加4根。",
            "2. 說法二（以第1個圖為基準）：5+(6-1)*4=25根。第一個圖用5根組成，後面每加4根增加一個圖。",
            "3. 評量標準：只需說明圖⑥即可！兩種說法則說其中一種就通過！只要說明清楚任一種說法且答案25根正確即算通過。"
        ]
    elif topic_desc:
        standards = [f"1. 解題核心概念與標準步驟：{topic_desc}"]

    # 組織表格欄位
    headers = ["項次", "座號 / 姓名", "評等", "診斷摘要與說理", "Padlet 發布回饋評語"]
    rows = []
    for idx, r in enumerate(reports, start=1):
        st_name = r.get("studentName", f"學生_{idx}")
        rating = r.get("rating", "")
        summary = r.get("conceptSummary") or r.get("comment", "")
        comment = r.get("comment") or summary
        if not summary and comment:
            summary = comment
        elif not comment and summary:
            comment = summary
        rows.append([
            str(idx),
            st_name,
            rating,
            summary,
            comment
        ])

    doc_data = {
        "boardTitle": board_title,
        "sectionName": section_name,
        "topicDesc": topic_desc or section_name,
        "title": f"📋 {board_title} - {section_name} 全班評語摘要總表",
        "standards": standards,
        "headers": headers,
        "rows": rows
    }

    docx_path = os.path.join(output_dir, f"{clean_prefix}_說數學評語摘要總表.docx")
    build_docx_document(doc_data, docx_path, custom_gdrive)

    # 同步產出 Markdown 格式總表（若尚未存在或需要更新）
    md_path = os.path.join(output_dir, f"{clean_prefix}_說數學評語摘要總表.md")
    md_content = f"# 📋 {board_title} - {section_name} 全班評語摘要總表\n\n"
    md_content += f"> **看板名稱**：{board_title}  \n"
    md_content += f"> **單元主題**：{topic_desc or section_name}  \n"
    md_content += f"> **評核區段**：{section_name}  \n"
    md_content += f"> **評核學生**：全班共 {len(rows)} 位同學  \n"
    md_content += f"> **產出日期**：{datetime.now().strftime('%Y-%m-%d')}  \n\n---\n\n"

    if standards:
        md_content += "### 🎯 教師指定評量核心標準說明：\n"
        for s in standards:
            md_content += f"- {s}\n"
        md_content += "\n---\n\n"

    md_content += f"## 📊 全班 {len(rows)} 位學生評核摘要表\n\n"
    md_content += "| " + " | ".join(headers) + " |\n"
    md_content += "| " + " | ".join([":---:" if i < 3 else "---" for i in range(len(headers))]) + " |\n"
    for r in rows:
        md_content += "| " + " | ".join([c.replace("\n", "<br>") for c in r]) + " |\n"

    md_content += "\n---\n\n### 📁 檔案保存路徑\n"
    md_content += f"- **Word 文件檔 (`.docx`)**：\n  - 本機：`{os.path.abspath(docx_path)}`\n"
    gdrive = get_gdrive_math_dir(custom_gdrive)
    if gdrive and os.path.exists(gdrive):
        md_content += f"  - 雲端硬碟：`{os.path.join(gdrive, os.path.basename(docx_path))}`\n"
    md_content += f"- **Markdown 文件檔 (`.md`)**：\n  - 本機：`{os.path.abspath(md_path)}`\n"
    if gdrive and os.path.exists(gdrive):
        md_content += f"  - 雲端硬碟：`{os.path.join(gdrive, os.path.basename(md_path))}`\n"

    with open(md_path, "w", encoding="utf-8") as f:
        f.write(md_content)
    print(f"✅ Markdown 總表已建立：{md_path}")

    if gdrive and os.path.exists(gdrive):
        try:
            shutil.copyfile(md_path, os.path.join(gdrive, os.path.basename(md_path)))
            print(f"☁️ 已同步鏡像 Markdown 至 Google 雲端硬碟")
        except Exception:
            pass

    return docx_path


def main():
    parser = argparse.ArgumentParser(description="產生說數學 Word (.docx) 評語摘要總表")
    parser.add_argument("target", nargs="?", default=None, help="區段名稱、資料夾路徑或審核 Markdown 路徑")
    parser.add_argument("--json", dest="json_path", help="從 pipeline.js 產出的 JSON 資料檔案生成")
    parser.add_argument("--md", dest="md_path", help="指定來源 Markdown 摘要表")
    parser.add_argument("--out", dest="output_dir", help="輸出資料夾")
    parser.add_argument("--gdrive", dest="custom_gdrive", help="指定 Google 雲端硬碟說數學路徑")

    args = parser.parse_args()

    # 模式 1：由 pipeline.js 傳遞之 JSON 生成
    if args.json_path and os.path.exists(args.json_path):
        generate_from_pipeline_json(args.json_path, args.output_dir, args.custom_gdrive)
        return

    # 模式 2：由 Markdown 或目錄路徑生成
    target = args.target or args.md_path or "918"
    md_file = None

    if os.path.isfile(target) and target.endswith(".md"):
        md_file = target
    elif os.path.isdir(target):
        # 尋找目錄中的總表或審核表
        dir_files = os.listdir(target)
        for f in dir_files:
            if "評語摘要總表.md" in f:
                md_file = os.path.join(target, f)
                break
        if not md_file:
            for f in dir_files:
                if "評分審核表.md" in f:
                    md_file = os.path.join(target, f)
                    break
    else:
        # 當作區段名稱尋找
        clean_target = re.sub(r'[\\/:*?"<>|]', "_", target)
        candidates = [
            os.path.join(target, f"{clean_target}_說數學評語摘要總表.md"),
            f"{clean_target}_說數學評語摘要總表.md",
            os.path.join("D:\\Google 雲端硬碟\\說數學", f"{clean_target}_說數學評語摘要總表.md"),
            os.path.join(target, f"{clean_target}_說數學評分審核表.md"),
        ]
        for c in candidates:
            if os.path.exists(c):
                md_file = c
                break

    if not md_file or not os.path.exists(md_file):
        print(f"❌ 找不到對應的 Markdown 檔案：{target}")
        print("用法範例：")
        print("  python generate_summary_docx.py 918")
        print("  python generate_summary_docx.py --json pipeline_data.json")
        print("  python generate_summary_docx.py D:/padlet/918/918_說數學評語摘要總表.md")
        sys.exit(1)

    print(f"📖 正在解析來源文件：{md_file} ...")
    parsed_data = parse_summary_md_file(md_file)
    if not parsed_data or not parsed_data.get("rows"):
        print(f"❌ 解析失敗或表格無資料：{md_file}")
        sys.exit(1)

    out_dir = args.output_dir or os.path.dirname(md_file) or "."
    base_name = os.path.basename(md_file).replace(".md", ".docx")
    out_docx = os.path.join(out_dir, base_name)

    build_docx_document(parsed_data, out_docx, args.custom_gdrive)


if __name__ == "__main__":
    main()
