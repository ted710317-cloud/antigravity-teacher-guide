---
name: padlet-math-speaking
description: Complete end-to-end automated pipeline for "Talking Math" (說數學) student video assignments on Padlet. Downloads student video recordings (MP4, MOV, WebM), uses Gemini multimodal AI to transcribe verbatim Traditional Chinese transcripts with timestamps, evaluates mathematical concepts and reasoning logic against 3 educational rubrics, generates concise ~50-character reasoning diagnostic feedback identical between teacher diagnostic focus and Padlet published comments, automatically creates interactive HTML/Markdown review documents and professional A4 landscape Word (.docx) summary documents in the workspace and local backup directory (D:\說數學) for teacher audit, and supports 1-click batch posting of approved feedback to Padlet posts.
---

# 🎓 說數學 (Talking Math) AI 自動化批改技能

此技能專為中小學數學教師設計，能全自動化處理學生在 Padlet 繳交的「說數學」螢幕解題錄影作業，具備完整的多模態影音轉錄、教學規準診斷、**防誤發審核機制**、**Word (.docx) 評語摘要總表排版**與本機備份功能（不自動同步至 Google 雲端硬碟）。

---

## 🌟 核心特色與技術亮點

1. **多格式視訊支援（含 iOS `.mov`）**：
   - 支援 iPhone、iPad 錄製之 `.mov`（`video/quicktime`）、Android/PC 之 `.mp4`、`.webm` 等。
   - 自動配置 MIME Type 與檔案流傳輸，確保上傳至 Gemini Files API 零錯誤。
2. **多模態影音深度診斷（Gemini 4 Hydrogen 與 Gemini 3.8 Flash）**：
   - 同步聆聽學生語音解說並解析螢幕算式筆跡。
   - 產出具精確時間軸（`[分:秒]`）之繁體中文完整逐字稿，忠實記錄算式唸法、口誤與自我修正。
3. **說數學嚴格語音與無聲判定規則（⭐ 1 顆星重錄機制）**：
   - **作業本質**：此為「說數學」作業，學生核心任務在於開口說明解題理由。
   - **無聲/聽不清楚判定**：若影片為完全無聲音、未開啟麥克風、靜音錄影、只有背景環境雜音、或說話聲音過於模糊微弱完全聽不清楚，AI 與後處理系統**一律直接判定為「⭐ 1 顆星（待加強 / 請重新錄製）」**。
   - **精簡重錄評語**：統一為「未錄到清楚聲音（請檢查麥克風），說數學需開口說理，請重新錄製上傳。」
4. **說理診斷重點即發布評語（兩者內容相同，直指核心說理，自動標註星等）**：
   - **自動標註星等標籤**：發布在 Padlet 上的回饋留言開頭自動註明學生獲得的星級評等（例如：`【評等：🌟🌟🌟🌟 4 顆星】` 或 `【評等：🌟🌟🌟 3 顆星】`），學生在看板上對自己的表現等級一目了然。
   - **口語嚴謹度規準（口誤降等機制）**：口語表達是「說數學」的核心一環。解題過程中只要出現口誤（如算式讀錯、位值漏唸、條件說反）或答案說錯，即便核心數學概念正確，總體評等最高僅能評為 3 顆星（或以下），並需於評語中明確點出口誤處以利學生精確訂正。
   - **發布評語與說理診斷重點完全一致**：發布至 Padlet 的回饋評語直接採用「說理診斷重點」，精準聚焦於學生的數學概念掌握、思考脈絡與說理邏輯。
   - **精簡約 50 字直截回饋**：文字精煉直白（約 50 字左右），徹底屏除客套話與緩衝詞（切勿出現「同學你好、請加油」等套話），兼顧具體亮點肯定與關鍵概念修正，直接點明算理本質。
   - **審核表與 Padlet 留言無縫連動**：雙格式審核表與 Word 總表中的「診斷摘要與說理」直接即為「Padlet 發布回饋評語」，內容完全相同，簡化教師審閱流程。
5. **完整逐字稿雙格式審核表（方便教師迅速審核學生說理）**：
   - 全自動產出雙格式審核表，直觀對照學生口說逐字稿與 AI 評審結論：
     - **網頁版 (`.html`)**：內建「🎙️ 語音逐字稿」折疊與滾動預覽視窗、紅底警示標籤（無聲異常即時標記）、評語線上直接編輯、提供「📋 一鍵複製評語」按鈕。
     - **文件版 (`.md`)**：每位學生均設有獨立「🎙️ 【語音逐字稿】」區塊，方便教師歸檔或匯入 Google Docs。
6. **全自動製作高品質 A4 橫向 Word 評語摘要總表 (.docx)**：
   - 全自動透過 `python-docx` 產出專業排版之 A4 橫向（Landscape）評語摘要總表：
     - 具備單元主題標題、資訊列與教師評量規準（焦點判斷、任務要求）小卡。
     - 斑馬紋表格設計，包含項次、學生姓名、星級評等、診斷摘要說理與精簡發布評語。
     - 隨附 companion Markdown 總表檔，產出後全數鏡像備份至 **本機備份目錄 (`D:\說數學`)**，不寫入 Google 雲端硬碟。
     - 支援獨立指令隨時生成：`python .agents/skills/padlet-math-speaking/scripts/generate_summary_docx.py <區段名稱>`。
7. **自動快取與中斷續跑（Resume & Cache）**：
   - 若學生已有個別評分報告，自動跳過上傳與模型呼叫，省時省配額，網路中斷亦能隨時恢復。
8. **雙軌智慧評估模式（Hybrid Mode：外部批次 API ＋ 內建多模態直讀）**：
   - **軌道 A（全班大批量初批）**：當一次須處理 **5 支以上**全班影片時，優先由批次腳本（`pipeline.js` 或區段腳本）於背景調用 Gemini API 產出初稿，節省對話視窗空間。需注意檔案上傳路徑必須使用純 ASCII 檔名（如 `10_v2.mp4`）並設定逾時保護（`timeout=120000`）。
   - **軌道 B（零星補交 / API 壅塞即時備援）**：當新上傳或重錄影片為 **1～4 支**，或外部 API 遭遇晚間高負載（`503`/`504`）與單日免費額度上限（`429`）時，**直接下載影片至本機後，由 Agent 透過 `read_file` 內建多模態影音引擎親自觀看畫面筆跡與聆聽語音進行診斷**，零額度消耗、零等待且辨識精準度極高。
   - **無縫切換原則**：若外部 API 請求失敗或卡頓，立即自動切換為軌道 B 完成批改並寫入本機報告（`D:\padlet\[區段]\` 與 `D:\說數學\`），不讓流程中斷。
9. **一鍵發布審核成果（人機共審）**：
   - 無論採用哪一軌，均須先將完整逐字稿、板書檢視、評定星等與建議評語呈報老師審核；老師核可後再呼叫 Padlet MCP `create_comment`（或 `upload_approved.js`）發布至學生卡片。
   - **儲存禁令**：所有影音與報告僅留存於本機（`D:\padlet` 與 `D:\說數學`），**嚴禁寫入 `D:\Google 雲端硬碟`**。

---

## 🔑 前置條件

1. **Padlet API Key**：
   - 設定於 `~/.gemini/config/mcp_config.json` 或環境變數 `PADLET_API_KEY`。
2. **Gemini API Key**：
   - 設定於專案目錄 `.env`（`GEMINI_API_KEY=...`）或環境變數。

---

## 🚀 常用指令與操作流程

### 步驟一：執行全班自動批改與生成審核表（預設不發布）

```bash
node .agents/skills/padlet-math-speaking/scripts/pipeline.js --board "<PADLET_URL_OR_ID>" --section "<欄位/班級名稱>"
```

#### 常用範例：
- **批改指定欄位（例如：數重46（2）用分配律方式解題）**：
  ```bash
  node .agents/skills/padlet-math-speaking/scripts/pipeline.js --board "https://padlet.com/<您的Padlet帳號>/padlet-l61jt4fuyej8r77n" --section "數重46（2）用分配律方式解題"
  ```
- **指定學生座號（篩選特定學生批改）**：
  ```bash
  node .agents/skills/padlet-math-speaking/scripts/pipeline.js --board "https://padlet.com/<您的Padlet帳號>/padlet-d0xr4jjefydzne79" --section "911" --students "01,12,14,22,26"
  ```
- **指定自訂題目與標準解法（提升診斷精確度）**：
  ```bash
  node .agents/skills/padlet-math-speaking/scripts/pipeline.js --board "https://padlet.com/<您的Padlet帳號>/padlet-l61jt4fuyej8r77n" --section "數重46（2）" --topic "404 × 25 用分配律拆成 (400+4)×25 = 10100"
  ```
- **指定自訂本機備份路徑（選用）**：
  ```bash
  node .agents/skills/padlet-math-speaking/scripts/pipeline.js --board "<PADLET_URL>" --section "911" --backup "D:\說數學"
  ```
- **（選用）跳過審核，直接自動發布回饋至 Padlet**：
  ```bash
  node .agents/skills/padlet-math-speaking/scripts/pipeline.js --board "<PADLET_URL>" --section "904" --comment
  ```

---

### 步驟二：教師審核與微調（可檢視 HTML 或 Word 文件）

批改完成後，系統會自動在下列位置建立審核與評語總表文件（不儲存至 Google 雲端硬碟）：
1. **專案目錄**：
   - `./[欄位名稱]/[欄位名稱]_說數學評分審核表.html`
   - `./[欄位名稱]/[欄位名稱]_說數學評語摘要總表.docx`
   - `./[欄位名稱]/[欄位名稱]_說數學評語摘要總表.md`
2. **本機備份目錄 (`D:\說數學`)**：
   - 互動審核表：`D:\說數學\[欄位名稱]_說數學評分審核表.html`
   - Word 總表：`D:\說數學\[欄位名稱]_說數學評語摘要總表.docx`
   - Markdown 總表：`D:\說數學\[欄位名稱]_說數學評語摘要總表.md`

> 💡 **操作方式**：
> - 雙擊開啟專案目錄或 `D:\說數學` 的 `.html` 檔案或 `.docx` Word 總表。
> - 在各學生卡片下方檢視評等、診斷重點，並可直接修改文字框中的評語。
> - 若欲個別手動上傳，點擊「📋 複製評語」後直接貼到學生 Padlet 卡片留言。

---

### 步驟三：確認無誤後，一鍵批次上傳已核准評語

老師若確認審核表（`.md` 或 `.html`）中的評語皆無問題，執行以下指令即可全數同步至 Padlet：

```bash
node .agents/skills/padlet-math-speaking/scripts/upload_approved.js "<區段名稱或審核表路徑>"
```

#### 範例：
```bash
# 自動由專案目錄或「D:\說數學」讀取審核表
node .agents/skills/padlet-math-speaking/scripts/upload_approved.js 911
node .agents/skills/padlet-math-speaking/scripts/upload_approved.js 數重46_2

# 或直接指定審核表完整路徑
node .agents/skills/padlet-math-speaking/scripts/upload_approved.js "D:\說數學\911_說數學評分審核表.md"
```

---

### 步驟四：（選用）隨時重新產生 Word 評語摘要總表 (.docx)

若教師手動調整了評語或個別報告，可隨時執行下列指令重新生成高品質 A4 橫向 Word 總表：

```bash
# 傳入區段名稱或資料夾路徑，自動產生 .docx
python .agents/skills/padlet-math-speaking/scripts/generate_summary_docx.py 918
python .agents/skills/padlet-math-speaking/scripts/generate_summary_docx.py "D:/padlet/918"
```

---

## 參數詳細清單

| 參數 | 必要 | 說明 | 範例 |
|---|---|---|---|
| `--board` | 是 | Padlet 網址或 Board ID | `https://padlet.com/<您的Padlet帳號>/padlet-d0xr4jjefydzne79` |
| `--section` 或 `--class` | 否 | 欄位/班級名稱（預設為第一欄） | `--section "911"` |
| `--students` | 否 | 指定批改學生座號清單（逗號分隔） | `--students "01,12,14,22,26"` |
| `--topic` 或 `--prompt` | 否 | 指定題目與核心解法說明 | `--topic "404x25分配律簡算"` |
| `--out` | 否 | 本地檔案儲存資料夾（預設為 `./<欄位名稱>`） | `--out d:/padlet/911` |
| `--comment` | 否 | 跳過教師審核表，直接留言發布至 Padlet | `--comment` |

---

## 📁 產出檔案結構

批改後目錄結構如下（**僅儲存於本機，不寫入 Google 雲端硬碟**）：
```text
d:/padlet/<欄位名稱>/
├── post_xxx_video.mp4 (或 .mov)              # 原始影片本機備份
├── [學生/作業名稱]_評分報告.md                 # 個別學生完整逐字稿與規準評分
├── [欄位名稱]_說數學評分審核表.html            # 互動式全班審核總表（免下載直接預覽/修改）
├── [欄位名稱]_說數學評分審核表.md              # Markdown 審核總表
├── [欄位名稱]_說數學評語摘要總表.docx           # 專業 A4 橫向 Word 評語總表（含規準小卡）
└── [欄位名稱]_說數學評語摘要總表.md             # Markdown 評語摘要總表

D:/說數學/                                     # 本機備份目錄（不佔用雲端硬碟容量）
├── [區段名稱]_說數學評分審核表.html
├── [區段名稱]_說數學評分審核表.md
├── [區段名稱]_說數學評語摘要總表.docx
└── [區段名稱]_說數學評語摘要總表.md
```
所有成果均存放於本機磁碟，確保學生影音與評語隱私，不寫入桌面與 Google 雲端硬碟。
