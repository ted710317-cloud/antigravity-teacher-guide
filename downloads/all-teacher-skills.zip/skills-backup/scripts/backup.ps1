﻿param (
    [ValidateSet("All", "GitHub", "GoogleDrive")]
    [string]$Target = "All"
)

$ErrorActionPreference = "Stop"
$skillsDir = "%USERPROFILE%\.gemini\config\skills"
$driveFolderId = "<您的雲端硬碟備份資料夾ID>"
$githubRepo = "<您的GitHub帳號>/antigravity-skills"
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"

Write-Host "=============================================" -ForegroundColor Cyan
Write-Host " 🚀 Antigravity 技能雙向備份系統 (Dual Backup)" -ForegroundColor Cyan
Write-Host "    目標範圍: $Target" -ForegroundColor Cyan
Write-Host "    執行時間: $timestamp" -ForegroundColor Cyan
Write-Host "=============================================" -ForegroundColor Cyan

# 1. GitHub 備份流程
if ($Target -in @("All", "GitHub")) {
    Write-Host "`n📦 [1/2] 開始備份至 GitHub ($githubRepo) ..." -ForegroundColor Yellow
    Push-Location $skillsDir
    try {
        if (-not (Test-Path ".git")) {
            Write-Host "⚡ 初始化 Git 儲存庫..." -ForegroundColor Gray
            git init -b main
            git remote add origin "https://github.com/$githubRepo.git"
        }

        git add .
        $status = git status --porcelain
        if ($status) {
            $commitMsg = "Backup skills: $timestamp"
            git commit -m $commitMsg
            Write-Host "✅ 已建立 Commit: $commitMsg" -ForegroundColor Green
        } else {
            Write-Host "ℹ️ 本地無變更需 commit，準備推送最新狀態..." -ForegroundColor Gray
        }

        Write-Host "☁️  正在推送到 GitHub main 分支..." -ForegroundColor Gray
        git push -u origin main
        Write-Host "🎉 GitHub 備份成功！網址: https://github.com/$githubRepo" -ForegroundColor Green
    }
    catch {
        Write-Host "❌ GitHub 備份失敗: $_" -ForegroundColor Red
    }
    finally {
        Pop-Location
    }
}

# 2. Google Drive 備份流程
if ($Target -in @("All", "GoogleDrive")) {
    Write-Host "`n📦 [2/2] 開始備份至 Google Drive ..." -ForegroundColor Yellow
    $tempZip = Join-Path $env:TEMP "antigravity_skills_backup_$timestamp.zip"
    try {
        if (Test-Path $tempZip) { Remove-Item $tempZip -Force }
        Write-Host "⚡ 正在壓縮技能目錄為 ZIP..." -ForegroundColor Gray
        Compress-Archive -Path "$skillsDir\*" -DestinationPath $tempZip -Force
        
        $zipSize = (Get-Item $tempZip).Length / 1KB
        Write-Host ("✅ 壓縮完成: {0} ({1:N2} KB)" -f (Split-Path $tempZip -Leaf), $zipSize) -ForegroundColor Green

        Write-Host "☁️  正在上傳至 Google Drive (資料夾 ID: $driveFolderId) ..." -ForegroundColor Gray
        gdrive mutate upload $tempZip --parent $driveFolderId
        
        Write-Host "🎉 Google Drive 備份成功！" -ForegroundColor Green
    }
    catch {
        Write-Host "❌ Google Drive 備份失敗: $_" -ForegroundColor Red
    }
    finally {
        if (Test-Path $tempZip) { Remove-Item $tempZip -Force }
    }
}

Write-Host "`n=============================================" -ForegroundColor Cyan
Write-Host " ✨ 備份作業執行完畢！" -ForegroundColor Cyan
Write-Host "=============================================" -ForegroundColor Cyan
