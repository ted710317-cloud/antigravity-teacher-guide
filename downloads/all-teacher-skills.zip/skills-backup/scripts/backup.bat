@echo off
chcp 65001 >nul
echo 正在執行 Antigravity 技能雙向備份 (GitHub + Google Drive)...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0backup.ps1" -Target All
pause
