---
name: skills-backup
description: 專為 Antigravity 設計的技能全自動雙向備份系統（GitHub + Google Drive）。當使用者提到「備份技能」、「備份到 GitHub」、「備份到 Google Drive」、「打包技能」或輸入 /skills-backup 時觸發此技能。
---

# 🛡️ 技能全自動雙向備份系統 (Skills Dual-Backup System)

本技能提供 Antigravity 所有個人自訂技能的雙軌備份與版本控管機制，支援自動將技能代碼、設定與相依腳本同步推送至 **GitHub 遠端儲存庫** 與 **Google Drive 雲端硬碟**。

---

## 🌟 適用情境 (When to Use)

- 使用者要求「備份技能」、「把技能備份到 GitHub」、「備份到 Google Drive」。
- 新增、修改或優化某項自訂技能後，需要將最新版本存檔控管。
- 透過排程定期自動備份整個技能庫。
- 換機、重灌或系統損壞時，依據本技能指南快速還原所有技能。

---

## 📂 備份目標與綁定資訊

### 1. GitHub 儲存庫 (版本控管與原始碼)
- **存放路徑**：`https://github.com/<您的GitHub帳號>/antigravity-skills`
- **預設分支**：`main`
- **認證機制**：GitHub CLI (`gh`) 綁定之 `<您的GitHub帳號>` 帳號
- **特點**：完整記錄每一次修改差異（Git Commit History），支援分支與精確回滾。

### 2. Google Drive 雲端硬碟 (離線打包與快速匯入)
- **資料夾名稱**：`技能備份 (Antigravity Skills)`
- **資料夾位置**：`Google Drive > 備份 > 技能備份 (Antigravity Skills)`
- **資料夾 ID**：`<您的雲端硬碟備份資料夾ID>`
- **雲端連結**：[Google Drive 技能備份資料夾](https://drive.google.com/drive/folders/<您的雲端硬碟備份資料夾ID>)
- **檔案命名**：`antigravity_skills_backup_YYYYMMDD_HHMMSS.zip`

---

## 🛠️ 執行備份方式

### 方式 A：Agent 自動化執行 (推薦)
當使用者發出備份指令時，直接執行內建備份腳本：

```powershell
# 執行雙軌完整備份 (GitHub + Google Drive)
powershell -ExecutionPolicy Bypass -File "%USERPROFILE%\.gemini\config\skills\skills-backup\scripts\backup.ps1" -Target All

# 僅備份至 GitHub
powershell -ExecutionPolicy Bypass -File "%USERPROFILE%\.gemini\config\skills\skills-backup\scripts\backup.ps1" -Target GitHub

# 僅備份至 Google Drive
powershell -ExecutionPolicy Bypass -File "%USERPROFILE%\.gemini\config\skills\skills-backup\scripts\backup.ps1" -Target GoogleDrive
```

### 方式 B：本機一鍵執行
使用者可直接在檔案總管雙擊執行：
- `%USERPROFILE%\.gemini\config\skills\skills-backup\scripts\backup.bat`

---

## 📦 目前受保護的技能清單

1. **`claude-gemini-eduweb`**：雙模型教具網站工坊
2. **`guidance-record-assistant`**：國中小輔導紀錄隨筆撰寫與試算表登記
3. **`padlet-composition-publisher`**：學生作文全自動化排版發布至 Padlet
4. **`padlet-math-speaking`**：說數學學生影音逐字稿評析與自動回饋
5. **`padlet-video-downloader`**：Padlet 多媒體批次下載工具
6. **`tn-guidance-sync`**：臺南市國小輔導系統線上登錄同步
7. **`skills-backup`**：全自動雙軌備份系統（本技能）

---

## 🔄 災難還原指南 (Disaster Recovery)

若更換電腦或技能設定遺失，可透過以下兩種方式之一秒級還原：

1. **透過 GitHub 還原**：
   ```powershell
   cd %USERPROFILE%\.gemini\config
   git clone https://github.com/<您的GitHub帳號>/antigravity-skills.git skills
   ```
2. **透過 Google Drive 還原**：
   - 下載最新版 `antigravity_skills_backup_*.zip`。
   - 解壓縮至 `%USERPROFILE%\.gemini\config\skills\` 目錄即可。
