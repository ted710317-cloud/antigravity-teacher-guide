#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
parse_records.py
臺南市國小輔導系統 - 輔導紀錄 Excel 解析與資料準備工具
"""

import os
import sys
import json
import argparse
from datetime import datetime

DEFAULT_EXCEL_PATH = r"D:\Google 雲端硬碟\輔導紀錄匯入 .xls"

def ad_to_roc_date(ad_date_str):
    """
    將西元 8 碼數字 (如 20261113 或 2026-11-13) 轉為民國格式 (如 115/11/13)
    """
    clean_str = "".join(ch for ch in str(ad_date_str).strip() if ch.isdigit())
    if len(clean_str) == 8:
        year = int(clean_str[:4])
        month = clean_str[4:6]
        day = clean_str[6:8]
        roc_year = year - 1911
        return f"{roc_year}/{month}/{day}"
    return str(ad_date_str)

def read_excel_records(file_path=DEFAULT_EXCEL_PATH):
    """
    透過 win32com 無損讀取 Excel (.xls / .xlsx)，跳過前置空列並解析有效紀錄
    """
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"找不到檔案：{file_path}")

    import win32com.client
    excel = win32com.client.Dispatch("Excel.Application")
    excel.Visible = False
    excel.DisplayAlerts = False

    records = []
    wb = None
    try:
        wb = excel.Workbooks.Open(os.path.abspath(file_path), ReadOnly=True)
        ws = wb.Worksheets(1)
        used_range = ws.UsedRange
        total_rows = used_range.Rows.Count
        total_cols = used_range.Columns.Count

        # 欄位定義：
        # 1: 學年, 2: 學期, 3: 學號, 4: 班級代碼, 5: 座號, 6: 年級, 7: 日期, 8: 晤談對象, 9: 輔導內容要點, 10: 他校記錄者, 11: 記錄者學校
        for r in range(2, total_rows + 1):
            row_vals = [ws.Cells(r, c).Value for c in range(1, total_cols + 1)]
            # 檢查是否為空列 (沒有座號或沒有輔導內容)
            seat = row_vals[4] if len(row_vals) >= 5 else None
            content = row_vals[8] if len(row_vals) >= 9 else None
            
            if seat is None or content is None:
                continue
            
            seat_str = str(seat).strip()
            # 若為浮點數如 1.0 轉為整數
            if seat_str.endswith(".0"):
                seat_str = seat_str[:-2]
            seat_formatted = seat_str.zfill(2)

            date_val = str(row_vals[6]).strip() if len(row_vals) >= 7 and row_vals[6] is not None else ""
            if date_val.endswith(".0"):
                date_val = date_val[:-2]

            roc_date = ad_to_roc_date(date_val)

            target = str(row_vals[7]).strip() if len(row_vals) >= 8 and row_vals[7] is not None else "學生"
            summary = str(content).strip()

            syear = str(row_vals[0]).strip() if len(row_vals) >= 1 and row_vals[0] is not None else "115"
            if syear.endswith(".0"):
                syear = syear[:-2]

            seme = str(row_vals[1]).strip() if len(row_vals) >= 2 and row_vals[1] is not None else "1"
            if seme.endswith(".0"):
                seme = seme[:-2]

            class_code = str(row_vals[3]).strip() if len(row_vals) >= 4 and row_vals[3] is not None else "607"
            if class_code.endswith(".0"):
                class_code = class_code[:-2]

            grade = str(row_vals[5]).strip() if len(row_vals) >= 6 and row_vals[5] is not None else "6"
            if grade.endswith(".0"):
                grade = grade[:-2]

            records.append({
                "row_index": r,
                "syear": syear,
                "seme": seme,
                "class_code": class_code,
                "seat": seat_formatted,
                "grade": grade,
                "raw_date": date_val,
                "roc_date": roc_date,
                "target": target,
                "summary": summary
            })
    finally:
        if wb:
            wb.Close(False)

    return records

def main():
    parser = argparse.ArgumentParser(description="輔導紀錄 Excel 解析工具")
    parser.add_argument("--file", "-f", default=DEFAULT_EXCEL_PATH, help="Excel 檔案路徑")
    parser.add_argument("--json", action="store_true", help="以 JSON 格式輸出")
    parser.add_argument("--seat", help="只顯示特定座號")
    parser.add_argument("--count", "-n", type=int, default=0, help="僅顯示最後 n 筆 (0 為全部)")
    args = parser.parse_args()

    records = read_excel_records(args.file)
    if args.seat:
        target_seat = args.seat.zfill(2)
        records = [r for r in records if r["seat"] == target_seat]

    if args.count > 0:
        records = records[-args.count:]

    if args.json:
        print(json.dumps(records, ensure_ascii=False, indent=2))
    else:
        print(f"檔案路徑: {args.file}")
        print(f"有效紀錄總數: {len(records)} 筆\n")
        print(f"{'列號':<5}{'座號':<6}{'西元日期':<10}{'民國日期':<12}{'對象':<8}{'內容摘要'}")
        print("-" * 70)
        for r in records:
            preview = r["summary"][:35] + ("..." if len(r["summary"]) > 35 else "")
            print(f"{r['row_index']:<5}{r['seat']:<6}{r['raw_date']:<10}{r['roc_date']:<12}{r['target']:<8}{preview}")

if __name__ == "__main__":
    main()
