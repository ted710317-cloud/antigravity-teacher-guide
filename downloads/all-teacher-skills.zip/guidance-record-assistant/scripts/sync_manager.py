# -*- coding: utf-8 -*-
"""
sync_manager.py
臺南市國小輔導系統 - 線上同步管理與預檢工具
整合 Excel 資料解析、民國日期轉換、待同步項目比對與 Chrome 偵錯通訊埠預檢。
"""

import os
import sys
import json
import socket
import argparse
from datetime import datetime
from typing import List, Dict, Any, Optional

# Ensure UTF-8 output encoding for Windows console
if sys.stdout.encoding != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

DEFAULT_EXCEL_PATH = r"D:\Google 雲端硬碟\輔導紀錄匯入 .xls"
SYSTEM_URL = "https://assist.tn.edu.tw"

def check_chrome_debug_port(host: str = "127.0.0.1", port: int = 9222) -> bool:
    """檢查 Chrome 遠端偵錯通訊埠是否處於監聽狀態"""
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(1.0)
    try:
        result = s.connect_ex((host, port))
        return result == 0
    except Exception:
        return False
    finally:
        s.close()

def ad_to_roc_date(ad_date_str: Any) -> str:
    """將西元 8 碼數字 (如 20261113 或 2026-11-13) 轉為民國格式 (如 115/11/13)"""
    clean_str = "".join(ch for ch in str(ad_date_str).strip() if ch.isdigit())
    if len(clean_str) == 8:
        year = int(clean_str[:4])
        month = clean_str[4:6]
        day = clean_str[6:8]
        roc_year = year - 1911
        return f"{roc_year}/{month}/{day}"
    return str(ad_date_str)

def get_excel_records(file_path: str = DEFAULT_EXCEL_PATH) -> List[Dict[str, Any]]:
    """讀取 Excel 檔案中的所有有效輔導紀錄"""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"找不到檔案：{file_path}")

    import win32com.client as win32
    excel = win32.DispatchEx("Excel.Application")
    excel.Visible = False
    excel.DisplayAlerts = False
    wb = None
    records = []
    try:
        wb = excel.Workbooks.Open(os.path.abspath(file_path), ReadOnly=True)
        ws = wb.Worksheets(1)
        used_range = ws.UsedRange
        total_rows = used_range.Rows.Count
        total_cols = used_range.Columns.Count

        for r in range(2, total_rows + 1):
            row_vals = [ws.Cells(r, c).Value for c in range(1, total_cols + 1)]
            seat = row_vals[4] if len(row_vals) >= 5 else None
            content = row_vals[8] if len(row_vals) >= 9 else None

            if seat is None or content is None:
                continue

            seat_str = str(seat).strip()
            if seat_str.endswith(".0"):
                seat_str = seat_str[:-2]
            seat_formatted = seat_str.zfill(2)

            date_val = str(row_vals[6]).strip() if len(row_vals) >= 7 and row_vals[6] is not None else ""
            if date_val.endswith(".0"):
                date_val = date_val[:-2]

            roc_date = ad_to_roc_date(date_val)
            target = str(row_vals[7]).strip() if len(row_vals) >= 8 and row_vals[7] is not None else "學生"
            summary = str(content).strip()

            syear = str(row_vals[0]).strip() if len(row_vals) >= 1 and row_vals[0] is not None else "115"
            if syear.endswith(".0"):
                syear = syear[:-2]

            seme = str(row_vals[1]).strip() if len(row_vals) >= 2 and row_vals[1] is not None else "1"
            if seme.endswith(".0"):
                seme = seme[:-2]

            class_code = str(row_vals[3]).strip() if len(row_vals) >= 4 and row_vals[3] is not None else "607"
            if class_code.endswith(".0"):
                class_code = class_code[:-2]

            grade = str(row_vals[5]).strip() if len(row_vals) >= 6 and row_vals[5] is not None else "6"
            if grade.endswith(".0"):
                grade = grade[:-2]

            records.append({
                "row_index": r,
                "syear": syear,
                "seme": seme,
                "class_code": class_code,
                "seat": seat_formatted,
                "grade": grade,
                "raw_date": date_val,
                "roc_date": roc_date,
                "target": target,
                "summary": summary
            })
    finally:
        if wb:
            try:
                wb.Close(False)
            except Exception:
                pass
        try:
            excel.Quit()
        except Exception:
            pass

    return records

def parse_args():
    parser = argparse.ArgumentParser(description="臺南市國小輔導系統同步管理工具")
    parser.add_argument("--file", "-f", default=DEFAULT_EXCEL_PATH, help="Excel 檔案路徑")
    parser.add_argument("--seat", help="指定座號 (如 19 或 04)")
    parser.add_argument("--count", "-n", type=int, default=0, help="僅處理最後 n 筆")
    parser.add_argument("--json", action="store_true", help="以 JSON 格式輸出")
    parser.add_argument("--check-env", action="store_true", help="檢查 Chrome 遠端偵錯通訊埠與系統環境")
    return parser.parse_args()

def main():
    args = parse_args()

    if args.check_env:
        debug_ready = check_chrome_debug_port()
        file_exists = os.path.exists(args.file)
        status_info = {
            "chrome_debug_port_9222": "OPEN" if debug_ready else "CLOSED",
            "excel_file_exists": file_exists,
            "excel_path": os.path.abspath(args.file) if file_exists else args.file,
            "target_system_url": SYSTEM_URL,
            "ready_to_sync": file_exists and debug_ready
        }
        if args.json:
            print(json.dumps(status_info, ensure_ascii=False, indent=2))
        else:
            print("=== 臺南市輔導系統同步環境檢核 ===")
            print(f"Chrome 遠端偵錯埠 (9222): {'🟢 已就緒' if debug_ready else '🔴 未偵測到 (請先以偵錯模式啟動 Chrome)'}")
            print(f"輔導紀錄 Excel 檔案: {'🟢 存在' if file_exists else '🔴 未找到'} ({args.file})")
            print(f"目標系統網址: {SYSTEM_URL}")
            print(f"同步前置狀態: {'✅ 可直接啟動同步' if status_info['ready_to_sync'] else '⚠️ 需就緒偵錯環境後同步'}")
        return

    try:
        records = get_excel_records(args.file)
    except Exception as e:
        err = {"status": "error", "error": str(e)}
        if args.json:
            print(json.dumps(err, ensure_ascii=False, indent=2))
        else:
            print(f"讀取紀錄失敗: {e}")
        sys.exit(1)

    if args.seat:
        target_seat = args.seat.zfill(2)
        records = [r for r in records if r["seat"] == target_seat]

    if args.count > 0:
        records = records[-args.count:]

    if args.json:
        print(json.dumps(records, ensure_ascii=False, indent=2))
    else:
        print(f"=== 臺南市輔導系統待同步紀錄清單 (共 {len(records)} 筆) ===")
        for r in records:
            print(f"• [第 {r['row_index']:2d} 列] 座號: {r['seat']} | 民國日期: {r['roc_date']} | 對象: {r['target']}")
            print(f"  內容要點: {r['summary'][:45]}...")
            print("-" * 65)

if __name__ == "__main__":
    main()
