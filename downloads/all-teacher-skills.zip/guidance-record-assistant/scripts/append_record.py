# -*- coding: utf-8 -*-
"""
輔導紀錄自動追加寫入腳本 (append_record.py)
專為國中小教師設計，將專業輔導歷程紀錄自動追加至「輔導紀錄匯入」Excel 檔案中。
"""

import sys
import os
import argparse
import json
import datetime
import gc
from typing import Optional, Dict, Any

# Ensure UTF-8 output encoding for Windows console
if sys.stdout.encoding != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

CANDIDATE_PATHS = [
    r"D:\Google 雲端硬碟\輔導紀錄匯入 .xls",
    r"D:\Google 雲端硬碟\輔導紀錄匯入.xls",
    r"D:\Google 雲端硬碟\輔導紀錄匯入.xlsx",
    r"D:\Google 雲端硬碟\輔導紀錄匯入 .xlsx",
    os.path.join(os.getcwd(), "輔導紀錄匯入 .xls"),
    os.path.join(os.getcwd(), "輔導紀錄匯入.xls"),
]

def find_target_file(explicit_path: Optional[str] = None) -> str:
    if explicit_path and os.path.exists(explicit_path):
        return os.path.abspath(explicit_path)
    for p in CANDIDATE_PATHS:
        if os.path.exists(p):
            return os.path.abspath(p)
    raise FileNotFoundError(
        f"找不到「輔導紀錄匯入」試算表檔案。請確認檔案是否存在於「D:\\Google 雲端硬碟\\輔導紀錄匯入 .xls」或使用 --file 指定路徑。"
    )

def format_seat_number(seat: Any) -> str:
    s = str(seat).strip()
    if s.isdigit() and len(s) == 1:
        return f"0{s}"
    return s

def format_date(dt_str: Optional[str] = None) -> str:
    if dt_str:
        clean = "".join([c for c in str(dt_str) if c.isdigit()])
        if len(clean) == 8:
            return clean
        if len(clean) == 7:  # 民國年，如 1151015
            roc_year = int(clean[:3])
            ad_year = roc_year + 1911
            return f"{ad_year}{clean[3:]}"
    return datetime.datetime.now().strftime("%Y%m%d")

def list_records(file_path: str, count: int = 10):
    import win32com.client as win32
    excel = win32.DispatchEx("Excel.Application")
    excel.Visible = False
    excel.DisplayAlerts = False
    wb = None
    ws = None
    try:
        wb = excel.Workbooks.Open(file_path, ReadOnly=True)
        ws = wb.Sheets(1)
        xlUp = -4162
        last_row = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row
        print(f"檔案: {file_path}")
        print(f"工作表: {ws.Name}，目前總列數 (含標題): {last_row}")
        
        headers = [ws.Cells(1, c).Text for c in range(1, 12)]
        print(f"欄位標題: {' | '.join(headers)}")
        print("-" * 60)
        
        start_row = max(2, last_row - count + 1)
        for r in range(start_row, last_row + 1):
            vals = [ws.Cells(r, c).Text for c in range(1, 12)]
            print(f"Row {r:2d}: {vals}")
    finally:
        if wb:
            try:
                wb.Close(False)
            except Exception:
                pass
        try:
            excel.Quit()
        except Exception:
            pass
        del ws
        del wb
        del excel
        gc.collect()

def append_record(file_path: str, record: Dict[str, Any], dry_run: bool = False) -> Dict[str, Any]:
    # 欄位順序對應:
    # 1: 學年 (A)
    # 2: 學期 (B)
    # 3: 學號 (C)
    # 4: 班級代碼 (D)
    # 5: 座號 (E)
    # 6: 年級 (F)
    # 7: 日期 (G)
    # 8: 晤談對象 (H)
    # 9: 輔導內容要點 (I)
    # 10: 他校記錄者 (J)
    # 11: 記錄者學校 (K)
    
    row_values = [
        str(record.get("academic_year", "115")),
        str(record.get("semester", "1")),
        str(record.get("student_id", "")),
        str(record.get("class_code", "607")),
        format_seat_number(record.get("seat_number", "")),
        str(record.get("grade", "6")),
        format_date(record.get("date")),
        str(record.get("target", "學生")),
        str(record.get("content", "")).strip(),
        str(record.get("other_recorder", "")),
        str(record.get("recorder_school", "")),
    ]

    if dry_run:
        return {
            "status": "dry_run",
            "file": file_path,
            "row_values": row_values,
            "message": "模擬執行完成，未寫入檔案。"
        }

    import win32com.client as win32
    excel = win32.DispatchEx("Excel.Application")
    excel.Visible = False
    excel.DisplayAlerts = False
    wb = None
    ws = None
    try:
        wb = excel.Workbooks.Open(file_path)
        if wb.ReadOnly:
            raise RuntimeError(
                f"檔案「{file_path}」目前處於唯讀狀態，可能正被其他 Excel 程式開啟或鎖定。請先儲存並關閉 Excel 後再試一次。"
            )
        wb.CheckCompatibility = False
        ws = wb.Sheets(1)
        xlUp = -4162
        last_row = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row
        target_row = last_row + 1

        for col_idx, val in enumerate(row_values, start=1):
            cell = ws.Cells(target_row, col_idx)
            cell.NumberFormat = "@"  # 文字格式，確保座號與日期不掉前導零
            cell.Value = val

        wb.Save()
        wb.Close(True)
        wb = None
        return {
            "status": "success",
            "file": file_path,
            "appended_row": target_row,
            "row_values": row_values,
            "message": f"成功追加 1 筆輔導紀錄至第 {target_row} 列。"
        }
    except Exception as e:
        return {
            "status": "error",
            "file": file_path,
            "error": str(e)
        }
    finally:
        if wb:
            try:
                wb.Close(False)
            except Exception:
                pass
        try:
            excel.Quit()
        except Exception:
            pass
        del ws
        del wb
        del excel
        gc.collect()

def parse_args():
    parser = argparse.ArgumentParser(description="追加學生輔導紀錄至 Excel 試算表")
    parser.add_argument("--file", "-f", help="試算表檔案路徑 (預設自動搜尋 Google 雲端硬碟)")
    parser.add_argument("--seat", "-n", help="座號 (例如: 20 或 04)")
    parser.add_argument("--content", "-m", help="輔導內容要點 (客觀歷程文字)")
    parser.add_argument("--target", "-t", default="學生", help="晤談對象 (預設: 學生)")
    parser.add_argument("--year", "-y", default="115", help="學年度 (預設: 115)")
    parser.add_argument("--term", "-s", default="1", help="學期 (預設: 1)")
    parser.add_argument("--class-code", "-c", default="607", help="班級代碼 (預設: 607)")
    parser.add_argument("--grade", "-g", default="6", help="年級 (預設: 6)")
    parser.add_argument("--student-id", "-i", default="", help="學號 (預設留空)")
    parser.add_argument("--date", "-d", help="日期 YYYYMMDD (預設當日，如 20261015)")
    parser.add_argument("--other-recorder", default="", help="他校記錄者")
    parser.add_argument("--recorder-school", default="", help="記錄者學校")
    parser.add_argument("--json-input", help="以 JSON 字串傳入完整參數")
    parser.add_argument("--json-file", help="以 JSON 檔案路徑傳入參數")
    parser.add_argument("--dry-run", action="store_true", help="模擬執行，不實際寫入檔案")
    parser.add_argument("--list", action="store_true", help="列出檔案最新幾筆紀錄")
    parser.add_argument("--count", type=int, default=5, help="配合 --list 顯示的筆數")
    return parser.parse_args()

def main():
    args = parse_args()

    try:
        target_file = find_target_file(args.file)
    except Exception as e:
        print(json.dumps({"status": "error", "error": str(e)}, ensure_ascii=False, indent=2))
        sys.exit(1)

    if args.list:
        list_records(target_file, args.count)
        return

    record = {}
    if args.json_file and os.path.exists(args.json_file):
        with open(args.json_file, "r", encoding="utf-8") as f:
            record = json.load(f)
    elif args.json_input:
        record = json.loads(args.json_input)
    else:
        record = {
            "academic_year": args.year,
            "semester": args.term,
            "student_id": args.student_id,
            "class_code": args.class_code,
            "seat_number": args.seat,
            "grade": args.grade,
            "date": args.date,
            "target": args.target,
            "content": args.content,
            "other_recorder": args.other_recorder,
            "recorder_school": args.recorder_school,
        }

    if not record.get("seat_number") and not args.dry_run:
        print(json.dumps({"status": "error", "error": "必須提供學生座號 (--seat 或 -n)"}, ensure_ascii=False, indent=2))
        sys.exit(1)

    if not record.get("content") and not args.dry_run:
        print(json.dumps({"status": "error", "error": "必須提供輔導內容要點 (--content 或 -m)"}, ensure_ascii=False, indent=2))
        sys.exit(1)

    result = append_record(target_file, record, dry_run=args.dry_run)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if result.get("status") == "error":
        sys.exit(1)

if __name__ == "__main__":
    main()
