@echo off
chcp 65001 >nul
echo 正在以遠端偵錯模式啟動 Google Chrome...
echo 連接埠: 9222
echo 目標網址: https://assist.tn.edu.tw
start "" "C:\Program Files\Google\Chrome\Application\chrome.exe" --remote-debugging-port=9222 "https://assist.tn.edu.tw"
echo 啟動完成！請於開啟的瀏覽器中登入「臺南市國小輔導系統」。
