---
name: tn-guidance-system-sync
description: 臺南市國小輔導系統線上登記與自動同步技能（已與 guidance-record-assistant 整合為一體化雙向管線）。自動讀取 Google 雲端硬碟之「輔導紀錄匯入」Excel 試算表（.xls），透過 Chrome 瀏覽器自動化連線，安全引導教師登入「臺南市國小輔導系統」（https://assist.tn.edu.tw），自動比對並過濾線上已存在之紀錄以防重複，並將最新輔導歷程逐筆安全登錄至對應學生的輔導卡中。當使用者提到「登記輔導系統」、「同步輔導紀錄」、「上網填寫輔導紀錄」、「臺南市國小輔導系統」、「輔導紀錄上傳」或輸入 /tn-guidance-sync 時觸發此技能。
---

# 🏫 臺南市國小輔導系統 - 輔導紀錄線上同步整合技能 (Tainan Guidance System Sync)

> [!NOTE]
> 本技能已與 [`guidance-record-assistant`](../guidance-record-assistant/SKILL.md) 深度整合為全自動化一體化管線。  
> 您可以直接使用 `/guidance-record-assistant` 或 `/tn-guidance-sync`，兩者皆支援完整的「隨筆客觀化撰寫 ➔ Excel 試算表存檔 ➔ Google Chrome 臺南市輔導系統線上同步」全流程！

---

## 🌟 整合管線架構

1. **資料來源**：`D:\Google 雲端硬碟\輔導紀錄匯入 .xls`（由 `guidance-record-assistant` 自動追加產生）。
2. **格式轉譯**：自動將西元日期（`YYYYMMDD`）轉譯為線上系統專用之民國日期（`YYY/MM/DD`）。
3. **安全協作**：遵循資安準則，由教師於 Chrome 瀏覽器中手動完成 OpenID 與圖形驗證碼登入，AI 自動接管後續比對與填報。
4. **智慧防重**：依「座號 + 晤談日期 + 晤談對象」比對線上既有紀錄，已存在者自動跳過，僅補登新紀錄。
5. **逐筆入庫**：自動進入學生輔導卡填報，確認彈窗提示 `"資料已儲存!"` 後回報。

---

## 🛠️ 執行指令

```bash
# 1. 檢核環境 (Chrome 偵錯埠 9222 與 Excel 狀態)
python .agents/skills/guidance-record-assistant/scripts/sync_manager.py --check-env

# 2. 檢視待同步紀錄清單
python .agents/skills/guidance-record-assistant/scripts/sync_manager.py

# 3. 指定座號待同步清單
python .agents/skills/guidance-record-assistant/scripts/sync_manager.py --seat 19
```

完整詳細工作流程請參閱 [整合輔導助手全指南](../guidance-record-assistant/SKILL.md)。
