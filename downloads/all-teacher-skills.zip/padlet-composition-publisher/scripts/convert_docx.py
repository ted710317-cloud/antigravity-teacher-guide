#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
批次將 Word 作文診斷報告 (.docx) 透過 Microsoft Word COM 物件轉換為高品質 A4 PDF 檔。
"""

import os
import sys
import argparse
import win32com.client

sys.stdout.reconfigure(encoding="utf-8")

def convert_folder(src_dir, out_dir, count=26, title_prefix=""):
    os.makedirs(out_dir, exist_ok=True)
    print("啟動 Microsoft Word 轉換引擎...")
    word = win32com.client.Dispatch("Word.Application")
    word.Visible = False

    success_count = 0
    skip_count = 0
    fail_count = 0

    try:
        for i in range(1, count + 1):
            num = f"{i:02d}"
            candidates = [
                f"{title_prefix}{num}.docx",
                f"{title_prefix}{i}.docx",
                f"{num}.docx",
            ]
            docx_path = None
            for c in candidates:
                p = os.path.join(src_dir, c)
                if os.path.exists(p):
                    docx_path = p
                    break

            if not docx_path:
                for f in os.listdir(src_dir):
                    if f.endswith(".docx") and (num in f or f"{i}.docx" in f) and not f.startswith("~$") and "delete" not in f:
                        docx_path = os.path.join(src_dir, f)
                        break

            if not docx_path:
                print(f"[{num}] ⚠️ 找不到對應的 docx 檔案")
                continue

            out_pdf_name = f"{title_prefix}{num}_診斷報告.pdf" if title_prefix else f"{num}_診斷報告.pdf"
            out_pdf_path = os.path.join(out_dir, out_pdf_name)

            if os.path.exists(out_pdf_path) and os.path.getsize(out_pdf_path) > 1000:
                print(f"[{num}] ⚡ 已存在轉檔紀錄，略過：{out_pdf_name}")
                skip_count += 1
                continue

            print(f"[{num}] 正在轉檔：{os.path.basename(docx_path)} -> {out_pdf_name}...")
            try:
                doc = word.Documents.Open(docx_path)
                doc.SaveAs(out_pdf_path, FileFormat=17) # 17 = wdFormatPDF
                doc.Close()
                size_mb = os.path.getsize(out_pdf_path) / 1024 / 1024
                print(f"[{num}] ✅ 轉檔完成（{size_mb:.2f} MB）")
                success_count += 1
            except Exception as e:
                print(f"[{num}] ❌ 轉檔失敗：{e}")
                fail_count += 1
    finally:
        word.Quit()
        print(f"Word 引擎關閉。成功: {success_count}, 略過: {skip_count}, 失敗: {fail_count}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="DOCX to PDF batch converter")
    parser.add_argument("--src", required=True, help="Source folder containing docx files")
    parser.add_argument("--out", required=True, help="Output folder for converted pdf files")
    parser.add_argument("--count", type=int, default=26, help="Number of students (default: 26)")
    parser.add_argument("--prefix", default="", help="Filename prefix (e.g. 校園中的一角)")
    args = parser.parse_args()

    convert_folder(args.src, args.out, args.count, args.prefix)
