#!/usr/bin/env node
/**
 * 發布作文 (padlet-composition-publisher)
 * 全自動建立 Padlet 作文分欄看板、轉檔 A4 診斷報告為 PDF，並將原稿與報告批次上傳至各學生欄位。
 */

import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { execSync } from 'node:child_process';

function getPadletApiKey() {
  if (process.env.PADLET_API_KEY) return process.env.PADLET_API_KEY;
  try {
    const cfgPath = path.join(os.homedir(), '.gemini', 'config', 'mcp_config.json');
    if (fs.existsSync(cfgPath)) {
      const cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf8'));
      if (cfg.mcpServers?.padlet?.env?.PADLET_API_KEY) {
        return cfg.mcpServers.padlet.env.PADLET_API_KEY;
      }
    }
  } catch {}
  return null;
}

function parseArgs() {
  const args = process.argv.slice(2);
  const getOpt = (name, def = null) => {
    const idx = args.indexOf(name);
    return idx >= 0 && args[idx + 1] ? args[idx + 1] : def;
  };

  const title = getOpt('--title') || getOpt('--name') || '校園中的一角';
  const count = parseInt(getOpt('--count', '26'), 10);
  const board = getOpt('--board', null);

  let inputDir = getOpt('--input');
  if (!inputDir) {
    const candidates = [
      path.join('D:\', 'Google 雲端硬碟', '批改作文', title),
      path.join(os.homedir(), 'Desktop', '批改作文', title),
      path.join(process.cwd(), '批改作文', title),
      path.join('D:\', 'Google 雲端硬碟', title),
    ];
    for (const c of candidates) {
      if (fs.existsSync(c)) {
        inputDir = c;
        break;
      }
    }
  }

  return { title, count, board, inputDir };
}

const API_BASE = 'https://api.padlet.dev/v1';

async function padletApi(key, endpoint, options = {}) {
  const url = endpoint.startsWith('http') ? endpoint : `${API_BASE}${endpoint}`;
  const res = await fetch(url, {
    headers: {
      'X-API-KEY': key,
      'Content-Type': 'application/vnd.api+json',
      Accept: 'application/vnd.api+json',
      ...(options.headers || {}),
    },
    ...options,
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Padlet API ${res.status}: ${text.slice(0, 500)}`);
  }
  return await res.json();
}

async function createBoard(key, title, count) {
  const colList = Array.from({ length: count }, (_, i) => String(i + 1).padStart(2, '0')).join(', ');
  const instructions = `建立一面全新的 Padlet 看板，名稱是「${title}」，版面格式為分欄（Stream / Columns），依序建立 ${count} 個欄位，欄位名稱依序分別為：${colList}。請不要在任何欄位中放入任何預設卡片。`;

  console.log(`🎨 正在透過 Padlet API 建立新看板：「${title}」...`);
  const init = await padletApi(key, '/ai-recipe-boards', {
    method: 'POST',
    body: JSON.stringify({
      data: {
        type: 'ai_recipe_board',
        attributes: { boardCreationInstructions: instructions, role: 'teacher' },
      },
    }),
  });

  const statusUrl = init.data?.attributes?.statusUrl;
  if (!statusUrl) throw new Error('未取得 statusUrl');

  for (let i = 0; i < 45; i++) {
    await new Promise(r => setTimeout(r, 3000));
    const status = await padletApi(key, statusUrl);
    const attrs = status.data?.attributes ?? {};
    const state = (attrs.status ?? '').toLowerCase();
    if (['success', 'completed', 'complete', 'done', 'succeeded'].includes(state)) {
      const board = attrs.board ?? {};
      return {
        id: board.id,
        title: board.attributes?.title,
        url: board.attributes?.webUrl?.live,
      };
    }
    if (['failed', 'error'].includes(state)) {
      throw new Error(`建板失敗：${JSON.stringify(status)}`);
    }
  }
  throw new Error('建立看板逾時（已等候超過 2 分鐘）');
}

async function uploadToCatbox(filePath, fileName, cache, saveCacheFn) {
  if (cache[fileName]) {
    console.log(`  ⚡ [快取已存在] ${fileName} -> ${cache[fileName]}`);
    return cache[fileName];
  }

  const sizeMb = (fs.statSync(filePath).size / 1024 / 1024).toFixed(2);
  console.log(`  📤 [上傳雲端] ${fileName} (${sizeMb} MB)...`);
  const buf = fs.readFileSync(filePath);
  const form = new FormData();
  form.append('reqtype', 'fileupload');
  form.append('fileToUpload', new Blob([buf], { type: 'application/pdf' }), fileName);

  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      const res = await fetch('https://catbox.moe/user/api.php', { method: 'POST', body: form });
      if (res.ok) {
        const url = (await res.text()).trim();
        cache[fileName] = url;
        saveCacheFn();
        console.log(`  ✅ [完成] ${url}`);
        return url;
      }
    } catch (err) {
      console.warn(`  ⚠️ 上傳第 ${attempt} 次失敗: ${err.message}`);
    }
    await new Promise(r => setTimeout(r, 2000));
  }
  throw new Error(`檔案 ${fileName} 上傳失敗（已重試 3 次）`);
}

async function createPost(key, boardId, sectionId, subject, body, attachmentUrl) {
  const payload = {
    data: {
      type: 'post',
      attributes: {
        content: {
          subject,
          body,
          attachment: { url: attachmentUrl },
        },
      },
      relationships: {
        section: { data: { id: sectionId } },
      },
    },
  };

  const res = await padletApi(key, `/boards/${boardId}/posts`, {
    method: 'POST',
    body: JSON.stringify(payload),
  });
  return res.data?.id;
}

async function main() {
  const { title, count, board: inputBoard, inputDir } = parseArgs();

  console.log('==================================================');
  console.log('📝 發布作文 (padlet-composition-publisher)');
  console.log('==================================================');
  console.log(`📌 作文題目：${title}`);
  console.log(`👥 學生人數：${count} 位`);
  console.log(`📁 來源資料夾：${inputDir || '❌ 未找到！'}`);

  if (!inputDir || !fs.existsSync(inputDir)) {
    console.error('❌ 找不到來源資料夾！請以 --input 指定，或確認資料夾存在於：');
    console.error(`   D:\Google 雲端硬碟\批改作文\${title}`);
    process.exit(1);
  }

  const padletKey = getPadletApiKey();
  if (!padletKey) {
    console.error('❌ 找不到 PADLET_API_KEY，請確認 mcp_config.json 或環境變數。');
    process.exit(1);
  }

  // 1. 轉檔 DOCX 為 PDF
  const convertedDir = path.join(process.cwd(), 'converted_reports', title);
  fs.mkdirSync(convertedDir, { recursive: true });
  const scriptDir = path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Z]:)/, '$1'));
  const pyScript = path.join(scriptDir, 'convert_docx.py');

  console.log('
📄 [步驟一] 檢查並批次轉換 Word 診斷報告 (.docx) 為 A4 PDF...');
  try {
    execSync(`python "${pyScript}" --src "${inputDir}" --out "${convertedDir}" --count ${count} --prefix "${title}"`, {
      stdio: 'inherit',
    });
  } catch (err) {
    console.error('⚠️ 轉檔過程發生警告或部分失敗，繼續進行後續流程...');
  }

  // 2. 建立或連線 Padlet 看板
  let boardId = inputBoard;
  let boardUrl = null;

  if (!boardId) {
    console.log('
🎨 [步驟二] 建立全新 Padlet 作文分欄看板...');
    const created = await createBoard(padletKey, title, count);
    boardId = created.id;
    boardUrl = created.url;
    console.log(`✅ 看板建立成功！ID: ${boardId} | 網址: ${boardUrl}`);
  } else {
    if (boardId.includes('padlet.')) {
      const hash = boardId.split('/').pop().split('-').pop();
      boardId = hash;
    }
    console.log(`
🔗 [步驟二] 連線至現有看板 ID: ${boardId}`);
    boardUrl = `https://padlet.com/<您的Padlet帳號>/padlet-${boardId}`;
  }

  // 3. 取得欄位清單
  console.log('
🔍 [步驟三] 比對看板欄位（Sections）...');
  const boardData = await padletApi(padletKey, `/boards/${boardId}?include=sections`);
  const sections = (boardData.included ?? []).filter(x => x.type === 'section');
  const sectionMap = {};
  sections.forEach(s => {
    sectionMap[(s.attributes?.title ?? '').trim()] = s.id;
  });

  console.log(`✅ 成功比對到 ${Object.keys(sectionMap).length} 個區段欄位。`);

  // 4. 批次上傳與發布
  const cacheFile = path.join(convertedDir, 'upload_cache.json');
  let cache = {};
  if (fs.existsSync(cacheFile)) {
    try { cache = JSON.parse(fs.readFileSync(cacheFile, 'utf8')); } catch {}
  }
  const saveCache = () => fs.writeFileSync(cacheFile, JSON.stringify(cache, null, 2), 'utf8');

  console.log('
🚀 [步驟四] 開始批次上傳原稿與寫作診斷報告...');

  for (let i = 1; i <= count; i++) {
    const num = String(i).padStart(2, '0');
    console.log(`
▶️ [${num}/${count}] 處理學生座號：${num}`);

    if (cache[`posts_${num}`]) {
      console.log(`  ⚡ 座號 ${num} 兩張卡片均已發布，跳過！`);
      continue;
    }

    const secId = sectionMap[num] || sectionMap[String(i)];
    if (!secId) {
      console.warn(`  ⚠️ 看板中無「${num}」區段，略過。`);
      continue;
    }

    // 尋找原稿 PDF
    let studentPdfName = `${num}.pdf`;
    let studentPdfPath = path.join(inputDir, studentPdfName);
    if (!fs.existsSync(studentPdfPath)) {
      if (fs.existsSync(path.join(inputDir, `${num}pdf.pdf`))) {
        studentPdfName = `${num}pdf.pdf`;
        studentPdfPath = path.join(inputDir, studentPdfName);
      } else if (fs.existsSync(path.join(inputDir, `${i}.pdf`))) {
        studentPdfName = `${i}.pdf`;
        studentPdfPath = path.join(inputDir, studentPdfName);
      }
    }

    // 尋找診斷報告 PDF
    let reportPdfName = `${title}${num}_診斷報告.pdf`;
    let reportPdfPath = path.join(convertedDir, reportPdfName);
    if (!fs.existsSync(reportPdfPath)) {
      reportPdfName = `${num}_診斷報告.pdf`;
      reportPdfPath = path.join(convertedDir, reportPdfName);
    }

    if (!fs.existsSync(studentPdfPath) && !fs.existsSync(reportPdfPath)) {
      console.warn(`  ⚠️ 座號 ${num} 原稿與報告皆不存在，略過。`);
      continue;
    }

    let p1Id = null;
    let p2Id = null;

    // 發布卡片 1：原稿 PDF
    if (fs.existsSync(studentPdfPath)) {
      const studentUrl = await uploadToCatbox(studentPdfPath, `${num}_作文原稿.pdf`, cache, saveCache);
      console.log(`  📌 建立卡片 1：${num}.pdf（作文原稿）...`);
      p1Id = await createPost(
        padletKey,
        boardId,
        secId,
        `${num}.pdf（作文原稿）`,
        `${num} 號同學《${title}》作文手寫原稿掃描檔`,
        studentUrl
      );
      console.log(`  ✅ 卡片 1 建立成功：${p1Id}`);
      await new Promise(r => setTimeout(r, 1000));
    }

    // 發布卡片 2：寫作診斷報告 PDF
    if (fs.existsSync(reportPdfPath)) {
      const reportUrl = await uploadToCatbox(reportPdfPath, `${title}${num}_寫作診斷報告.pdf`, cache, saveCache);
      console.log(`  📌 建立卡片 2：${title}${num}（寫作診斷報告書）...`);
      p2Id = await createPost(
        padletKey,
        boardId,
        secId,
        `${title}${num}（寫作診斷報告書）`,
        `📄 包含 A4 完整寫作診斷報告、綜合總評、級分判定、四向度深度診斷與句子升級引導思考。`,
        reportUrl
      );
      console.log(`  ✅ 卡片 2 建立成功：${p2Id}`);
    }

    cache[`posts_${num}`] = { p1: p1Id, p2: p2Id };
    saveCache();
    await new Promise(r => setTimeout(r, 1200));
  }

  console.log('
==================================================');
  console.log('🎉 作文批次發布全數完成！');
  console.log(`🔗 看板專屬網址：${boardUrl}`);
  console.log('==================================================');
}

main().catch(err => {
  console.error('執行失敗：', err);
  process.exit(1);
});
