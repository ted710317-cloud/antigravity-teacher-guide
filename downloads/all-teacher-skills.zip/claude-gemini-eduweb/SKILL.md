---
name: claude-gemini-eduweb
description: 專為中小學教師與數位教材開發者打造的「雙模型教具網站工坊」。由 Claude 負責編寫高互動、符合教育認知心理與平板友善的 HTML5/JS 教具代碼，並由 Gemini 3.8 負責本機建置、啟動 Live 預覽伺服器、沙盒計算與視覺除錯。具備「自動降級備援機制」，當 Claude 額度用盡或無法使用時，Gemini 3.8 自動無縫接手獨立生成與發布。當使用者提到「教具網站」、「製作教具」、「互動教材」、「雙模型教具」、「線上教具」或輸入 /eduweb、/claude-gemini-eduweb 時觸發此技能。
---

# 🎓 雙模型教具網站工坊 (Claude-Gemini EduWeb Workshop)

此技能專為教育工作者量身打造，結合 **Claude（前端互動與教學界面設計專家）** 與 **Gemini 3.8（本機執行、多模態審查與自動部署專家）**，全自動化產出可於電子白板、電腦、iPad 立即離線操作的高互動教學網頁。

---

## 🌟 核心特色與架構優勢

1. **雙腦無縫協作（Dual-Engine Pipeline）**：
   - **Claude（教學架構師）**：負責邏輯構思、教學引導流程、高適讀性字體、符合兒童認知的正向回饋與音效。
   - **Gemini 3.8（本機執行官）**：負責自動在指定目錄建檔、啟動本機伺服器、進行代碼沙盒計算，並可使用瀏覽器工具檢查是否有報錯。

2. **智慧降級與自動備援（Fallback Mechanism）**：
   - **不用擔心 Claude 流量用完**！
   - 當系統偵測到 Claude API 觸發 `RateLimitError`、額度歸零（Quota Exceeded）或未設定金鑰時，會**自動無縫切換由 Gemini 3.8 全程接手生成**，教具開發工作絕不中斷。

3. **免安裝、零依賴、純單一檔案（Single-File HTML）**：
   - 生成的網頁整合 HTML5 + Tailwind CSS + Web Audio API（免外部音效檔，自體合成按鍵與通關音效）。
   - 老師拷貝到隨身碟即可直接在教室大屏或無網路環境點擊執行。

4. **觸控與大屏友善設計（Touch-First & Accessibility）**：
   - 按鈕點擊熱區 $\ge 48\text{px}$，避免國小學童誤觸。
   - 高對比度色彩、清晰說明看板、隨機題目生成與計分重置功能。

---

## 🔑 環境與金鑰設定

本技能可讀取環境變數或專案設定檔：
- `GEMINI_API_KEY`（或 `GOOGLE_API_KEY`）：Gemini 3.8 執行金鑰（必備）。
- `ANTHROPIC_API_KEY`：Claude 金鑰（選備；若無或額度用盡，自動由 Gemini 接手）。

---

## 🚀 指令與操作方式

### 1. 快速生成並立即在瀏覽器預覽

```bash
python "%USERPROFILE%\.gemini\config\skills\claude-gemini-eduweb\scripts\eduweb_orchestrator.py" --prompt "國小三年級認識圓形與分數切片互動教具" --title "fraction_pizza" --open
```

### 2. 指定引擎模式（強制指定或自動容錯）

* **預設自動模式（優先 Claude，若無額度自動切換 Gemini）**：
  ```bash
  python "%USERPROFILE%\.gemini\config\skills\claude-gemini-eduweb\scripts\eduweb_orchestrator.py" -p "國小四年級時鐘指針與旋轉角度教具" -t "clock_angle" --engine auto --open
  ```

* **純 Gemini 模式（節省 Claude 額度）**：
  ```bash
  python "%USERPROFILE%\.gemini\config\skills\claude-gemini-eduweb\scripts\eduweb_orchestrator.py" -p "九九乘法打地鼠益智挑戰" -t "multiplication_game" --engine gemini --open
  ```

* **啟動本機 HTTP 伺服器並持續預覽**：
  ```bash
  python "%USERPROFILE%\.gemini\config\skills\claude-gemini-eduweb\scripts\eduweb_orchestrator.py" -p "天平與質量平衡理化模擬實驗" -t "balance_scale" --serve --port 8080
  ```

---

## 📋 教具設計通用規範

當本技能產出代碼時，必須遵循以下教育規範：
1. **教學提示清楚**：頂端標題明確標註年級、單元與學習目標，並有一鍵說明的引導小精靈。
2. **音效回饋**：正確時播放和弦清脆提示音，錯誤時播放低沉柔和提示音（使用 Web Audio API 原生 OscillatorNode 合成）。
3. **支援重設與新題目**：具備「重新出題」或「清除重來」按鈕。
4. **自適應排版（Responsive）**：確保在手機、平板與 4K 電子白板上均能維持比例且字體清晰。
