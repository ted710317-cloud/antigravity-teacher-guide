# 🎓 雙模型教具網站工坊 (Claude-Gemini EduWeb Workshop)

專為中小學教師與數位教材開發者打造的雙 AI（Claude + Gemini 3.8）教具網頁自動化生成技能。

---

## 📁 目錄結構

```
claude-gemini-eduweb/
├── SKILL.md                       # Antigravity 技能主要定義檔
├── README.md                      # 使用指南與說明
└── scripts/
    └── eduweb_orchestrator.py     # 雙模型排程與代碼生成核心腳本
```

---

## ⚙️ 金鑰設定（選備）

您可以在以下任一路徑建立 `.env` 檔案存放 API 金鑰：
* 當前執行目錄的 `.env`
* `%USERPROFILE%\.gemini\.env`
* `%USERPROFILE%\.gemini\config\.env`

```env
# Claude 金鑰（選備：若未填寫或額度用盡，系統將自動無縫由 Gemini 3.8 接手）
ANTHROPIC_API_KEY="sk-ant-..."

# Gemini 金鑰（選備/必備：用於 Gemini 3.8 獨立運行或備援接手）
GEMINI_API_KEY="AIzaSy..."
```

---

## 🚀 常用指令範例

### 1. 製作「國小分數切片」教具並立即在瀏覽器開啟
```bash
python "%USERPROFILE%\.gemini\config\skills\claude-gemini-eduweb\scripts\eduweb_orchestrator.py" -p "國小三年級圓形與長條分數切片互動教具" -t "fraction_pizza" --open
```

### 2. 製作「時鐘與角度」教具並啟動本機伺服器
```bash
python "%USERPROFILE%\.gemini\config\skills\claude-gemini-eduweb\scripts\eduweb_orchestrator.py" -p "國小四年級時鐘指針與旋轉角度教具" -t "clock_angle" --serve --port 8080
```

### 3. 省流量模式：指定全由 Gemini 3.8 製作
```bash
python "%USERPROFILE%\.gemini\config\skills\claude-gemini-eduweb\scripts\eduweb_orchestrator.py" -p "九九乘法打地鼠挑戰" -t "math_mole" --engine gemini --open
```

---

## 🌟 產出特色
1. **免安裝、零依賴**：產出的 `index.html` 拷貝到隨身碟點兩下即可直接在電子白板或平板使用。
2. **內建合成音效**：使用原生 Web Audio API 合成和弦與點擊音，不依賴外部音訊連結。
3. **觸控大按鈕**：點擊熱區 $\ge 48\text{px}$，避免學生誤觸。
