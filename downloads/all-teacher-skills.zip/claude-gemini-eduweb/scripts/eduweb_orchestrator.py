#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
雙模型教具網站工坊 (Claude-Gemini EduWeb Orchestrator)
-------------------------------------------------------
核心功能：
1. Claude 負責前端教學互動代碼編寫（優先調用）。
2. 當 Claude 額度用盡或未設定金鑰時，自動無縫降級切換為 Gemini 3.8 接手生成。
3. 自動產出零依賴、免安裝的單一 HTML5 教具網頁檔（含 Web Audio 音效、TailwindCSS 與大字體/觸控優化）。
4. 自動建立專案目錄並支援一鍵本機啟動與預覽。
"""

import os
import sys
import argparse
import re
import webbrowser
import http.server
import socketserver
from pathlib import Path

# 載入環境變數（支援多個常規路徑）
try:
    from dotenv import load_dotenv
    load_dotenv()  # 當前目錄 .env
    load_dotenv(Path.home() / ".gemini" / ".env")
    load_dotenv(Path.home() / ".gemini" / "config" / ".env")
except ImportError:
    pass

SYSTEM_PROMPT = """你是一位專精於「中小學互動教學教具（Interactive Web Educational Tools）」的前端與教學設計專家。
你的任務是根據老師或開發者的需求，產出一個功能完整、設計優雅、可獨立運行的「單一檔案 HTML5 互動教具（Single-File HTML）」。

請務必嚴格遵守以下開發與教育設計規範：
1. 【單一完整檔案】：所有 CSS、JavaScript 都內嵌在同一個 HTML 檔案中。透過 CDN 引入 Tailwind CSS (<script src="https://cdn.tailwindcss.com"></script>)。不要依賴任何需要 npm build 的框架，確保老師下載或拷貝後「點兩下即可在瀏覽器離線執行」。
2. 【大屏與平板觸控友善】：
   - 所有點擊按鈕高度與寬度必須大於等於 48px，外觀圓角鮮明、色彩活潑。
   - 字體適讀性高，繁體中文介面，適合電子白板與學生平板。
3. 【自體合成音效 (Web Audio API)】：
   - 不得引用外部音效 mp3/wav 檔案（以防外鏈失效）。
   - 請直接利用原生 Web Audio API (AudioContext) 合成：
     * 正確/得分時：清脆悅耳的爬音和弦 (C5-E5-G5)。
     * 點擊/切換時：輕微短促的 pop 點擊音。
     * 答錯/重試時：柔和低沉的提示音。
4. 【教學結構完整性】：
   - 頂部：大標題、單元名稱、適合年級、操作提示/規則說明按鈕。
   - 中間：核心互動區（如 Canvas 繪圖、拖曳、拉桿數值調節、幾何切片或動畫）。
   - 底部：即時反饋、重設/重新出題按鈕、計分或完成度標記。
5. 【輸出格式限制】：
   - 請只回傳純 HTML 內容，從 <!DOCTYPE html> 開始，到 </html> 結束。
   - 絕對不要在最外層包含任何 Markdown 標記（不要有 ```html 或 ```），也不要有任何非代碼的閒聊文字。
"""

def clean_html_output(raw_text: str) -> str:
    """清理模型回傳的 markdown 代碼標籤"""
    text = raw_text.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:html)?\s*\n?", "", text, flags=re.IGNORECASE)
    if text.endswith("```"):
        text = re.sub(r"\n?```$", "", text)
    return text.strip()

def generate_with_claude(prompt: str) -> str:
    """使用 Claude 生成代碼"""
    import anthropic
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        raise ValueError("未檢測到 ANTHROPIC_API_KEY 環境變數")
    
    client = anthropic.Anthropic(api_key=api_key)
    
    # 支援 Claude 3.7 / 3.5 Sonnet
    model = os.environ.get("CLAUDE_MODEL", "claude-3-7-sonnet-20250219")
    print(f"🧠 [Claude 引擎] 正在由 {model} 構思與編寫教具網頁代碼...")
    
    response = client.messages.create(
        model=model,
        max_tokens=4096,
        system=SYSTEM_PROMPT,
        messages=[{"role": "user", "content": prompt}]
    )
    return clean_html_output(response.content[0].text)

def generate_with_gemini(prompt: str) -> str:
    """使用 Gemini 3.8 生成代碼"""
    api_key = os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY")
    if not api_key:
        raise ValueError("未檢測到 GEMINI_API_KEY 或 GOOGLE_API_KEY 環境變數")
    
    try:
        from google import genai
        from google.genai import types
        client = genai.Client(api_key=api_key)
        model = os.environ.get("GEMINI_MODEL", "gemini-3.8-flash")
        print(f"⚡ [Gemini 引擎] 正在由 {model} 編寫教具網頁代碼...")
        
        response = client.models.generate_content(
            model=model,
            contents=[
                types.Part.from_text(text=SYSTEM_PROMPT + "\n\n【使用者教具需求】：\n" + prompt)
            ],
            config=types.GenerateContentConfig(
                temperature=0.3,
            )
        )
        return clean_html_output(response.text)
    except Exception as e:
        # 若新 SDK 有狀況，嘗試 HTTP 呼叫或舊版 SDK 作為終極容錯
        print(f"透過 google-genai SDK 呼叫發生狀況，嘗試備援請求: {e}")
        import requests
        url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key={api_key}"
        headers = {"Content-Type": "application/json"}
        payload = {
            "contents": [{"parts": [{"text": SYSTEM_PROMPT + "\n\n【使用者教具需求】：\n" + prompt}]}],
            "generationConfig": {"temperature": 0.3}
        }
        res = requests.post(url, json=payload, headers=headers, timeout=60)
        res.raise_for_status()
        result_json = res.json()
        return clean_html_output(result_json['candidates'][0]['content']['parts'][0]['text'])

def run_orchestrator(prompt: str, title: str, output_dir: str, engine: str = "auto", auto_open: bool = False, serve: bool = False, port: int = 8080):
    print("=" * 65)
    print("🎓 雙模型教具網站工坊 (Claude-Gemini EduWeb Orchestrator)")
    print(f"📌 教具主題: {prompt}")
    print(f"⚙️ 執行模式: {engine}")
    print("=" * 65)
    
    html_code = None
    engine_used = None
    
    # 判斷引擎執行策略
    if engine in ["auto", "claude"]:
        try:
            html_code = generate_with_claude(prompt)
            engine_used = "Claude (雙腦協作模式)"
        except Exception as e:
            err_msg = str(e)
            if engine == "claude":
                print(f"❌ [錯誤] Claude 執行失敗: {err_msg}")
                sys.exit(1)
            else:
                print(f"\n⚠️  [智慧降級提示] 檢測到 Claude 無法調用（原因：{err_msg}）")
                print("🔄 系統已自動啟動【Gemini 3.8 備援引擎】接手編寫教具...")
                try:
                    html_code = generate_with_gemini(prompt)
                    engine_used = "Gemini 3.8 (全能備援模式)"
                except Exception as gemini_err:
                    print(f"❌ [錯誤] Gemini 執行也失敗: {gemini_err}")
                    sys.exit(1)
    elif engine == "gemini":
        try:
            html_code = generate_with_gemini(prompt)
            engine_used = "Gemini 3.8 (獨立專屬模式)"
        except Exception as e:
            print(f"❌ [錯誤] Gemini 執行失敗: {e}")
            sys.exit(1)
    
    # 確保輸出目錄存在
    target_dir = Path(output_dir).resolve()
    target_dir.mkdir(parents=True, exist_ok=True)
    target_file = target_dir / "index.html"
    
    with open(target_file, "w", encoding="utf-8") as f:
        f.write(html_code)
    
    print("\n" + "=" * 65)
    print("✅ 教具網頁製作完成！")
    print(f"🏷️  使用引擎: {engine_used}")
    print(f"📂 輸出路徑: {target_file}")
    print(f"💡 特色亮點: 單一 HTML 檔、免安裝、內建 Web Audio 音效、大字體與觸控優化")
    print("=" * 65)
    
    # 自動預覽開啟
    if auto_open:
        print(f"🌐 正在使用預設瀏覽器開啟教具...")
        webbrowser.open(target_file.as_uri())
    
    # 本地伺服器模式
    if serve:
        os.chdir(target_dir)
        handler = http.server.SimpleHTTPRequestHandler
        try:
            with socketserver.TCPServer(("", port), handler) as httpd:
                server_url = f"http://localhost:{port}"
                print(f"\n🚀 本機教具伺服器已啟動: {server_url}")
                print(f"👉 請在瀏覽器中開啟體驗（按 Ctrl+C 可結束預覽伺服器）")
                if auto_open:
                    webbrowser.open(server_url)
                httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n🛑 伺服器已安全停止。")
        except Exception as e:
            print(f"⚠️  無法啟動連接埠 {port} 的伺服器: {e}")

def main():
    parser = argparse.ArgumentParser(description="Claude-Gemini 雙模型教具網站全自動工坊")
    parser.add_argument("-p", "--prompt", required=True, help="教具需求說明，例：國小三年級認識圓形與分數切片")
    parser.add_argument("-t", "--title", default="edu_interactive_tool", help="教具專案代稱或子資料夾名稱")
    parser.add_argument("-o", "--output-dir", default=None, help="輸出目錄路徑（預設: d:/chrome/edu_tools/<title>）")
    parser.add_argument("-e", "--engine", choices=["auto", "claude", "gemini"], default="auto", help="引擎模式：auto（自動降級備援）、claude、gemini")
    parser.add_argument("--open", action="store_true", help="製作完成後自動在預設瀏覽器中開啟")
    parser.add_argument("--serve", action="store_true", help="製作完成後啟動本地 HTTP 預覽伺服器")
    parser.add_argument("--port", type=int, default=8080, help="本地 HTTP 伺服器通訊埠（預設 8080）")
    
    args = parser.parse_args()
    
    out_dir = args.output_dir
    if not out_dir:
        out_dir = os.path.join("d:\\chrome\\edu_tools", args.title)
    
    run_orchestrator(
        prompt=args.prompt,
        title=args.title,
        output_dir=out_dir,
        engine=args.engine,
        auto_open=args.open,
        serve=args.serve,
        port=args.port
    )

if __name__ == "__main__":
    main()
