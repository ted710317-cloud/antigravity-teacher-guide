#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { GoogleGenAI } from '@google/genai';

function getGeminiApiKey(customKey) {
  if (customKey) return customKey;
  if (process.env.GEMINI_API_KEY) return process.env.GEMINI_API_KEY;
  if (process.env.GOOGLE_API_KEY) return process.env.GOOGLE_API_KEY;
  
  // Try reading from .env in d:/padlet
  const envPath = path.join(process.cwd(), '.env');
  if (fs.existsSync(envPath)) {
    const lines = fs.readFileSync(envPath, 'utf8').split('\n');
    for (const line of lines) {
      const match = line.match(/^\s*(?:GEMINI_API_KEY|GOOGLE_API_KEY)\s*=\s*([^\s#]+)/);
      if (match) return match[1].trim();
    }
  }
  return null;
}

async function processVideo(ai, videoPath, outputDir) {
  const filename = path.basename(videoPath);
  const baseNameWithoutExt = path.basename(videoPath, path.extname(videoPath));
  console.log(`\n========================================`);
  console.log(`🎬 正在處理影片：${filename}`);
  console.log(`========================================`);

  console.log(`⬆️ 上傳影片至 Gemini API...`);
  const uploadResult = await ai.files.upload({
    file: videoPath,
    mimeType: 'video/mp4',
  });

  console.log(`⏳ 等待影片處理完成 (File: ${uploadResult.name})...`);
  let fileInfo = await ai.files.get({ name: uploadResult.name });
  while (fileInfo.state === 'PROCESSING') {
    process.stdout.write('.');
    await new Promise((r) => setTimeout(r, 4000));
    fileInfo = await ai.files.get({ name: uploadResult.name });
  }
  console.log('');

  if (fileInfo.state === 'FAILED') {
    throw new Error(`影片處理失敗：${uploadResult.name}`);
  }
  console.log(`✅ 影片準備就緒，開始進行語音轉錄與數學解題評分...`);

  const prompt = `
你是一位經驗豐富、循循善誘的國小/國中數學專業教師。
現在請你仔細觀看並聆聽這段學生「說數學 / 解題說明」的螢幕錄影，完成以下兩項任務：

### 任務一：完整語音逐字稿（繁體中文）
- 請將學生在影片中說的每一句話精準轉錄為繁體中文逐字稿。
- 請標記大致的時間軸（例如 [00:05]）。
- 若學生有口誤、停頓、自我修正或重複，請忠實記錄。

### 任務二：說數學解題評分與具體回饋
請依據以下三項教學規準進行評量：
1. **數學概念正確性（40%）**：
   - 學生是否正確理解題目？是否正確使用數學專有名詞（如因數、倍數、質數、公因數等）？
   - 計算步驟與解題邏輯是否無誤？
2. **解題邏輯與說理清晰度（30%）**：
   - 學生是否能清楚說明「為什麼要這樣算」，而非只是唸算式？
   - 步驟推進是否有條不紊？
3. **口語表達與螢幕算式配合（30%）**：
   - 說話清晰度、語速是否適中？
   - 語音解說與螢幕上書寫/畫面的同步配合度如何？

【輸出結構要求】：
- **總體評等**：給予 🌟 星級評分（1~5 顆星）與等級（特優 / 優等 / 尚可 / 待加強）。
- **解題亮點**：具體列出 2~3 點學生做得很好的地方（語氣親切、給予肯定）。
- **精進建議**：具體指出 1~2 個可以更清楚、更精確的關鍵步驟或觀念迷思。
- **給學生的暖心鼓勵評語**（約 50~100 字，適合直接複製給學生閱讀）。
`;

  const response = await ai.models.generateContent({
    model: 'gemini-3.6-flash',
    contents: [
      {
        fileData: {
          fileUri: fileInfo.uri,
          mimeType: fileInfo.mimeType,
        },
      },
      prompt,
    ],
  });

  const fullText = response.text;

  // Save full report
  const reportPath = path.join(outputDir, `${baseNameWithoutExt}_評分報告.md`);
  fs.writeFileSync(reportPath, fullText, 'utf8');
  console.log(`📝 已產出評分報告：${reportPath}`);

  // Extract transcript if possible or save separately
  const transcriptPath = path.join(outputDir, `${baseNameWithoutExt}_逐字稿.txt`);
  fs.writeFileSync(transcriptPath, fullText, 'utf8');
  console.log(`📄 已儲存逐字稿：${transcriptPath}`);

  return {
    filename,
    reportPath,
    transcriptPath,
    text: fullText
  };
}

async function main() {
  const args = process.argv.slice(2);
  const getOpt = (name) => {
    const idx = args.indexOf(name);
    return idx >= 0 && args[idx + 1] ? args[idx + 1] : null;
  };
  const hasFlag = (name) => args.includes(name);

  const targetPath = getOpt('--path') || getOpt('--file') || getOpt('--dir') || args[0];
  const customKey = getOpt('--key');

  if (!targetPath || hasFlag('--help') || hasFlag('-h')) {
    console.log(`
使用方式:
  node transcribe_and_grade.js <影片路徑或資料夾> [選項]

範例:
  node transcribe_and_grade.js d:/padlet/911
  node transcribe_and_grade.js d:/padlet/911/ScreenRecording_...mp4

選項:
  --key <API_KEY>   Gemini API Key（未提供時自動讀取環境變數或 .env）
  --out <目錄>      報告儲存目錄（預設為該影片所在資料夾）
  --help, -h        顯示說明
    `);
    process.exit(targetPath ? 0 : 1);
  }

  const apiKey = getGeminiApiKey(customKey);
  if (!apiKey) {
    console.error(`
❌ 錯誤：找不到 GEMINI_API_KEY。
請依以下任一方式設定：
1. 建立 d:/padlet/.env 檔案，填入：GEMINI_API_KEY=你的API_Key
2. 設定環境變數：$env:GEMINI_API_KEY="你的API_Key"
3. 執行時帶入參數：--key "你的API_Key"
`);
    process.exit(1);
  }

  const ai = new GoogleGenAI({ apiKey });

  const resolvedPath = path.resolve(targetPath);
  if (!fs.existsSync(resolvedPath)) {
    console.error(`❌ 路徑不存在：${resolvedPath}`);
    process.exit(1);
  }

  const stat = fs.statSync(resolvedPath);
  const videoFiles = [];
  let outputDir = getOpt('--out');

  if (stat.isDirectory()) {
    outputDir ??= resolvedPath;
    const files = fs.readdirSync(resolvedPath);
    for (const f of files) {
      if (/\.(mp4|mov|webm|m4v|mkv)$/i.test(f)) {
        videoFiles.push(path.join(resolvedPath, f));
      }
    }
  } else {
    outputDir ??= path.dirname(resolvedPath);
    videoFiles.push(resolvedPath);
  }

  if (videoFiles.length === 0) {
    console.log(`ℹ️ 在「${resolvedPath}」中未找到任何支援的影片檔案。`);
    process.exit(0);
  }

  console.log(`🎯 找到 ${videoFiles.length} 部影片待處理，儲存目錄：${outputDir}`);

  for (const videoFile of videoFiles) {
    try {
      await processVideo(ai, videoFile, outputDir);
    } catch (err) {
      console.error(`❌ 處理影片失敗 (${path.basename(videoFile)}):`, err.message);
    }
  }

  console.log(`\n🎉 全部影片批改與轉錄完成！`);
}

main().catch((err) => {
  console.error('❌ 系統錯誤:', err);
  process.exit(1);
});
