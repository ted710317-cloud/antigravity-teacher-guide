#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import https from 'node:https';
import http from 'node:http';
import os from 'node:os';

function getApiKey(customKey) {
  if (customKey) return customKey;
  if (process.env.PADLET_API_KEY) return process.env.PADLET_API_KEY;
  try {
    const cfgPath = path.join(os.homedir(), '.gemini', 'config', 'mcp_config.json');
    if (fs.existsSync(cfgPath)) {
      const cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf8'));
      if (cfg.mcpServers?.padlet?.env?.PADLET_API_KEY) {
        return cfg.mcpServers.padlet.env.PADLET_API_KEY;
      }
    }
  } catch {}
  return null;
}

const ID_RE = /^[A-Za-z0-9_]{15,22}$/;
function resolveBoardId(input) {
  const s = input.trim();
  if (ID_RE.test(s)) return s;
  if (s.includes('padlet.')) {
    try {
      const parsedUrl = new URL(s.startsWith('http') ? s : `https://${s}`);
      const lastSegment = parsedUrl.pathname.split('/').filter(Boolean).pop() ?? '';
      const hash = lastSegment.split('-').pop() ?? '';
      if (ID_RE.test(hash)) return hash;
    } catch {}
  }
  throw new Error(`無法從「${input}」解析出 board ID。請確認 Padlet 網址或 15-22 碼的 board ID。`);
}

function sanitizeFilename(name) {
  return name.replace(/[\\/:*?"<>|]/g, '_').trim();
}

function downloadFile(url, destPath) {
  return new Promise((resolve, reject) => {
    const client = url.startsWith('https') ? https : http;
    const req = client.get(url, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return downloadFile(res.headers.location, destPath).then(resolve).catch(reject);
      }
      if (res.statusCode !== 200) {
        return reject(new Error(`下載失敗，HTTP 狀態碼：${res.statusCode}`));
      }
      const total = parseInt(res.headers['content-length'] || '0', 10);
      let downloaded = 0;
      const fileStream = fs.createWriteStream(destPath);
      res.on('data', (chunk) => {
        downloaded += chunk.length;
        fileStream.write(chunk);
      });
      res.on('end', () => {
        fileStream.end();
        resolve({ destPath, size: downloaded, total });
      });
      res.on('error', (err) => {
        fileStream.close();
        reject(err);
      });
    });
    req.on('error', reject);
  });
}

async function main() {
  const args = process.argv.slice(2);
  const getOpt = (name) => {
    const idx = args.indexOf(name);
    return idx >= 0 && args[idx + 1] ? args[idx + 1] : null;
  };
  const hasFlag = (name) => args.includes(name);

  const boardArg = getOpt('--board') || args[0];
  const sectionFilter = getOpt('--section');
  const typeFilter = (getOpt('--type') || 'all').toLowerCase(); // video, image, all
  const outputDir = getOpt('--out') || getOpt('--output') || path.join(process.cwd(), 'downloads');
  const customKey = getOpt('--key');

  if (!boardArg || hasFlag('--help') || hasFlag('-h')) {
    console.log(`
使用方式:
  node download.js --board <Padlet網址或ID> [選項]

選項:
  --section <名稱或ID>  僅下載指定欄位/區段（例如 "911"）
  --type <類型>        過濾媒體類型：video, image, all (預設)
  --output <目錄>      檔案儲存目錄（預設為 ./downloads）
  --key <API_KEY>      Padlet API Key（未提供時自動讀取環境變數或 mcp_config.json）
  --help, -h           顯示此說明訊息
    `);
    process.exit(boardArg ? 0 : 1);
  }

  const apiKey = getApiKey(customKey);
  if (!apiKey) {
    console.error('❌ 錯誤：找不到 PADLET_API_KEY。請設定環境變數或在 mcp_config.json 中配置。');
    process.exit(1);
  }

  const boardId = resolveBoardId(boardArg);
  console.log(`🔍 正在讀取 Padlet 版面：${boardId}...`);

  const res = await fetch(`https://api.padlet.dev/v1/boards/${boardId}?include=posts,sections,comments`, {
    headers: {
      'X-API-KEY': apiKey,
      'Content-Type': 'application/vnd.api+json',
      Accept: 'application/vnd.api+json',
    },
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Padlet API 錯誤 (${res.status}): ${text}`);
  }

  const json = await res.json();
  const boardTitle = json.data?.attributes?.title || boardId;
  const included = json.included || [];
  const sections = included.filter((x) => x.type === 'section');
  const posts = included.filter((x) => x.type === 'post');

  console.log(`📋 看板名稱：「${boardTitle}」，共 ${sections.length} 個區段，${posts.length} 則貼文。`);

  let targetSectionIds = null;
  let targetSectionName = '全部區段';
  if (sectionFilter) {
    const match = sections.find(
      (s) => s.id === sectionFilter || (s.attributes?.title || '').toLowerCase().includes(sectionFilter.toLowerCase())
    );
    if (!match) {
      console.error(`❌ 找不到符合「${sectionFilter}」的欄位/區段。目前看板區段：`);
      sections.forEach((s) => console.log(`  - [${s.id}] ${s.attributes?.title}`));
      process.exit(1);
    }
    targetSectionIds = new Set([match.id]);
    targetSectionName = match.attributes?.title;
    console.log(`🎯 鎖定區段：${targetSectionName} (ID: ${match.id})`);
  }

  const matchedPosts = posts.filter((p) => {
    if (targetSectionIds) {
      const secId = p.relationships?.section?.data?.id;
      if (!secId || !targetSectionIds.has(secId)) return false;
    }
    return Boolean(p.attributes?.content?.attachment?.url);
  });

  console.log(`📦 區段「${targetSectionName}」內含有附件的貼文數量：${matchedPosts.length}`);

  if (matchedPosts.length === 0) {
    console.log('ℹ️ 沒有找到任何含有附件的卡片。');
    process.exit(0);
  }

  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }

  const videoExts = ['.mp4', '.mov', '.webm', '.avi', '.m4v', '.mkv'];
  const imageExts = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg'];

  let downloadedCount = 0;
  for (const post of matchedPosts) {
    const attachUrl = post.attributes.content.attachment.url;
    const urlObj = new URL(attachUrl);
    const originalExt = path.extname(urlObj.pathname).toLowerCase();

    const isVideo = videoExts.includes(originalExt) || attachUrl.includes('.mp4');
    const isImage = imageExts.includes(originalExt);

    if (typeFilter === 'video' && !isVideo) continue;
    if (typeFilter === 'image' && !isImage) continue;

    const baseName = path.basename(urlObj.pathname);
    const subject = post.attributes.content.subject;
    let fileName = baseName;
    if (subject && subject.trim()) {
      fileName = `${sanitizeFilename(subject.trim())}_${baseName}`;
    }

    const savePath = path.join(outputDir, fileName);
    console.log(`⬇️ 下載中：${fileName} ...`);
    try {
      const result = await downloadFile(attachUrl, savePath);
      const mb = (result.size / (1024 * 1024)).toFixed(2);
      console.log(`✅ 下載完成：${fileName} (${mb} MB) -> ${savePath}`);
      downloadedCount++;
    } catch (err) {
      console.error(`❌ 下載失敗 ${fileName}: ${err.message}`);
    }
  }

  console.log(`\n🎉 下載任務完成！共下載 ${downloadedCount} 個檔案至 ${outputDir}`);
}

main().catch((err) => {
  console.error('❌ 執行錯誤:', err.message);
  process.exit(1);
});
