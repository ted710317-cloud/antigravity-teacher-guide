---
name: padlet-video-downloader
description: Download videos, images, and media attachments from Padlet boards or specific columns/sections. Use this skill whenever the user asks to download, fetch, extract, or backup videos, photos, or attachments from a Padlet URL or section name.
---

# Padlet Video & Media Downloader Skill

This skill provides an automated workflow to download videos, images, and file attachments from any Padlet board or specific section/column.

## Prerequisites

- **Node.js**: v18 or higher.
- **Padlet API Key**: Configured in environment variable `PADLET_API_KEY` or in `~/.gemini/config/mcp_config.json`.

## Quick Start

The skill includes a dedicated helper script located at [scripts/download.js](./scripts/download.js).

### 1. Download Videos from a Specific Section

To download all videos from a specific section (e.g. "911"):

```bash
node .agents/skills/padlet-video-downloader/scripts/download.js --board "<PADLET_URL_OR_ID>" --section "<SECTION_NAME_OR_ID>" --type video --output "<OUTPUT_DIR>"
```

### 2. Download All Videos from Entire Board

```bash
node .agents/skills/padlet-video-downloader/scripts/download.js --board "<PADLET_URL_OR_ID>" --type video --output "<OUTPUT_DIR>"
```

### 3. Download All Attachments (Videos, Images, Files)

```bash
node .agents/skills/padlet-video-downloader/scripts/download.js --board "<PADLET_URL_OR_ID>" --section "<SECTION_NAME>" --type all --output "<OUTPUT_DIR>"
```

### 4. Transcribe & Grade Video (Speech-to-Text & Math Evaluation)

Once videos are downloaded to a local folder (e.g. `d:/padlet/911`), generate verbatim transcripts and mathematical evaluation:

```bash
node .agents/skills/padlet-video-downloader/scripts/transcribe_and_grade.js "d:/padlet/911"
```

## Command Line Arguments

| Parameter | Required | Description | Example |
|---|---|---|---|
| `--board` | Yes | Padlet board URL or 15-22 character board ID | `https://padlet.com/user/padlet-xyz` or `d0xr4jjefydzne79` |
| `--section` | No | Target section title or section ID | `911`, `質因數分解`, or `sec_x1rD2JLb5krjv0dM` |
| `--type` | No | Media type filter: `video`, `image`, or `all` (default: `all`) | `--type video` |
| `--output` | No | Destination directory for downloaded files (default: `./downloads`) | `--output d:/padlet/downloads` |
| `--key` | No | Explicit Padlet API Key (falls back to `PADLET_API_KEY` or `mcp_config.json`) | `--key pdltp_...` |

## Workflow Steps for Agent

1. **Identify Target Board & Section**:
   - Extract the board URL/ID and section name from the user's prompt.
2. **Execute Downloader Script**:
   - Run `node <path-to-skill>/scripts/download.js` with the corresponding flags.
   - Use `WaitMsBeforeAsync` with sufficient timeout or let it complete in background.
3. **Verify Downloads**:
   - Check the output directory to confirm the files exist and verify their sizes.
4. **Transcribe & Grade (if requested)**:
   - Run `node <path-to-skill>/scripts/transcribe_and_grade.js <target_folder>` to generate verbatim transcript and math rubric evaluations.
5. **Report to User**:
   - Provide the board title, section name, list of downloaded files, file sizes, exact storage paths, and the evaluation summary.

