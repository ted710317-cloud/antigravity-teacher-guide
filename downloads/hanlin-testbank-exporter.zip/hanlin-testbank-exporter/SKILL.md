---
name: hanlin-testbank-exporter
description: >-
  透過 Chrome DevTools MCP 連線桌面 Chrome，從「翰林雲端命題大師」批次擷取指定年級、科目與考試範圍的題庫題目，並依題型分檔輸出為 Markdown (.md) 審題參考資料庫。當使用者提到「匯出翰林題庫」、「下載命題大師題庫」、「輸出題庫成 MD 檔」、「依題型分檔匯出題庫」或輸入 /hanlin-testbank-exporter 時觸發此技能。
---

# 翰林雲端命題大師題庫匯出技能

本技能用於將「翰林雲端命題大師」（`https://testbank.hle.com.tw/paper-picker-view/subjectEntries.html?application=%E5%91%BD%E9%A1%8C%E5%A4%A7%E5%B8%AB`）的題庫題目完整擷取，並依題型分檔輸出成 Markdown（`.md`）審題參考資料庫。

## 前置檢查

1. **確認 `chrome-devtools` MCP 已連線**：呼叫 `list_pages` 確認可讀取使用者桌面 Chrome 分頁。若尚未啟用，請檢查 `~/.gemini/config/mcp_config.json` 是否已設定 `chrome-devtools-mcp@latest --autoConnect`，並請使用者在 Chrome 的 `chrome://inspect/#remote-debugging` 勾選「Enable remote debugging」。
2. **確認登入狀態**：使用 `new_page` 開啟命題大師網址後，透過 `take_snapshot` 確認使用者已登入（右上角顯示教師姓名）。若未登入，請暫停並請使用者於 Chrome 中完成登入後再繼續。

## 操作流程

### 步驟 1：選擇科目與進入手動命題
1. 在 `subjectEntries.html` 的快照中，找到目標學制（如「國小」）與目標科目按鈕（如「國語」、「社會」、「數學」、「自然科學」），使用 `click` 點擊。
2. 在 `selectionModeEntries.html` 點擊「手動命題」（`selection-manual`），進入 `scope.html?sessionId=...`。

### 步驟 2：展開冊次並向使用者確認考試範圍
1. 在 `scope.html` 透過 `evaluate_script` 等待載入後，勾選目標冊次（例如 `第七冊(六上)` 或 `第十一冊(六上)`），並讀取畫面上「課次」樹狀清單與各單元／課次的題數。
2. **使用 `ask_question` 向使用者確認**：
   - 本次要匯出的實際範圍（例如：特定單元、含／不含跨課次評量、或整冊全部）。
   - 確認輸出格式（預設依題型分檔輸出 `.md`，若有需要可另轉 `.docx`）。
3. 依據使用者回覆，在 `scope.html` 的快照中點擊對應 `treeitem`（若選全冊可直接點冊次節點），確認「下一步」按鈕啟用後點擊進入 `manualSelection.html?sessionId=...`。

### 步驟 3：透過頁面 API 批次擷取完整題庫
1. 等待 `manualSelection.html` 初始化完成後，使用 `evaluate_script` 在頁面內執行擷取邏輯（動態取得 `sessionId`、`subjectId` 與 `userId`，不寫死帳號資訊）：
   ```js
   async () => {
     await new Promise(r => setTimeout(r, 1500));
     const sessionId = new URLSearchParams(location.search).get('sessionId');
     const subjRes = await fetch(`/paper-picker/Session/${sessionId}/subjectId`);
     const subjectId = (await subjRes.text()).replace(/"/g, '').trim();
     const userRes = await fetch(`/paper-picker/Session/${sessionId}/userIdentity`);
     const userInfo = await userRes.json();
     const userId = userInfo.userId || userInfo.id || userInfo.sub;

     const url = `/paper-picker/Session/${sessionId}/items`;
     const payloadBase = {
       userId,
       subjectId,
       sectionIds: null,
       sources: null,
       difficultyBoundaryGroups: [
         { difficulty: "0", boundaries: { lower: 0.5, upper: 0.8 } },
         { difficulty: "3", boundaries: { lower: 0, upper: 0.5 } },
         { difficulty: "-3", boundaries: { lower: 0.8, upper: 1.00001 } }
       ],
       usertypes: null,
       knowledges: null,
       keyword: null,
       ignoreItemIds: null,
       itemIds: null,
       showFavoriteOnly: null,
       pageSize: 200
     };

     const all = [];
     for (let p = 1; p <= 50; p++) {
       const res = await fetch(url, {
         method: 'POST',
         headers: { 'content-type': 'application/json-patch+json' },
         body: JSON.stringify({ ...payloadBase, pageNumber: p })
       });
       const data = await res.json();
       if (!data.content || data.content.length === 0) break;
       all.push(...data.content);
       if (data.content.length < 200) break;
     }

     window.__HLE_COMPACT = all.map(x => ({
       id: x.itemId,
       d: x.difficulty,
       an: x.answerNum,
       k: x.knowledges,
       r: x.recognitions,
       s: x.sources,
       t: (x.usertypes && x.usertypes[0] && x.usertypes[0].name) || (x.answeringMethods && x.answeringMethods[0]) || '其他',
       doc: x.documents,
       c: x.content
     }));
     return { subjectId, total: window.__HLE_COMPACT.length, chunk: window.__HLE_COMPACT.slice(0, 500) };
   }
   ```
2. 若總題數超過 500 題，可平行呼叫多次 `evaluate_script`（例如每次切片 `1000` 題：`window.__HLE_COMPACT.slice(500, 1500)`、`slice(1500, 2500)` 等），`chrome-devtools-mcp` 會自動將大型輸出存成 `.system_generated/steps/*/output.txt`。

### 步驟 4：執行匯出腳本產生分檔 Markdown 與總覽
1. 呼叫 [export_to_md.py](./scripts/export_to_md.py)，將所有 chunk 檔案合併、依 `itemId` 去重並依題型分檔輸出：
   ```powershell
   python "%USERPROFILE%\.gemini\config\skills\hanlin-testbank-exporter\scripts\export_to_md.py" `
     --out-dir "<輸出資料夾路徑>" `
     --title "<例如：115 學年翰林版 國小國語第十一冊（六上）題庫總覽>" `
     --scope "<範圍說明>" `
     --sources "<出處說明>" `
     --chunks "<chunk1路徑>" "<chunk2路徑>" ...
   ```
2. **驗證輸出**：確認指令正常結束、總題數與各題型 `.md` 檔案數正確、`00_題庫總覽.md` 與 `raw_all_items.json` 皆已產生。
3. 在最終回覆中附上 [00_題庫總覽.md](file://...) 與各主要題型檔案的可點擊連結與題數統計。
