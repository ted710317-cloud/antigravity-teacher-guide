"""Export Hanlin Testbank (命題大師) item chunks to per-type Markdown files."""

import argparse
import json
import os
from collections import Counter, defaultdict

DIFF_MAP = {-3: "易", 0: "中", 3: "難"}


def load_chunk(path: str):
    """Load items from either a chrome-devtools-mcp output.txt or a plain JSON file."""
    with open(path, "r", encoding="utf-8") as f:
        text = f.read()

    stripped = text.strip()
    if stripped.startswith("["):
        return json.loads(stripped)

    for line in text.splitlines():
        line = line.strip()
        if line.startswith("{"):
            obj = json.loads(line)
            if "chunk" in obj:
                return obj["chunk"]
    raise ValueError(f"No valid chunk JSON found in {path}")


def safe_filename(name: str) -> str:
    for ch in ["/", "\\", ":", "*", "?", '"', "<", ">", "|"]:
        name = name.replace(ch, "_")
    return name


def export_markdown(out_dir: str, title: str, scope: str, sources_desc: str, chunk_paths: list[str]):
    os.makedirs(out_dir, exist_ok=True)

    raw_items = []
    for p in chunk_paths:
        raw_items.extend(load_chunk(p))

    seen = set()
    unique_items = []
    for it in raw_items:
        if it["id"] not in seen:
            seen.add(it["id"])
            unique_items.append(it)

    raw_path = os.path.join(out_dir, "raw_all_items.json")
    with open(raw_path, "w", encoding="utf-8") as f:
        json.dump(unique_items, f, ensure_ascii=False, indent=2)

    grouped = defaultdict(list)
    for it in unique_items:
        grouped[it["t"]].append(it)

    ordered_types = sorted(grouped.keys(), key=lambda t: (-len(grouped[t]), t))

    overview_lines = [
        f"# {title}",
        "",
        f"- **範圍**：{scope}",
        f"- **出處**：{sources_desc}",
        f"- **總題數**：{len(unique_items)} 題（原始回傳 {len(raw_items)} 筆，去重後 {len(unique_items)} 題）",
        "- **用途**：審題參考資料庫（依題型分檔輸出）",
        "",
        "## 一、各題型統計與檔案連結",
        "",
        "| 編號 | 題型 | 題數 | 難度分佈（易 / 中 / 難） | 檔案 |",
        "| :---: | :--- | :---: | :---: | :--- |",
    ]

    knowledge_counter = Counter()
    source_counter = Counter()

    for idx, qtype in enumerate(ordered_types, start=1):
        qlist = grouped[qtype]
        fname = f"{idx:02d}_{safe_filename(qtype)}.md"
        fpath = os.path.join(out_dir, fname)

        d_cnt = Counter(DIFF_MAP.get(x["d"], str(x["d"])) for x in qlist)
        diff_summary = f"{d_cnt.get('易', 0)} / {d_cnt.get('中', 0)} / {d_cnt.get('難', 0)}"
        overview_lines.append(f"| {idx:02d} | {qtype} | {len(qlist)} | {diff_summary} | [{fname}](./{fname}) |")

        md_lines = [
            f"# {qtype}（共 {len(qlist)} 題）",
            "",
            f"- **題庫**：{title}",
            f"- **範圍**：{scope}",
            f"- **難度統計**：易 {d_cnt.get('易', 0)} 題 ／ 中 {d_cnt.get('中', 0)} 題 ／ 難 {d_cnt.get('難', 0)} 題",
            "",
            "---",
            "",
        ]

        for q_idx, item in enumerate(qlist, start=1):
            diff_str = DIFF_MAP.get(item["d"], str(item["d"]))
            knowledges = "、".join(item.get("k") or []) or "未分類"
            recognitions = "、".join(item.get("r") or []) or "未標示"
            sources = "、".join(item.get("s") or []) or "未標示"
            docs = "、".join(item.get("doc") or []) or ""
            content = (item.get("c") or "").strip()

            for k in (item.get("k") or ["未分類"]):
                knowledge_counter[k] += 1
            for s in (item.get("s") or ["未標示"]):
                source_counter[s] += 1

            md_lines.append(f"### {q_idx}. 【{diff_str}】{knowledges}")
            md_lines.append(
                f"- **題目編號**：`{item['id']}` ｜ **出處**：{sources} ｜ **認知層次**：{recognitions} ｜ **子題數**：{item.get('an', 1)}"
            )
            if docs:
                md_lines.append(f"- **來源檔案**：`{docs}`")
            md_lines.append("")
            md_lines.append(content)
            md_lines.append("")
            md_lines.append("---")
            md_lines.append("")

        with open(fpath, "w", encoding="utf-8") as f:
            f.write("\n".join(md_lines))

    overview_lines.extend([
        "",
        "## 二、各課次／知識點題數分佈",
        "",
        "| 課次／知識點 | 題數 |",
        "| :--- | :---: |",
    ])
    for k, cnt in knowledge_counter.most_common():
        overview_lines.append(f"| {k} | {cnt} |")

    overview_lines.extend([
        "",
        "## 三、各出處題數分佈（單題可能同時屬於多個出處）",
        "",
        "| 出處 | 題數 |",
        "| :--- | :---: |",
    ])
    for s, cnt in source_counter.most_common():
        overview_lines.append(f"| {s} | {cnt} |")

    overview_path = os.path.join(out_dir, "00_題庫總覽.md")
    with open(overview_path, "w", encoding="utf-8") as f:
        f.write("\n".join(overview_lines))

    print(
        f"DONE: {len(unique_items)} unique items (from {len(raw_items)} fetched) "
        f"exported into {len(ordered_types)} type files + 00_題庫總覽.md + raw_all_items.json"
    )


def main():
    parser = argparse.ArgumentParser(description="Export Hanlin Testbank chunks to Markdown files.")
    parser.add_argument("--out-dir", required=True, help="Output directory")
    parser.add_argument("--title", required=True, help="Overview title")
    parser.add_argument("--scope", required=True, help="Scope description")
    parser.add_argument("--sources", default="全選（試題、習作、圖說試題、素養題）", help="Sources description")
    parser.add_argument("--chunks", nargs="+", required=True, help="Chunk file paths")
    args = parser.parse_args()

    export_markdown(args.out_dir, args.title, args.scope, args.sources, args.chunks)


if __name__ == "__main__":
    main()
