---
name: padlet-composition-publisher
description: 專為中小學教師打造的「發布作文」全自動化發布技能。自動建立 Padlet 作文分欄看板（1~26 欄位）、自動透過 Microsoft Word COM 物件將 Word 作文診斷報告 (.docx) 轉為高解析度 A4 PDF 檔、將學生手寫原稿掃描 PDF 與寫作診斷報告 PDF 批次發布至對應學生欄位，具備 Padlet 免下載直接線上翻閱預覽功能與中斷續跑快取機制。當使用者提到「發布作文」、「上傳作文到 Padlet」、「作文看板」或輸入 /發布作文、/padlet-composition-publisher 時觸發此技能。
---

# 📝 發布作文 (Padlet Composition Publisher) AI 自動化技能

此技能專為語文與作文教師設計，能全自動處理班級學生作文手寫原稿（PDF）與 AI/教師批改產出之寫作診斷報告書（.docx），並將兩者成對發布至 Padlet 班級分欄展示牆。

---

## 🌟 核心特色與技術架構

1. **一鍵建立分欄看板（Stream / Columns）**：
   - 透過 Padlet AI Recipe API 自動建立指定題目（例：「校園中的一角」）之分欄看板。
   - 自動預先建置 1~26 號（或自訂人數）的獨立座號欄位（`01`, `02`, ..., `26`），無需教師手動逐一新增區段。
2. **Microsoft Word 原生轉檔引擎（.docx 轉 A4 PDF）**：
   - 整合系統底層 Microsoft Word COM 物件，將 A4 作文診斷報告書（含排版、字型、表格、四向度診斷標註）無損轉換為正式 PDF 檔。
   - 完美解決行動裝置（手機、平板）無法直接開啟 Word 檔的問題，家長與學生於 Padlet 點擊即可**直接線上翻閱、免下載開啟**。
3. **雙卡片成對發布機制**：
   - 每個學生欄位自動依序發布兩張卡片：
     - **卡片 1【作文原稿】**：`{座號}.pdf（作文原稿）`，附帶學生手寫作品掃描 PDF。
     - **卡片 2【寫作診斷報告書】**：`{題目}{座號}（寫作診斷報告書）`，內文包含重點說明，並附帶高畫質完整 A4 診斷 PDF。
4. **雲端檔案傳輸與快取續跑（Resume & Cache）**：
   - 自動將 PDF 直連託管於 Padlet 可直接嵌入之永久高速雲端儲存。
   - 內建 `upload_cache.json` 快取紀錄，如遇網路中斷或重複執行，自動略過已上傳成功的檔案與卡片，省時且避免重複發布。
5. **多路徑智慧偵測**：
   - 自動搜尋 Google 雲端硬碟 (`D:\Google 雲端硬碟\批改作文\...`)、桌面 (`~/Desktop/批改作文/...`) 或專案目錄。

---

## 🔑 前置需求

1. **Padlet API Key**：
   - 設定於 `~/.gemini/config/mcp_config.json` 或環境變數 `PADLET_API_KEY`。
2. **作業系統環境**：
   - Windows 系統且安裝有 Microsoft Word（支援 COM 自動化轉檔）。
   - Node.js 18+ 及 Python 3.10+。

---

## 🚀 常用指令與操作方式

### 1. 標準發布（預設題目：校園中的一角，預設 26 位學生）

```bash
node .agents/skills/padlet-composition-publisher/scripts/publish_composition.js --title "校園中的一角" --count 26
```

### 2. 指定自訂來源資料夾

```bash
node .agents/skills/padlet-composition-publisher/scripts/publish_composition.js --title "我的校園" --input "D:\Google 雲端硬碟\批改作文\我的校園" --count 28
```

### 3. 發布至現有 Padlet 看板（不重新建板）

若已手動建好看板或希望發布至既有看板，可加上 `--board` 參數：

```bash
node .agents/skills/padlet-composition-publisher/scripts/publish_composition.js --title "校園中的一角" --board "https://padlet.com/<您的Padlet帳號>/padlet-<看板ID>"
```

---

## 📂 檔案命名規範

將學生資料放置於 `D:\Google 雲端硬碟\批改作文\<題目名稱>` 目錄下：

| 檔案類型 | 檔名範例 | 說明 |
| :--- | :--- | :--- |
| **手寫作文原稿** | `01.pdf`, `02.pdf` ... `26.pdf`（或 `17pdf.pdf`） | 學生手寫作文掃描檔 |
| **Word 診斷報告** | `校園中的一角01.docx`, `校園中的一角02.docx` ... | 含綜合評語、級分判定之報告書 |

---

## 🛠️ 輔助工具腳本

* **單獨執行 Word 轉 PDF 轉檔**：
  ```bash
  python .agents/skills/padlet-composition-publisher/scripts/convert_docx.py --src "D:\Google 雲端硬碟\批改作文\校園中的一角" --out "d:\padlet\converted_reports\校園中的一角" --count 26 --prefix "校園中的一角"
  ```
